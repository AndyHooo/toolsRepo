package com.jst.config;

/**
 * 
 * <p>Title: XMLSerializerConfig.java</p>
 * <p>Description: 此配置用于XML和JSON相互转换时所需配置</p>
 * @author lee
 * @date 2015年6月8日
 * @version 1.0
 */
public class XMLSerializerConfig {

	//JSON转XML时XML时XML根节点名称
	private String rootName;
	
	//JSON转XML时，rootName为空时以objectName作为XML根节点名称
	private String objectName;
	
	//JSONArray转XML时XML根节点名称
	private String arrayName;
	
	//JSON转XML时对象记录父节点名称
	private String elementName;
	
	//XML转JSON时强制以根节点名称作为JSON的键值
	private boolean forceTopLevelObject;
	
	//JSON转XML时设置各节点属性(<node class="*"></node>)
	private boolean typeHintsEnabled;
	
	//JSON转XML时设置根节点属性内容前缀(<node class="json_*"></node>)
	private boolean typeHintsCompatibility;
	
	private boolean namespaceLenient;
	private boolean removeNamespacePrefixFromElements;
	private boolean skipNamespaces;
	private boolean skipWhitespace;
	private boolean trimSpaces;
	
	private String[] expandableProperties;
	
	private static final String[] EMPTY_ARRAY = new String[0];
	
	public XMLSerializerConfig() {
		setObjectName("o");
	    setArrayName("a");
	    setElementName("e");
	    setForceTopLevelObject(false);
	    setTypeHintsEnabled(true);
	    setTypeHintsCompatibility(true);
	    setNamespaceLenient(false);
	    setRemoveNamespacePrefixFromElements(false);
	    setSkipNamespaces(false);
	    setSkipWhitespace(false);
	    setTrimSpaces(false);
	    setExpandableProperties(EMPTY_ARRAY);
	}

	public XMLSerializerConfig(String rootName, String objectName,
			String arrayName, String elementName, boolean forceTopLevelObject,
			boolean typeHintsEnabled, boolean typeHintsCompatibility,
			boolean namespaceLenient,
			boolean removeNamespacePrefixFromElements, boolean skipNamespaces,
			boolean skipWhitespace, boolean trimSpaces,
			String[] expandableProperties) {
		this.rootName = rootName;
		this.objectName = objectName;
		this.arrayName = arrayName;
		this.elementName = elementName;
		this.forceTopLevelObject = forceTopLevelObject;
		this.typeHintsEnabled = typeHintsEnabled;
		this.typeHintsCompatibility = typeHintsCompatibility;
		this.namespaceLenient = namespaceLenient;
		this.removeNamespacePrefixFromElements = removeNamespacePrefixFromElements;
		this.skipNamespaces = skipNamespaces;
		this.skipWhitespace = skipWhitespace;
		this.trimSpaces = trimSpaces;
		this.expandableProperties = expandableProperties;
	}

	public String getRootName() {
		return rootName;
	}

	public void setRootName(String rootName) {
		this.rootName = rootName;
	}

	public String getObjectName() {
		return objectName;
	}

	public void setObjectName(String objectName) {
		this.objectName = objectName;
	}

	public String getArrayName() {
		return arrayName;
	}

	public void setArrayName(String arrayName) {
		this.arrayName = arrayName;
	}

	public String getElementName() {
		return elementName;
	}

	public void setElementName(String elementName) {
		this.elementName = elementName;
	}

	public boolean isForceTopLevelObject() {
		return forceTopLevelObject;
	}

	public void setForceTopLevelObject(boolean forceTopLevelObject) {
		this.forceTopLevelObject = forceTopLevelObject;
	}

	public boolean isTypeHintsEnabled() {
		return typeHintsEnabled;
	}

	public void setTypeHintsEnabled(boolean typeHintsEnabled) {
		this.typeHintsEnabled = typeHintsEnabled;
	}

	public boolean isTypeHintsCompatibility() {
		return typeHintsCompatibility;
	}

	public void setTypeHintsCompatibility(boolean typeHintsCompatibility) {
		this.typeHintsCompatibility = typeHintsCompatibility;
	}

	public boolean isNamespaceLenient() {
		return namespaceLenient;
	}

	public void setNamespaceLenient(boolean namespaceLenient) {
		this.namespaceLenient = namespaceLenient;
	}

	public boolean isRemoveNamespacePrefixFromElements() {
		return removeNamespacePrefixFromElements;
	}

	public void setRemoveNamespacePrefixFromElements(
			boolean removeNamespacePrefixFromElements) {
		this.removeNamespacePrefixFromElements = removeNamespacePrefixFromElements;
	}

	public boolean isSkipNamespaces() {
		return skipNamespaces;
	}

	public void setSkipNamespaces(boolean skipNamespaces) {
		this.skipNamespaces = skipNamespaces;
	}

	public boolean isSkipWhitespace() {
		return skipWhitespace;
	}

	public void setSkipWhitespace(boolean skipWhitespace) {
		this.skipWhitespace = skipWhitespace;
	}

	public boolean isTrimSpaces() {
		return trimSpaces;
	}

	public void setTrimSpaces(boolean trimSpaces) {
		this.trimSpaces = trimSpaces;
	}

	public String[] getExpandableProperties() {
		return expandableProperties;
	}

	public void setExpandableProperties(String[] expandableProperties) {
		this.expandableProperties = expandableProperties;
	}

}
