package com.jst.config;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.jst.util.StringUtil;
import com.thoughtworks.xstream.converters.Converter;
import com.thoughtworks.xstream.converters.SingleValueConverter;

/**
 * 
 * <p>
 * Title: ObjectSerializeConfig.java
 * </p>
 * <p>
 * Description: 此配置用于封装序列化及反序列化对象时所需的配置
 * </p>
 * 
 * @author lee
 * @date 2015年6月8日
 * @version 1.0
 */
public class ObjectSerializeConfig {

	// 包名对应的简称
	private Map<String, String> packageAlias;

	// 类名对应的简称
	private Map<Class<?>, String> objectAlias;

	// 字段名对应的简称
	private Map<Class<?>, Map<String, String>> fieldAlias;

	// 字段对应的转换类
	private Map<Class<?>, Map<String, SingleValueConverter>> fieldConverter;

	// 不序列化或排除在外的字段
	private Map<Class<?>, String> excludeField;

	// 全局类的转换类
	private List<Converter> globalConverter;

	// 全局去掉class数据
	private boolean removeClass = true;

	/**
	 * @see 创建实例
	 */
	public ObjectSerializeConfig() {
		super();

		packageAlias = new HashMap<String, String>();

		objectAlias = new HashMap<Class<?>, String>();

		fieldAlias = new HashMap<Class<?>, Map<String, String>>();

		fieldConverter = new HashMap<Class<?>, Map<String, SingleValueConverter>>();

		excludeField = new HashMap<Class<?>, String>();

		globalConverter = new ArrayList<Converter>();
	}

	/**
	 * @see 设置包名对应的简称
	 * @param packageName
	 * @param alias
	 */
	public void setPackageAlias(String packageName, String alias) {
		packageAlias.put(packageName, alias);
	}

	/**
	 * @see 获取包名简称映射
	 * @return Map<String, String>
	 */
	public Map<String, String> getPackageAlias() {
		return packageAlias;
	}

	/**
	 * @see 设置类名对应的简称
	 * @param clazz
	 * @param alias
	 */
	public void setObjectAlias(Class<?> clazz, String alias) {
		objectAlias.put(clazz, alias);
	}

	/**
	 * @see 获取类名简称映射
	 * @return Map<Class<?>, String>
	 */
	public Map<Class<?>, String> getObjectAlias() {
		return objectAlias;
	}

	/**
	 * @see 设置字段名对应的简称
	 * @param clazz
	 * @param fieldName
	 * @param alias
	 */
	public void setFieldAlias(Class<?> clazz, String fieldName, String alias) {
		if (fieldAlias.containsKey(clazz)) {
			fieldAlias.get(clazz).put(fieldName, alias);
		} else {
			Map<String, String> map = new HashMap<String, String>();

			map.put(fieldName, alias);

			fieldAlias.put(clazz, map);
		}
	}

	/**
	 * @see 获取字段简称映射
	 * @return Map<Class<?>, Map<String, String>>
	 */
	public Map<Class<?>, Map<String, String>> getFieldAlias() {
		return fieldAlias;
	}

	/**
	 * @see 设置字段对应转换类
	 * @param clazz
	 * @param fieldName
	 * @param converter
	 */
	public void setFieldConvert(Class<?> clazz, String fieldName, SingleValueConverter converter) {
		if (fieldConverter.containsKey(clazz)) {
			fieldConverter.get(clazz).put(fieldName, converter);
		} else {
			Map<String, SingleValueConverter> map = new HashMap<String, SingleValueConverter>();

			map.put(fieldName, converter);

			fieldConverter.put(clazz, map);
		}
	}

	/**
	 * @see 获取字段转换类映射
	 * @return Map<Class<?>, Map<String, SingleValueConverter>>
	 */
	public Map<Class<?>, Map<String, SingleValueConverter>> getFieldConverter() {
		return fieldConverter;
	}

	/**
	 * @see 设置不进行序列化的字段
	 * @param clazz
	 * @param fieldName
	 */
	public void setExcludeField(Class<?> clazz, String fieldName) {
		excludeField.put(clazz, fieldName);
	}

	/**
	 * @see 获取不进行序列化的字段映射
	 * @return
	 */
	public Map<Class<?>, String> getExcludeField() {
		return excludeField;
	}

	/**
	 * @see 设置全局类对应的转换类
	 * @param converter
	 */
	public void setGlobalConverter(Converter converter) {
		globalConverter.add(converter);
	}

	/**
	 * @see 获取全剧类对应转换类集合
	 * @return List<Converter>
	 */
	public List<Converter> getGlobalConverter() {
		return globalConverter;
	}

	/**
	 * @see 清空所有配置
	 */
	public void clear() {
		packageAlias.clear();
		;

		objectAlias.clear();
		;

		fieldAlias.clear();
		;

		fieldConverter.clear();
		;

		excludeField.clear();
		;

		globalConverter.clear();
		;
	}

	/**
	 * @see 获取默认配置，尚未完善，但亦可使用
	 * @param clazz
	 * @return ObjectSerializeConfig
	 */
	public static ObjectSerializeConfig getDefaultSerializeConfig(Class<?> clazz) {
		ObjectSerializeConfig serializeConfig = new ObjectSerializeConfig();

		// 设置包简称
		serializeConfig.setPackageAlias(ObjectSerializeConfig.class.getPackage().getName(), ObjectSerializeConfig.class.getPackage().getName());

		// 设置类简称
		serializeConfig.setObjectAlias(clazz, StringUtil.firstLetterToLowerCase(clazz.getSimpleName()));

		// 设置字段简称及转换类
		// 后续完成此环节

		return serializeConfig;
	}

	public boolean isRemoveClass() {
		return removeClass;
	}

	public void setRemoveClass(boolean removeClass) {
		this.removeClass = removeClass;
	}

}
