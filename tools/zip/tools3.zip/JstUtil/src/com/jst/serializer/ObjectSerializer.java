package com.jst.serializer;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.jst.config.ObjectSerializeConfig;
import com.jst.serializer.converter.GlobalDateConverter;
import com.jst.type.DataType;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.converters.Converter;
import com.thoughtworks.xstream.converters.SingleValueConverter;
import com.thoughtworks.xstream.io.json.JettisonMappedXmlDriver;

/**
 * 
 * <p>
 * Title: ObjectSerializer.java
 * </p>
 * <p>
 * Description: 此类用于序列换及发序列化实体
 * </p>
 * 
 * @author lee
 * @date 2015年6月8日
 * @version 1.0
 */
public class ObjectSerializer {

	// 序列化后的字符串类型
	private DataType dataType;

	// 对象序列化配置
	private ObjectSerializeConfig serializeConfig;

	/**
	 * @see 创建实例
	 * @param dataType
	 */
	private ObjectSerializer(DataType dataType) {
		this.dataType = dataType;
	}

	/**
	 * @see 创建实例
	 * @param dataType
	 * @param serializeConfig
	 */
	private ObjectSerializer(DataType dataType, ObjectSerializeConfig serializeConfig) {
		this.dataType = dataType;
		this.serializeConfig = serializeConfig;
	}

	/**
	 * @see 获取XStream对象
	 * @param objectClass
	 * @return XStream
	 */
	private XStream _getXStream(Class<?> objectClass) {
		XStream xStream = dataType.equals(DataType.XML) ? new XStream() : dataType.equals(DataType.JSON) ? new XStream(new JettisonMappedXmlDriver()) : new XStream();

		// 判断设置是否为空
		serializeConfig = null == serializeConfig ? ObjectSerializeConfig.getDefaultSerializeConfig(objectClass) : serializeConfig;

		// 设置包简称
		Map<String, String> packageAlias = serializeConfig.getPackageAlias();

		for (Iterator<String> it = packageAlias.keySet().iterator(); it.hasNext();) {
			String packageName = it.next();
			String alias = packageAlias.get(packageName);

			xStream.aliasPackage(alias, packageName);
		}

		// 设置类简称
		Map<Class<?>, String> objectAlias = serializeConfig.getObjectAlias();

		for (Iterator<Class<?>> it = objectAlias.keySet().iterator(); it.hasNext();) {
			Class<?> clazz = it.next();

			xStream.alias(objectAlias.get(clazz), clazz);
		}

		Map<Class<?>, Map<String, String>> fieldAlias = serializeConfig.getFieldAlias();

		Map<Class<?>, Map<String, SingleValueConverter>> fieldConverter = serializeConfig.getFieldConverter();

		// 去除被排除的字段
		Map<Class<?>, String> excludeField = serializeConfig.getExcludeField();

		for (Iterator<Class<?>> it = excludeField.keySet().iterator(); it.hasNext();) {
			Class<?> clazz = it.next();
			String fieldName = excludeField.get(clazz);

			xStream.omitField(clazz, excludeField.get(clazz));

			if (fieldAlias.containsKey(clazz) && fieldAlias.get(clazz).containsKey(fieldName)) {
				fieldAlias.get(clazz).remove(fieldName);
			}

			if (fieldConverter.containsKey(clazz) && fieldConverter.get(clazz).containsKey(fieldName)) {
				fieldConverter.get(clazz).remove(fieldName);
			}

		}

		// 设置字段简称
		for (Iterator<Class<?>> it = fieldAlias.keySet().iterator(); it.hasNext();) {
			Class<?> clazz = it.next();

			Map<String, String> map = fieldAlias.get(clazz);

			for (Iterator<String> i = map.keySet().iterator(); i.hasNext();) {
				String fieldName = i.next();
				String alias = map.get(fieldName);

				xStream.aliasField(alias, clazz, fieldName);

				if (fieldConverter.containsKey(clazz) && fieldConverter.get(clazz).containsKey(fieldName)) {
					xStream.registerLocalConverter(clazz, fieldName, fieldConverter.get(clazz).get(fieldName));

					fieldConverter.get(clazz).remove(fieldName);
				}
			}
		}

		// 设置字段转换类
		for (Iterator<Class<?>> it = fieldConverter.keySet().iterator(); it.hasNext();) {
			Class<?> clazz = it.next();

			Map<String, SingleValueConverter> map = fieldConverter.get(clazz);

			for (Iterator<String> i = map.keySet().iterator(); i.hasNext();) {
				String fieldName = i.next();

				xStream.registerLocalConverter(clazz, fieldName, map.get(fieldName));
			}
		}

		// 设置全局转换类
		List<Converter> globalConverter = serializeConfig.getGlobalConverter();

		for (Converter converter : globalConverter) {
			xStream.registerConverter(converter);
		}

		// 去掉 class 属性
		if (serializeConfig.isRemoveClass()) {
			xStream.aliasSystemAttribute(null, "class");
		}

		xStream.registerConverter(new GlobalDateConverter("yyyy-MM-dd HH:mm:ss"));
		return xStream;
	}

	/**
	 * @see 序列化对象
	 * @param object
	 * @return String
	 */
	public String serialize(Object object) {
		return _getXStream(object.getClass()).toXML(object);
	}

	/**
	 * @see 反序列化对象
	 * @param objectClass
	 * @param objectString
	 * @return <T> T
	 */
	@SuppressWarnings("unchecked")
	public <T> T deserialize(Class<T> objectClass, String objectString) {
		return (T) _getXStream(objectClass).fromXML(objectString);
	}

	/**
	 * @see 创建实例
	 * @param dataType
	 * @return ObjectSerializer
	 */
	public static ObjectSerializer getInstance(DataType dataType) {
		return new ObjectSerializer(dataType);
	}

	/**
	 * @see 创建实例
	 * @param dataType
	 * @param serializeConfig
	 * @return ObjectSerializer
	 */
	public static ObjectSerializer getInstance(DataType dataType, ObjectSerializeConfig serializeConfig) {
		return new ObjectSerializer(dataType, serializeConfig);
	}

}
