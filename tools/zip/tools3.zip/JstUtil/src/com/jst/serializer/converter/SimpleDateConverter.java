package com.jst.serializer.converter;

import java.util.Date;

import com.thoughtworks.xstream.converters.basic.DateConverter;

/**
 * 
 * <p>Title: SimpleDateConverter.java</p>
 * <p>Description: 对象序列话日期类型字段转换类</p>
 * @author lee
 * @date 2015年6月30日
 * @version 1.0
 */
public class SimpleDateConverter extends DateConverter{

	@Override
	@SuppressWarnings("rawtypes")
	public boolean canConvert(Class clazz) {
		return null != clazz && Date.class.isAssignableFrom(clazz);
	}
	
}
