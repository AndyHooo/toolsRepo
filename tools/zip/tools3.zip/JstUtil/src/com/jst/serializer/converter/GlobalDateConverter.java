package com.jst.serializer.converter;

import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.jst.util.DateUtil;
import com.thoughtworks.xstream.converters.Converter;
import com.thoughtworks.xstream.converters.MarshallingContext;
import com.thoughtworks.xstream.converters.UnmarshallingContext;
import com.thoughtworks.xstream.io.HierarchicalStreamReader;
import com.thoughtworks.xstream.io.HierarchicalStreamWriter;

/**
 * 
 * <p>Title: GlobalDateConverter.java</p>
 * <p>Description: 对象序列化全局时间格式转换</p>
 * @author lee
 * @date 2015年6月30日
 * @version 1.0
 */
public class GlobalDateConverter implements Converter {

	//日志
	private static final Log log = LogFactory.getLog(GlobalDateConverter.class);
	
	//默认日期格式
	private static final String DEFAULT_PATTERN = "yyyy-MM-dd HH:mm:ss";
	
	//日期格式
	private String datePattern;
	
	@Override
	@SuppressWarnings("rawtypes")
	public boolean canConvert(Class clazz) {
		return null != clazz && Date.class.isAssignableFrom(clazz);
	}
	
	public GlobalDateConverter(String datePattern) {
		this.datePattern = datePattern;
	}

	@Override
	public void marshal(Object value, HierarchicalStreamWriter writer, MarshallingContext context) {
		try {
			writer.setValue(DateUtil.format((Date) value, null == datePattern ? DEFAULT_PATTERN : datePattern));
		} catch (Exception e) {
			log.error("marshal error: " + e);
		}
	}

	@Override
	public Object unmarshal(HierarchicalStreamReader reader, UnmarshallingContext context) {
		try {
			return DateUtil.parse(reader.getValue(), null == datePattern ? DEFAULT_PATTERN : datePattern);
		} catch (Exception e) {
			log.error("unmarshal error: " + e);
		}
		
		return null;
	}

}
