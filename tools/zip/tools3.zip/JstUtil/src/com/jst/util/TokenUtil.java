package com.jst.util;

import com.jst.model.Token;
import com.jst.util.DateUtil;
import com.jst.util.EncryptUtil;

public class TokenUtil {
	
	/**
	 * 返回token对象 包含 tokenId, random
	 * @param userCode
	 * @return
	 * @throws Exception
	 */
	public static Token grentTokenId(String userCode ) throws Exception{
		String time = DateUtil.format(DateUtil.getCurrentDate(),"yyyyMMddHHmmss");
		String randomStr = ((int)(Math.random()*1000001))+"";
		String random = EncryptUtil.encryptDES("szjst#168", randomStr);
		String enStr = userCode+"_"+randomStr+"_"+time;
		return new Token(EncryptUtil.encryptDES(random, enStr),random);
	}
	
	/**
	 * 返回用户代码， 及 该token 所使用的时间(秒)
	 * @param token
	 * @return
	 * @throws Exception
	 */
	public static String[] getUser(Token token) throws Exception{
		String enStr = token.getToken();
		String random = token.getRandom();
		String s = EncryptUtil.decryptDES(random, enStr);
		String[] info = s.split("_");
		String userCode= info[0];
		String time = info[2];
		int num = DateUtil.getDateDifference(DateUtil.getCurrentDate(), DateUtil.parse(time, "yyyyMMddHHmmss"), "second");
		return new String[]{userCode,num+""};
	}
	
}
