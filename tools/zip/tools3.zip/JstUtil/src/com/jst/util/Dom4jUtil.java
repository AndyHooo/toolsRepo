package com.jst.util;

import java.io.File;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSON;
import net.sf.json.xml.XMLSerializer;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.dom4j.Attribute;
import org.dom4j.Branch;
import org.dom4j.CDATA;
import org.dom4j.Comment;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.DocumentType;
import org.dom4j.Element;
import org.dom4j.Entity;
import org.dom4j.Namespace;
import org.dom4j.Node;
import org.dom4j.ProcessingInstruction;
import org.dom4j.Text;
import org.dom4j.io.SAXReader;

import com.jst.config.XMLSerializerConfig;

/**
 * 
 * <p>Title: Dom4jUtil.java</p>
 * <p>Description: 此工具类用于处理XML相关问题</p>
 * @author lee
 * @date 2015年5月15日
 * @version 1.0
 */
public class Dom4jUtil {
	
	//日志
	private static final Log log = LogFactory.getLog(Dom4jUtil.class);
	
	/**
	 * @see 解析XML文本
	 * @param text
	 * @return Document
	 * @throws Exception
	 */
	public static Document parseText(String text) throws DocumentException {
		try {
			return DocumentHelper.parseText(text);
		} catch (DocumentException e) {
			log.error("parseText error: " + e, e);
			
			throw new DocumentException("文档格式不正确，解析文档失败");
		}
	}
	
	/**
	 * @see 解析XML文件
	 * @param file
	 * @return Document
	 * @throws Exception
	 */
	public static Document parseFile(File file) throws DocumentException {
		try {
			return new SAXReader().read(file);
		} catch (DocumentException e) {
			log.error("parseFile error: " + e, e);
			
			throw e;
		}
	}
	
	/**
	 * @see 解析XML文件
	 * @param filePath
	 * @return Document
	 * @throws Exception
	 */
	public static Document parseFile(String filePath) throws DocumentException {
		try {
			return parseFile(new File(filePath));
		} catch (DocumentException e) {
			log.error("parseFile error: " + e, e);
			
			throw e;
		}
	}
	
	/**
	 * @see 创建文档
	 * @return Document
	 */
	public static Document createDocument() {
		return DocumentHelper.createDocument();
	}
	
	/**
	 * @see 创建文档
	 * @param rootElement
	 * @return Document
	 */
	public static Document createDocument(Element rootElement) {
		return DocumentHelper.createDocument(rootElement);
	}
	
	/**
	 * @see 创建文档
	 * @param rootName
	 * @return Document
	 */
	public static Document createDocument(String rootName) {
		return createDocument(createElement(rootName));
	}
	
	/**
	 * @see 创建元素
	 * @param elementName
	 * @return Element
	 */
	public static Element createElement(String elementName) {
		return DocumentHelper.createElement(elementName);
	}
	
	/**
	 * @see 添加元素
	 * @param parent
	 * @param children
	 */
	public static void appendElement(Branch parent, Node ... children) {
		for (Node child : children) {
			parent.add((Node) child.clone());
		}
	}
	
	/**
	 * @see 根据XPATH判断节点是否存在
	 * @param document
	 * @param nodePath
	 * @return boolean
	 */
	public static boolean hasNode(Node node, String nodePath) {
//		第一种判断方式
//		Object object = node.selectObject(nodePath);
//			
//		if(object instanceof Node || object instanceof ArrayList) {
//			return true;
//		} else {
//			return false;
//		}
		
//		第二种判断方式		
		return null != node.selectNodes(nodePath) && node.selectNodes(nodePath).size() > 0;
	}
	
	/**
	 * @see 根据XPATH判断节点是否存在
	 * @param xmlString
	 * @param nodePath
	 * @return boolean
	 * @throws Exception
	 */
	public static boolean hasNode(String xmlString, String nodePath) throws Exception {
		return hasNode(parseText(xmlString), nodePath);
	}
	
	/**
	 * @see 根据XPATH判断当前节点是否存在多个
	 * @param document
	 * @param nodePath
	 * @return boolean
	 */
	public static boolean hasMultiNode(Node node, String nodePath) {
//		第一种判断方式
//		Object object = parseText(xmlString).selectObject(nodePath);
//		
//		if(object instanceof ArrayList) {
//			return true;
//		} else {
//			return false;
//		}
		
//		第二种判断方式
		return null != node.selectNodes(nodePath) && node.selectNodes(nodePath).size() > 1;
	}
	
	/**
	 * @see 根据XPATH判断当前节点是否存在多个
	 * @param xmlString
	 * @param nodePath
	 * @return boolean
	 * @throws Exception
	 */
	public static boolean hasMultiNode(String xmlString, String nodePath) throws DocumentException {
		return hasMultiNode(parseText(xmlString), nodePath);
	}
	
	/**
	 * @see 判断当前节点是否存在子节点
	 * @param element
	 * @return boolean
	 */
	public static boolean hasChildNode(Node node) {
		return node.hasContent();
	}
	
	/**
	 * @see 判断当前元素子节点数量
	 * @param element
	 * @return int
	 */
	public static int getChildNodeCount(Element element) {
		return element.content().size();
	}
	
	/**
	 * @see 根据XPATH获取节点
	 * @param document
	 * @param nodePath
	 * @return Element
	 */
	public static Node getNode(Node node, String nodePath) {
		//0 任意节点 
		//Node.ANY_NODE
		
		//1 元素节点
		//Node.ELEMENT_NODE
		
		//2 属性节点
		//Node.ATTRIBUTE_NODE
		
		//3 文本节点
		//Node.TEXT_NODE
		
		//4 CDATA节点
		//Node.CDATA_SECTION_NODE
		
		//5 实体引用节点
		//Node.ENTITY_REFERENCE_NODE
		
		//7 处理指令节点
		//Node.PROCESSING_INSTRUCTION_NODE
		
		//8 注释节点
		//Node.COMMENT_NODE
		
		//9 文档节点
		//Node.DOCUMENT_NODE
		
		//10 文档类型节点
		//Node.DOCUMENT_TYPE_NODE
		
		//13 命名空间节点
		//Node.NAMESPACE_NODE
		
		//14 未知节点
		//Node.UNKNOWN_NODE
		
		//14 最大节点类型
		//Node.MAX_NODE_TYPE
		
		return node.selectSingleNode(nodePath);
	}
	
	/**
	 * @see 根据XPATH获取节点
	 * @param xmlString
	 * @param nodePath
	 * @return Element
	 * @throws DocumentException
	 */
	public static Node getNode(String xmlString, String nodePath) throws DocumentException {
		try {
			return getNode(parseText(xmlString), nodePath);
		} catch (DocumentException e) {
			log.error("getNode error: " + e, e);
			
			throw e;
		}
	}
	
	/**
	 * @see 获取当前节点的上一个节点
	 * @param node
	 * @return T
	 */
	@SuppressWarnings("unchecked")
	public static <T> T prevNode(Node node) {
		Element parent = node.getParent();
		
		if (null != parent) {
			int prevIndex = parent.indexOf(node) - 1;
			
			if (prevIndex >= 0) {
				return (T) parent.content().get(prevIndex);
			}
		}
		
		return null;
	}
	
	/**
	 * @see 获取当前节点的下一个节点
	 * @param node
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static <T> T nextNode(Node node) {
		Element parent = node.getParent();
		
		if (null != parent) {
			int nextIndex = parent.indexOf(node) + 1;
			
			if (nextIndex < parent.content().size()) {
				return (T) parent.content().get(nextIndex);
			}
		}
		
		return null;
	}
	
	/**
	 * @see 获取当前元素节点值
	 * @param element
	 * @return String
	 */
	@SuppressWarnings("unchecked")
	public static String getNodeValue(Node node) {
		//以下分类型做详细处理
		//尽管以下很多节点都可用node.getText()返回
		//但这样方便以后对不同类型节点做修改或扩展
		
		short nodeType = node.getNodeType();
		
		//元素节点
		if (nodeType == Node.ELEMENT_NODE) {
			Element element = (Element) node;
			
			if (element.hasContent()) {
				List<Node> list = element.content();
				
				StringBuffer buffer = new StringBuffer();
				
				for (Node n : list) {
					buffer.append(n.asXML());
				}
				
				return buffer.toString();
			}
		}
		
		//属性节点
		if (nodeType == Node.ATTRIBUTE_NODE) {
			Attribute attribute = (Attribute) node;
			
			return attribute.getText();
		}
		
		//文本节点
		if (nodeType == Node.TEXT_NODE) {
			Text text = (Text) node;
			
			return text.getText();
		}
		
		//CDATA节点
		if (nodeType == Node.CDATA_SECTION_NODE) {
			CDATA cdata = (CDATA) node;
			
			return cdata.getText();
		}
		
		//实体引用节点
		if (nodeType == Node.ENTITY_REFERENCE_NODE) {
			Entity entity = (Entity) node;
			
			return entity.getText();
		}
		
		//处理指令节点
		if (nodeType == Node.PROCESSING_INSTRUCTION_NODE) {
			ProcessingInstruction process = (ProcessingInstruction) node;
			
			return process.getText();
		}
		
		//注释节点
		if (nodeType == Node.COMMENT_NODE) {
			Comment comment = (Comment) node;
			
			return comment.getText();
		}
		
		//文档节点
		if (nodeType == Node.DOCUMENT_NODE) {
			Document document = (Document) node;
			
			return document.asXML();
		}
				
		//文档类型节点
		if (nodeType == Node.DOCUMENT_TYPE_NODE) {
			DocumentType docType = (DocumentType) node;
			
			return docType.getText();
		}
				
		//命名空间节点
		//Node.NAMESPACE_NODE
		if (nodeType == Node.NAMESPACE_NODE) {
			Namespace namespace = (Namespace) node;
			
			return namespace.getText();
		}
		
		return null;
	}
	
	/**
	 * @see 根据XPATH获取节点值
	 * @param element
	 * @param nodePath
	 * @return String
	 */
	public static String getNodeValue(Node node, String nodePath) {
		return getNodeValue(getNode(node, nodePath));
	}
	
	/**
	 * @see 根据XPATH获取节点值
	 * @param xmlString
	 * @param nodePath
	 * @return String
	 * @throws Exception
	 */
	public static String getNodeValue(String xmlString, String nodePath) throws DocumentException {
		return getNodeValue(parseText(xmlString), nodePath); 
	}
	
	/**
	 * @see 根据XPATH获取节点列表
	 * @param document
	 * @param nodePath
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static List<Node> getNodeList(Node node, String nodePath) {
		return node.selectNodes(nodePath);
	}
	
	/**
	 * @see 根据XPATH获取节点列表
	 * @param element
	 * @return List<Element>
	 */
	@SuppressWarnings("unchecked")
	public static List<Node> getChildNodeList(Element element) {
		return element.content();
	}
	
	/**
	 * @see 设置属性 
	 * @param element
	 * @param key
	 * @param value
	 */
	public static void addAttribute(Element element, String key, String value) {
		element.addAttribute(key, value);
	}
	
	/**
	 * @see 获取属性
	 * @param element
	 * @param key
	 * @return String
	 */
	public static String getAttributeValue(Element element, String key) {
		return element.attributeValue(key);
	}
	
	/**
	 * @see 获取所有属性
	 * @param element
	 * @return Map<String, String>
	 */
	public static Map<String, String> getAttributeMap(Element element) {
		Map<String, String> map = new HashMap<String, String>();
		
		if (0 == element.attributeCount()) {
			return map;
		}
		
		for (Object object : element.attributes()) {
			Attribute attribute = (Attribute) object;
			
			map.put(attribute.getName(), attribute.getValue());
		}
		
		return map;
	}
	
	/**
	 * @see XML转JSON
	 * @param xmlString
	 * @param config
	 * @return JSON
	 * @throws Exception
	 */
	@Deprecated
	public static JSON toJSON(String xmlString, XMLSerializerConfig config) throws Exception {
		XMLSerializer serializer = new XMLSerializer();
		
		if (null != config) {
			try {
				EntityUtil.cloneEntity(config, serializer);
			} catch (Exception e) {
				log.error("toJSON error: " + e, e);
				
				throw e;
			}
		}
		
		return serializer.read(xmlString);
	}
	
	/**
	 * @see XML转JSON
	 * @param file
	 * @param config
	 * @return JSON
	 * @throws Exception
	 */
	@Deprecated
	public static JSON toJSON(File file,  XMLSerializerConfig config) throws Exception {
		XMLSerializer serializer = new XMLSerializer();
		
		if (null != config) {
			try {
				EntityUtil.cloneEntity(config, serializer);
			} catch (Exception e) {
				log.error("toJSON error: " + e, e);
				
				throw e;
			}
		}
		
		return serializer.readFromFile(file);
	}
	
	/**
	 * @see XML转JSON
	 * @param inputStream
	 * @param config
	 * @return JSON
	 * @throws Exception
	 */
	@Deprecated
	public static JSON toJSON(InputStream inputStream,  XMLSerializerConfig config) throws Exception {
		XMLSerializer serializer = new XMLSerializer();
		
		if (null != config) {
			try {
				EntityUtil.cloneEntity(config, serializer);
			} catch (Exception e) {
				log.error("toJSON error: " + e, e);
				
				throw e;
			}
		}
		
		return serializer.readFromStream(inputStream);
	}
	
}