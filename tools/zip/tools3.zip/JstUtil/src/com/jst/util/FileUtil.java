package com.jst.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.URI;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * 
 * <p>Title: FileUtil.java</p>
 * <p>Description: 此工具类用于文件相关问题</p>
 * @author lee
 * @date 2015年5月28日
 * @version 1.0
 */
public class FileUtil {

	//日志
	private static final Log log = LogFactory.getLog(FileUtil.class);
	
	//缓冲区大小
	//private static final int BUFFER_SIZE = 5 * 1024 * 1024;
	
	/**
	 * @see 创建文件
	 * @param filePath
	 * @return File
	 */
	public static File createFile(String filePath) {
		return new File(filePath);
	}
	
	/**
	 * @see 创建文件
	 * @param uri
	 * @return File
	 */
	public static File createFile(URI uri) {
		return new File(uri);
	}
	
	/**
	 * @see 创建文件
	 * @param parentFile
	 * @param fileName
	 * @return File
	 */
	public static File createFile(File parentFile, String fileName) {
		return new File(parentFile, fileName);
	}
	
	/**
	 * @see 删除文件
	 * @param file
	 * @return boolean
	 */
	public static boolean deleteFile(File file) {
		return file.delete();
	}
	
	/**
	 * @see 删除文件
	 * @param filePath
	 * @return boolean
	 */
	public static boolean deleteFile(String filePath) {
		return deleteFile(createFile(filePath));
	}
	
	/**
	 * @see 删除文件
	 * @param uri
	 * @return boolean
	 */
	public static boolean deleteFile(URI uri) {
		return deleteFile(createFile(uri));
	}
	
//	public static byte[] toByteArray(File file) throws Exception {
//		FileInputStream fis = null;
//		FileChannel channel = null;
//		
//		ByteBuffer byteBuffer = null;
//		
//		byte[] byteArray = null;
//		
//		int length = 0;
//		int loop = 0;
//		
//		try {
//			fis = new FileInputStream(file);
//			channel = fis.getChannel();
//
//			byteArray = new byte[Long.valueOf(channel.size()).intValue()];
//			
//			byteBuffer = ByteBuffer.allocate(BUFFER_SIZE);
//			
//			while((length = channel.read(byteBuffer)) > 0) {
//				byteBuffer.flip();
//				System.arraycopy(byteBuffer.array(), 0, byteArray, BUFFER_SIZE * loop, length);
//				byteBuffer.clear();
//				
//				loop++;
//			}
//		} catch (Exception e) {
//			log.error("toByteArray error: " + e);
//			
//			throw e;
//		} finally {
//			channel.close();
//			fis.close();
//		}
//		
//		return byteArray;
//	}
	
	/**
	 * @see file转byte[], 不支持超大文件
	 * @param file
	 * @return  byte[]
	 * @throws Exception
	 */
	public static byte[] toByteArray(File file) throws Exception {
		FileInputStream fis = null;
		FileChannel channel = null;
		
		ByteBuffer byteBuffer = null;
		
		try {
			fis = new FileInputStream(file);
			channel = fis.getChannel();

			byteBuffer = ByteBuffer.allocate(Long.valueOf(channel.size()).intValue());
			
			channel.read(byteBuffer);
		} catch (Exception e) {
			log.error("toByteArray error: " + e);
			
			throw e;
		} finally {
			channel.close();
			fis.close();
		}
		
		return byteBuffer.array();
	}
	
	/**
	 * @see byte[]转file
	 * @param byteArray
	 * @param file
	 * @throws Exception
	 */
	public static void toFile(byte[] byteArray, File file) throws Exception {
		FileOutputStream fos = null;
		FileChannel channel = null;
		
		try {
			fos = new FileOutputStream(file);
			channel = fos.getChannel();
			
			channel.write(ByteBuffer.wrap(byteArray));
		} catch (Exception e) {
			log.error("toFile error: " + e);
			
			throw e;
		} finally {
			channel.close();
			fos.close();
		}
	}
	
	/**
	 * @see 复制文件
	 * @param source
	 * @param target
	 * @throws Exception
	 */
	public static void copyFile(File source, File target) throws Exception {
		FileInputStream fis = null;
		FileOutputStream fos = null;
		
		FileChannel inChannel = null;
		FileChannel outChannel = null;
		
		try {
			fis = new FileInputStream(source);
			fos = new FileOutputStream(target);
			
			inChannel = fis.getChannel();
			outChannel= fos.getChannel();
			
			inChannel.transferTo(0, inChannel.size(), outChannel);
		} catch (Exception e) {
			log.error("copyFile error: " + e);
			
			throw e;
		} finally {
			inChannel.close();
			fis.close();
			
			outChannel.close();
			fos.close();
		}
	}

}
