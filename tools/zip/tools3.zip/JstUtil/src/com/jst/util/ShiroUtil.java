package com.jst.util;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.apache.shiro.web.util.WebUtils;

/**
 * 
 * <p>Title: ShiroUtil.java</p>
 * <p>Description: 此工具类用于解决Shiro相关问题</p>
 * @author lee
 * @date 2015年6月16日
 * @version 1.0
 */
public class ShiroUtil {
	
	/**
	 * @see 获取当前Subject
	 * @return Subject
	 */
	public static Subject getSubject() {
		return SecurityUtils.getSubject();
	}
	
	/**
	 * @see 获取当前登陆的用户对象
	 * @return T
	 */
	@SuppressWarnings("unchecked")
	public static <T> T getCurrentUser() {
		return (T) SecurityUtils.getSubject().getPrincipal();
	}
	
	/**
	 * @see 获取当前登陆的用户对象
	 * @param entityClazz
	 * @return T
	 */
	@SuppressWarnings("unchecked")
	public static <T> T getCurrentUser(Class<T> entityClazz) {
		return (T) SecurityUtils.getSubject().getPrincipal();
	}
	
	/**
	 * @see 获取ServletRequest
	 * @return ServletRequest
	 */
	public static ServletRequest getServletRequest() {
		return WebUtils.getRequest(getSubject());
	}
	
	/**
	 * @see 获取HttpServletRequest
	 * @return HttpServletRequest
	 */
	public static HttpServletRequest getHttpRequest() {
		return WebUtils.getHttpRequest(getSubject());
	}
	
	/**
	 * @see 获取ServletResponse
	 * @return ServletResponse
	 */
	public static ServletResponse getServletResponse() {
		return WebUtils.getHttpResponse(getSubject());
	}
	
	/**
	 * @see 获取HttpServletResponse
	 * @return HttpServletResponse
	 */
	public static HttpServletResponse getHttpResponse() {
		return WebUtils.getHttpResponse(getSubject());
	}
}
