package com.jst.util;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * 
 * <p>Title: ByteUtil.java</p>
 * <p>Description: 此工具类用于处理字节及字节数组的相关问题</p>
 * @author lee
 * @date 2015年5月22日
 * @version 1.0
 */
public class ByteUtil {
	
	//日志
	@SuppressWarnings("unused")
	private static final Log log = LogFactory.getLog(ByteUtil.class);

	/**
	 * @see byte转换int
	 * @param b
	 * @return int
	 */
	public static int toInt(byte b) {
		return b & 0xFF;
	}
	
	/**
	 * @see int转换hex字符串
	 * @param i
	 * @return String
	 */
	public static String toHexString(int i) {
		return 1 == Integer.toHexString(i).length() ? "0" + Integer.toHexString(i) : Integer.toHexString(i);
	}
	
	/**
	 * @see byte转换hex字符串
	 * @param b
	 * @return String
	 */
	public static String toHexString(byte b) {
		return toHexString(toInt(b));
	}
	
	/**
	 * @see byte[]转换hex字符串
	 * @param bytes
	 * @return
	 */
	public static String toHexString(byte[] bytes) {
		String hexString = "";
		
		for(byte b : bytes) {
			hexString += toHexString(b);
		}
		
		return hexString;
	}
}
