package com.jst.util;

import java.util.Iterator;
import java.util.Map;

import javax.xml.namespace.QName;

import org.apache.axiom.om.OMAbstractFactory;
import org.apache.axiom.om.OMElement;
import org.apache.axis2.AxisFault;
import org.apache.axis2.addressing.EndpointReference;
import org.apache.axis2.client.Options;
import org.apache.axis2.client.async.AxisCallback;
import org.apache.axis2.rpc.client.RPCServiceClient;
import org.apache.axis2.transport.http.HTTPConstants;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.jst.constant.Message;

public class WebServiceUtil {

	//日志
	private static final Log log = LogFactory.getLog(WebServiceUtil.class);

	//默认配置
	private static final Options defaultOptions = new Options();
	
	static {
		//初始化defaultOptions
		defaultOptions.setProperty(HTTPConstants.HTTP_PROTOCOL_VERSION, HTTPConstants.HEADER_PROTOCOL_11);
		defaultOptions.setProperty(HTTPConstants.CHUNKED, Boolean.FALSE);
//		defaultOptions.setProperty(HTTPConstants.MC_GZIP_REQUEST, Boolean.TRUE);
//		defaultOptions.setProperty(HTTPConstants.MC_GZIP_RESPONSE, Boolean.TRUE);
//		defaultOptions.setProperty(HTTPConstants.MC_ACCEPT_GZIP, Boolean.TRUE);
//		defaultOptions.setProperty(HTTPConstants.COMPRESSION_GZIP, Boolean.TRUE);
		defaultOptions.setProperty(HTTPConstants.HTTP_METHOD, Message.HTTP_METHOD.equals(HTTPConstants.HTTP_METHOD_POST) ? HTTPConstants.HTTP_METHOD_POST : (Message.HTTP_METHOD.equals(HTTPConstants.HTTP_METHOD_GET) ? HTTPConstants.HTTP_METHOD_GET : HTTPConstants.HTTP_METHOD_POST));
		defaultOptions.setProperty(HTTPConstants.CHAR_SET_ENCODING, Message.ENCODING);
//		defaultOptions.setProperty(Configuration.CHARACTER_SET_ENCODING, StringUtil.DEFAULT_ENCODING);
//		defaultOptions.setProperty(HTTPConstants.CONNECTION_TIMEOUT, Message.CONNECTION_TIMEOUT);
		defaultOptions.setTimeOutInMilliSeconds(Message.CONNECTION_TIMEOUT);
		
	}
	
	@SuppressWarnings({ "unchecked", "unused" })
	private static void _parseParameterMap(Map<String, Object> map, OMElement element) throws Exception {
		try {
			for (Iterator<String> it = map.keySet().iterator(); it.hasNext();) {
				String key = it.next();
				
				Object value = map.get(key);
				
				OMElement e = OMAbstractFactory.getOMFactory().createOMElement(key, null);
				
				if (value instanceof Map) {
					_parseParameterMap((Map<String, Object>) value, e);
				} else if (value instanceof String) {
					e.setText(String.valueOf(value));
				} else {
					throw new Exception("wrong value type");
				}
				
				element.addChild(e);
			}
		} catch (Exception e) {
			log.error("_parseParameterMap error: " + e);
			
			throw e;
		}
	}
	
	public static Options getDefaultOptions() {
		Options options = new Options();
		
		options.setProperties(defaultOptions.getProperties());
		
		return options;
	}
	
	/**
	 * @see 调用WebService接口
	 * @param options
	 * @param header
	 * @param method
	 * @param synchronous
	 * @param callback
	 * @return String
	 * @throws AxisFault
	 */
	public static OMElement invokeInterface(Options options, OMElement header, OMElement method, boolean synchronous, AxisCallback callback) throws AxisFault {
		RPCServiceClient client = new RPCServiceClient();
		
		try {
			client.setOptions(options);
			
			if (null != header) {
				client.addHeader(header);
			}
			
			if (synchronous) {
				return client.sendReceive(method);
			} else {
				client.sendReceiveNonBlocking(method, callback);
			}
		} catch (AxisFault e) {
			log.error("invokeInterface error: " + e);
			
			throw e;
		} finally {
			client.cleanup();
		}
		
		return null;
	}
	
	/**
	 * @see 调用WebService接口, 使用默认配置
	 * @param serviceUrl
	 * @param header
	 * @param method
	 * @param synchronous
	 * @param callback
	 * @return
	 * @throws AxisFault
	 */
	public static OMElement invokeInterface(String serviceUrl, OMElement header, OMElement method, boolean synchronous, AxisCallback callback) throws AxisFault {
		defaultOptions.setTo(new EndpointReference(serviceUrl));
		
		try {
			return invokeInterface(defaultOptions, header, method, synchronous, callback);
		} catch (AxisFault e) {
			log.error("invokeInterface error: " + e);
			
			throw e;
		}
	}
	
	/**
	 * @see 调用WebService接口
	 * @param options
	 * @param targetNamespace
	 * @param interfaceName
	 * @param header
	 * @param paramValues
	 * @param returnType
	 * @param synchronous
	 * @param callback
	 * @return Object[]
	 * @throws AxisFault
	 */
	@SuppressWarnings("rawtypes")
	public static Object[] invokeInterface(Options options, String targetNamespace, String interfaceName, OMElement header, Object[] paramValues, Class[] returnType, boolean synchronous, AxisCallback callback) throws AxisFault {
		RPCServiceClient client = new RPCServiceClient();
		
		try {
			client.setOptions(options);
			
			if (null != header) {
				client.addHeader(header);
			}
			
			QName qName = new QName(targetNamespace, interfaceName);
			
			if (synchronous) {
				return client.invokeBlocking(qName, paramValues, returnType);
			} else {
				client.invokeNonBlocking(qName, paramValues, callback);
			}
		} catch (AxisFault e) {
			log.error("invokeInterface error: " + e);
			
			throw e;
		} finally {
			client.cleanup();
		}
	    client.cleanup();
		
		return null;
	}
	
	
	/**
	 * @see 调用WebService接口, 使用默认配置
	 * @param serviceUrl
	 * @param targetNamespace
	 * @param interfaceName
	 * @param header
	 * @param paramValues
	 * @param returnType
	 * @param synchronous
	 * @param callback
	 * @return Object[]
	 * @throws AxisFault
	 */
	@SuppressWarnings("rawtypes")
	public static Object[] invokeInterface(String serviceUrl, String targetNamespace, String interfaceName, OMElement header, Object[] paramValues, Class[] returnType, boolean synchronous, AxisCallback callback) throws AxisFault {
		defaultOptions.setTo(new EndpointReference(serviceUrl));
		
		try {
			return invokeInterface(defaultOptions, targetNamespace, interfaceName, header, paramValues, returnType, synchronous, callback);
		} catch (AxisFault e) {
			log.error("invokeInterface error: " + e);
			
			throw e;
		}
	}
	
}
