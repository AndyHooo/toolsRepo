package com.jst.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * 
 * <p>Title: ShortMessageUtil.java</p>
 * <p>Description: 此工具类用于收发短信</p>
 * @author lee
 * @date 2015年6月24日
 * @version 1.0
 */
public class ShortMessageUtil {
	
	//日志
	private static final Log log = LogFactory.getLog(ShortMessageUtil.class);
	
	//收发短信地址
	private static final String MESSAGE_URL;
	
	//用户、密码
	private static final String UID;
	private static final String PSW;
	
	//收发短信操作代码
	private static final String SEND_CMD;
	private static final String RECEIVE_CMD;
	
	//收发短信返回代码
	private static final Map<String, String> sendRetCode = new HashMap<String, String>();
	private static final Map<String, String> receiveRetCode = new HashMap<String, String>();
	
	//URL加码字符集
	private static final String ENCODING = StringUtil.GBK;
	
	//收发短信操作成功代码
	private static final String OPE_SUCCESS = "100";
	
	//响应成功代码
	private static final int RESPONSE_SUCCESS = 200;
	
	public static final String SUCCESS = "T";
	public static final String FAILURE = "F";
	
	static {
		log.debug("begin load message configuration");
		
		MESSAGE_URL = PropertyUtil.getPropertyValue("message.url");
		
		UID = PropertyUtil.getPropertyValue("message.uid");
		PSW = PropertyUtil.getPropertyValue("message.psw");
		
		SEND_CMD = PropertyUtil.getPropertyValue("message.send.cmd");
		
		//XXX:XXX;XXX:XXX;...
		for (String keyValue : PropertyUtil.getPropertyValue("message.send.retCode").split(";")) {
			String[] keyValueArray = keyValue.split(":");
			
			sendRetCode.put(keyValueArray[0], keyValueArray[1]);
		}
		
		RECEIVE_CMD = PropertyUtil.getPropertyValue("message.receive.cmd");
		
		//XXX:XXX;XXX:XXX;...
		for (String keyValue : PropertyUtil.getPropertyValue("message.receive.retCode").split(";")) {
			String[] keyValueArray = keyValue.split(":");
			
			receiveRetCode.put(keyValueArray[0], keyValueArray[1]);
		}
		
		log.debug("end load message configuration");
	}
	
	/**
	 * @see 获取基本URL
	 * @return URL
	 * @throws MalformedURLException
	 */
	private static URL _getURL() throws MalformedURLException {
		return new URL(MESSAGE_URL + "?uid=" + UID + "&psw=" + PSW);
	}
	
	/**
	 * @see 获取发送短信的URL
	 * @param msgid
	 * @param mobile
	 * @param content
	 * @return URL
	 * @throws Exception
	 */
	private static URL _getSendURL(int msgid, String mobile, String content) throws Exception {
		return new URL(_getURL() + "&cmd=" + SEND_CMD + "&msgid=" + msgid + "&mobiles=" + mobile + "&msg=" + EncryptUtil.encryptURL(content, ENCODING));
	}
	
	/**
	 * @see 获取接收短信的URL
	 * @return URL
	 * @throws MalformedURLException
	 */
	private static URL _getReceiveURL() throws MalformedURLException {
		return new URL(_getURL() + "&cmd=" + RECEIVE_CMD);
	}
	
	/**
	 * @see 发送短信
	 * @param mobile
	 * @param content
	 * @return String[]
	 * @throws Exception
	 */
	public static String[] sendMessage(String mobile, String content) throws Exception {
		HttpURLConnection connection = null;
		
		BufferedReader br = null;
		
		try {
			URL url = _getSendURL(content.length(), mobile, content);
			
			connection = (HttpURLConnection) url.openConnection();
			
			int responseCode = connection.getResponseCode();
			String responseMessage = connection.getResponseMessage();
			
			if (RESPONSE_SUCCESS == responseCode) {
				br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
				
				String retMsg = "";
				
				String tempString = null;
				
				while (null != (tempString = br.readLine())) {
					retMsg += tempString;
				}
				
				if (retMsg.equals(OPE_SUCCESS)) {
					return new String[]{SUCCESS, sendRetCode.get(retMsg)};
				} else {
					if (sendRetCode.containsKey(retMsg)) {
						return new String[]{FAILURE, sendRetCode.get(retMsg)};
					} else {
						return new String[]{FAILURE, "未知返回代码" + retMsg};
					}
				}
			} else {
				return new String[]{FAILURE, "响应代码：" + responseCode + " 响应信息：" + responseMessage};
			}
		} catch (MalformedURLException e) {
			log.error("analyze send url error: " + e);
			
			throw e;
		} catch (IOException e) {
			log.error("open connection error: " + e);
			
			throw e;
		} finally {
			if (null != br) {
				br.close();
			}
			
			if (null != connection) {
				connection.disconnect();
			}
		}
	}
	
	/**
	 * @see 接收短信
	 * @return String[]
	 * @throws Exception
	 */
	public static String[] receiveMessage() throws Exception {
		HttpURLConnection connection = null;
		
		BufferedReader br = null;
		
		try {
			URL url = _getReceiveURL();
			
			connection = (HttpURLConnection) url.openConnection();
			
			int responseCode = connection.getResponseCode();
			String responseMessage = connection.getResponseMessage();
			
			if (RESPONSE_SUCCESS == responseCode) {
				br = new BufferedReader(new InputStreamReader(connection.getInputStream(), ENCODING));
				
				//有回复短信
				//操作代码6#时间#手机#UID#内容6#时间#手机#UID#内容#6...
				//1006#20150625104539#18688888888#szjp#回复内容
				//无回复短信
				//101
				String retMsg = "";
				
				String tempString = null;
				
				while (null != (tempString = br.readLine())) {
					retMsg += tempString;
				}
				
				String retCode = retMsg.substring(0, 3);
				
				if (retCode.equals(OPE_SUCCESS)) {
					//此处返回的回复短信内容未做任何处理，后续优化
					return new String[]{SUCCESS, retMsg.substring(3)};
				} else {
					if (receiveRetCode.containsKey(retCode)) {
						return new String[]{FAILURE, receiveRetCode.get(retCode)};
					} else {
						return new String[]{FAILURE, "未知返回代码" + retCode};
					}
				}
			} else {
				return new String[]{FAILURE, "响应代码：" + responseCode + " 响应信息：" + responseMessage};
			}
		} catch (MalformedURLException e) {
			log.error("analyze send url error: " + e);
			
			throw e;
		} catch (IOException e) {
			log.error("open connection error: " + e);
			
			throw e;
		} finally {
			if (null != br) {
				br.close();
			}
			
			if (null != connection) {
				connection.disconnect();
			}
		}
	}
	
}
