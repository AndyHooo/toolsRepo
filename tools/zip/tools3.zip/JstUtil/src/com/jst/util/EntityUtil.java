package com.jst.util;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.jst.util.ReflectUtil;
import com.jst.util.StringUtil;

/**
 * 
 * <p>Title: EntityUtil.java</p>
 * <p>Description: 此处理类用于处理实体类相关问题</p>
 * @author lee
 * @date 2015年5月20日
 * @version 1.0
 */
public class EntityUtil {
	
	//日志
	private static final Log log = LogFactory.getLog(EntityUtil.class);
	
	//get方法前缀
	public static final String GET_METHOD_PREFIX = "get";
	
	//set方法前缀
	public static final String SET_METHOD_PREFIX = "set";
	
	/**
	 * @see 判断实体是否为可持久化实体
	 * @param entity
	 * @return boolean
	 */
	public static boolean isEntity(Object entity) {
		return ReflectUtil.hasAnnotation(entity.getClass(), Entity.class);
	}
	
	/**
	 * @see 判断实体对象是否已缓存
	 * @param object
	 * @return boolean
	 */
	public static boolean isCacheable(Object entity) {
		return ReflectUtil.hasAnnotation(entity.getClass(), Cacheable.class);
	}
	
	/**
	 * @see 获取实体类中所有字段
	 * @param entity
	 * @return Field[]
	 */
	public static Field[] getFields(Object entity) {
		return ReflectUtil.getDeclaredFields(entity.getClass());
	}
	
	/**
	 * @see 根据方法名获取字段名
	 * @param methodName
	 * @return String
	 */
	public static String getFieldName(String methodName) {
		if(methodName.startsWith(SET_METHOD_PREFIX)) {
			return methodName.substring(methodName.indexOf(SET_METHOD_PREFIX) + SET_METHOD_PREFIX.length());
		}
		
		if(methodName.startsWith(GET_METHOD_PREFIX)) {
			return methodName.substring(methodName.indexOf(GET_METHOD_PREFIX) + GET_METHOD_PREFIX.length());
		}
		
		return null;
	}
	
	/**
	 * @see 根据实体类及列名获取字段名
	 * @param entityClass
	 * @param columnName
	 * @return String
	 */
	public static String getFieldName(Object entity, String columnName) {
		for(Method method : ReflectUtil.getMethods(entity.getClass())) {
			if(ReflectUtil.hasAnnotation(method, Column.class) && columnName.toLowerCase().equals(method.getAnnotation(Column.class).name().toLowerCase())) {
				return StringUtil.firstLetterToLowerCase(getFieldName(method.getName()));
			}
		}
		
		return null;
	}
	
	/**
	 * @see 获取字段类型
	 * @param entityClass
	 * @param fieldName
	 * @return Class<?>
	 * @throws Exception
	 */
	public static Class<?> getFieldType(Object entity, String fieldName) {
		return ReflectUtil.getFieldType(entity.getClass(), fieldName);
	}
	
	/**
	 * @see 获取字段值
	 * @param entity
	 * @param fieldName
	 * @return Object
	 * @throws Exception
	 */
	public static Object getFieldValue(Object entity, String fieldName) throws Exception {
		try{
			return ReflectUtil.executeMethod(ReflectUtil.getMethod(entity.getClass(), getMethodName(GET_METHOD_PREFIX, fieldName)), entity);
		}catch(Exception e){
			log.error("getFieldValue error: " + e);
			
			throw e;
		}
	}
	
	public static void setFieldValue(Method method, Object entity, Object fieldValue) throws Exception {
		ReflectUtil.executeMethod(method, entity, fieldValue);
	}
	
	/**
	 * @see 设置字段值
	 * @param entity
	 * @param fieldName
	 * @param fieldValue
	 * @throws Exception
	 */
	public static void setFieldValue(Object entity, String fieldName, Object fieldValue) throws Exception {
		try {
			setFieldValue(ReflectUtil.getMethod(entity.getClass(), getMethodName(SET_METHOD_PREFIX, fieldName), getFieldType(entity, fieldName)), entity, fieldValue);
		} catch (Exception e) {
			log.error("getFieldValue error: " + e);
			
			throw e;
		}
	}
	
	/**
	 * @see 根据方法前缀及字段名获取方法名
	 * @param methodPrefix
	 * @param fieldName
	 * @return String
	 */
	public static String getMethodName(String methodPrefix, String fieldName){
		return methodPrefix + StringUtil.firstLetterToUpperCase(fieldName); 
	}
	
	/**
	 * @see 获取实体对应表名
	 * @param entityClass
	 * @return String
	 */
	public static String getTableName(Object entity) {
		return ReflectUtil.getAnnotation(entity.getClass(), Table.class).name();
	}
	
	/**
	 * @see 获取实体的主键名
	 * @param entity
	 * @return String
	 * @throws Exception
	 */
	public static String getPrimaryKeyName(Object entity) {
		for(Method method : ReflectUtil.getMethods(entity.getClass())){
			String methodName = method.getName();
			
			if(methodName.startsWith(SET_METHOD_PREFIX)){
				continue;
			}
			
			if(method.isAnnotationPresent(Id.class)){
				return getColumnName(method);
			}
		}
		
		return null;
	}
	
	/**
	 * @see 获取实体的主键值
	 * @param entity
	 * @return String
	 * @throws Exception
	 */
	public static String getPrimaryKeyValue(Object entity) throws Exception {
		try {
			for(Method method : entity.getClass().getDeclaredMethods()){
				String methodName = method.getName();
				
				if(methodName.startsWith(SET_METHOD_PREFIX)){
					continue;
				}
				
				if(method.isAnnotationPresent(Id.class)){
					return String.valueOf(ReflectUtil.executeMethod(method, entity));
				}
			}
		} catch (Exception e) {
			log.error("getPrimaryKeyValue error: " + e);
			
			throw e;
		}
		
		return null;
	}
	
	/**
	 * @see 根据方法获取列名
	 * @param method
	 * @return String
	 */
	public static String getColumnName(Method method){
		return ReflectUtil.getAnnotation(method, Column.class).name();
	}
	
	/**
	 * @see 根据字段名获取列名
	 * @param entity
	 * @param fieldName
	 * @return String
	 * @throws Exception
	 */
	public static String getColumnName(Object entity, String fieldName) {
		return getColumnName(ReflectUtil.getMethod(entity.getClass(), getMethodName(GET_METHOD_PREFIX, fieldName)));
	}
	
	/**
	 * @see 说明：将实体各属性的值克隆至目标实体,仅克隆属性,各指针指向独立内存地址
	 *      条件：两个具有完全相同属性的实体或同一实体类的不同实例
	 * @param src
	 * @param target
	 */
	public static void cloneEntity(Object src, Object target) throws Exception {
		try{
			Method[] srcMethods = ReflectUtil.getMethods(src.getClass());
			
			for(Method srcMethod : srcMethods) {
				if(srcMethod.getName().startsWith(SET_METHOD_PREFIX)){
					continue;
				}
				
				setFieldValue(target, getFieldName(srcMethod.getName()), srcMethod.invoke(src));
			}
		}catch(Exception e){
			log.error("cloneEntity error: " + e);
			
			throw e;
		}
	}
	
	/**
	 * @see 克隆实体所有属性，并返回该实体类新的实例
	 * @param src
	 * @return Object
	 * @throws Exception
	 */
	public static Object cloneEntity(Object src) throws Exception{
		Object target = null;
		
		try{
			target = ReflectUtil.getInstance(src.getClass());
			
			cloneEntity(src, target);
		}catch(Exception e){
			log.error("cloneEntity error: " + e);
			
			throw e;
		}
		
		return target;
	}
	
	/**
	 * @see 将目标实体个属性克隆至目标实体,部分或完全克隆
	 * @param src
	 * @param target
	 * @throws Exception
	 */
	public static void clonePart(Object src, Object target) throws Exception{
		
		try{
			Method[] srcMethods = src.getClass().getDeclaredMethods();
			
			for(Method srcMethod : srcMethods){
				String methodName = srcMethod.getName();
				
				if(methodName.startsWith(SET_METHOD_PREFIX)){
					continue;
				}
				
				if(ReflectUtil.hasMethod(target.getClass(), methodName)){
					setFieldValue(target, getFieldName(srcMethod.getName()), srcMethod.invoke(src));
				}
			}
		}catch(Exception e){
			log.error("clonePart error: " + e);
			
			throw e;
		}
	}
}
