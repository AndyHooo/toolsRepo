package com.jst.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * 
 * <p>Title: PropertyUtil.java</p>
 * <p>Description: 此工具类用于获取配置文件中的配置信息, 稍后完善过期策略与实时读取</p>
 * @author lee
 * @date 2015年5月30日
 * @version 1.0
 */
public class PropertyUtil {
	
	//日志
	private static final Log log = LogFactory.getLog(PropertyUtil.class);
	
	//配置信息
	private static final Map<String, String> _properties = new Hashtable<String, String>();
	
	static {
		log.debug("begin load configuration file");
		
		_setProperties();
		
		log.debug("end load configuration file");
	}
	
	/**
	 * @see 获取Properties
	 * @param fileName
	 * @return Properties
	 * @throws IOException
	 */
	private static Properties _getProperties(String fileName) throws IOException {
		Properties properties = new Properties();
		
		InputStream inStream = PropertyUtil.class.getResourceAsStream(fileName);
		
		try {
			properties.load(inStream);
		} catch (IOException e) {
			log.error("load properties error: " + e);
			
			throw e;
		} finally {
			inStream.close();
		}
		
		return properties;
	}
	
	/**
	 * @see 设置默认Properties 
	 */
	private static void _setProperties() {
		try {
//			File classes = FileUtil.createFile(PropertyUtil.class.getClassLoader().getResource("/").toURI());
//			
//			//以下代码先简单实现，后续以FilenameFilter及RegEx实现
//			for (File file : classes.listFiles()) {
//				if (file.isDirectory() || file.getName().startsWith("log4j") || !file.getName().endsWith(".properties")) {
//					continue;
//				}
//				
//				log.debug("loading file: " + file.getName());
//				
//				Properties properties = _getProperties(file.getName());
//				
//				String key = null;
//				
//				log.debug("save properties");
//				
//				for (Enumeration<Object> e = properties.keys(); e.hasMoreElements();) {
//					key = (String) e.nextElement();
//					
//					_properties.put(key, new String(properties.getProperty(key).getBytes(StringUtil.ISO_8859_1), StringUtil.UTF_8));
//				}
//			}
			
			Properties properties = _getProperties("/config.properties");
			
			String key = null;
			
			log.debug("save properties");
			
			for (Enumeration<Object> e = properties.keys(); e.hasMoreElements();) {
				key = (String) e.nextElement();
				
				_properties.put(key, new String(properties.getProperty(key).getBytes(StringUtil.ISO_8859_1), StringUtil.UTF_8));
			}
		} catch (Exception e) {
			log.error("set properties error: " + e);
		}
	}

	/**
	 * @see 读取配置文件属性
	 * @param propertyName
	 * @return String
	 */
	public static String getPropertyValue(String propertyName) {
		return _properties.get(propertyName);
	}

	/**
	 * @see 读取配置文件属性
	 * @param fileName
	 * @param propertyName
	 * @return
	 * @throws IOException
	 */
	public static String getPropertyValue(String fileName, String propertyName) throws IOException {
		try {
			return _getProperties(fileName).getProperty(propertyName);
		} catch (IOException e) {
			log.error("get property value error: " + e);
			
			throw e;
		}
	}
	
}
