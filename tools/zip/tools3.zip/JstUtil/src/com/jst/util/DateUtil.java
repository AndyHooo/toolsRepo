package com.jst.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * 
 * <p>Title: DateUtil.java</p>
 * <p>Description: 此工具类用于处理时间日期相关问题</p>
 * @author lee
 * @date 2015年5月13日
 * @version 1.0
 */
public class DateUtil {
	
	//日志
	private static final Log log = LogFactory.getLog(DateUtil.class);
	
	//日期常用格式化格式
	public static final String DATE_PATTERN_1 = "yyyyMMdd";
	public static final String DATE_PATTERN_2 = "yyyy-MM-dd";
	
	//时间常用格式化格式
	public static final String TIME_PATTERN_1 = "HHmmss";
	public static final String TIME_PATTERN_2 = "HH:mm:ss";
	
	//全日期常用格式化格式
	public static final String TIMESTAMPS_PATTERN_1 = "yyyyMMddHHmmss";
	public static final String TIMESTAMPS_PATTERN_2 = "yyyy-MM-dd HH:mm:ss";
	
	//每秒的毫秒数
	public static final long secondMs = 1000;
	
	//每分钟的毫秒数
	public static final long minuteMs = 60 * secondMs;
	
	//每小时的毫秒数
	public static final long hourMs = 60 * minuteMs;
	
	//每天的毫秒数
	public static final long dayMs = 24 * hourMs;
	
	//每月的毫秒数
	public static final long monthMs = 30 * dayMs;
	
	//每年的毫秒数
	public static final long yearMs = 12 * monthMs;
	
	//年
	private static final int YEAR = Calendar.YEAR;
	
	//月
	private static final int MONTH = Calendar.MONTH;
	
	//日
	private static final int DAY = Calendar.DAY_OF_MONTH;
	
	//时
	private static final int HOUR = Calendar.HOUR_OF_DAY;
	
	//分
	private static final int MINUTE = Calendar.MINUTE;
	
	//秒
	private static final int SECOND = Calendar.SECOND;
	
	/**
	 * @see 获取系统当前时间
	 * @return Date
	 */
	public static Date getCurrentDate() {
		return new Date();
	}
	
	/**
	 * @see 获取Calendar实例
	 * @return Calendar
	 */
	public static Calendar getCalendar() {
		return Calendar.getInstance();
	}
	
	/**
	 * @see 获取日期的年月日时分秒数组
	 * @param date
	 * @return int[]
	 */
	public static int[] getDateArray(Date date) {
		Calendar c = getCalendar();
		
		return new int[]{c.get(YEAR), c.get(MONTH) + 1, c.get(DAY), c.get(HOUR), c.get(MINUTE), c.get(SECOND)};
	}
	
	/**
	 * @see 获取年
	 * @param date
	 * @return int
	 */
	public static int getYear(Date date) {
		return getCalendar().get(YEAR);
	}
	
	/**
	 * @see 获取月
	 * @param date
	 * @return int
	 */
	public static int getMonth(Date date) {
		return getCalendar().get(MONTH) + 1;
	}
	
	/**
	 * @see 获取日
	 * @param date
	 * @return int
	 */
	public static int getDay(Date date) {
		return getCalendar().get(DAY);
	}
	
	/**
	 * @see 获取时
	 * @param date
	 * @return int
	 */
	public static int getHour(Date date) {
		return getCalendar().get(HOUR);
	}
	
	/**
	 * @see 获取分
	 * @param date
	 * @return int
	 */
	public static int getMinute(Date date) {
		return getCalendar().get(MINUTE);
	}
	
	/**
	 * @see 获取秒
	 * @param date
	 * @return int
	 */
	public static int getSecond(Date date) {
		return getCalendar().get(SECOND);
	}
	
	/**
	 * @see 按指定格式将时间转换为字符串
	 * @param date
	 * @param datePattern
	 * @return String
	 * @throws Exception
	 */
	public static String format(Date date, String datePattern) throws Exception {
		try {
			return new SimpleDateFormat(datePattern).format(date);
		} catch (Exception e) {
			log.error("format error: " + e);
			
			throw e;
		}
	}
	
	/**
	 * @see 按指定格式将毫秒转换为字符串
	 * @param millisecond
	 * @param datePattern
	 * @return String
	 * @throws Exception
	 */
	public static String format(long millisecond, String datePattern) throws Exception {
		return format(parse(millisecond), datePattern);
	}
	
	/**
	 * @see 按指定格式将字符串转换为时间
	 * @param dateString
	 * @param datePattern
	 * @return Date
	 * @throws Exception
	 */
	public static Date parse(String dateString, String datePattern) throws Exception {
		try {
			return new SimpleDateFormat(datePattern).parse(dateString);
		} catch(Exception e) {
			log.error("parse error: " + e);
			
			throw e;
		}
	}
	
	/**
	 * @see 将毫秒转换为日期
	 * @param millisecond
	 * @return Date
	 */
	public static Date parse(long millisecond) {
//		Calendar calendar = getCalendar();
//		
//		calendar.setTimeInMillis(millisecond);
//		
//		return calendar.getTime();
		
		return new Date(millisecond);
	}
	
	/**
	 * @see 按所需差值类型返回两个日期的差值
	 *      差值类型分为：年（year）月（month）日（day）时（hour）分（minute）秒（second）
	 * @param startDate
	 * @param endDate
	 * @param returnType
	 * @return long
	 */
	public static int getDateDifference(Date date1, Date date2, String differenceType) {
		long difference = 0;
		
		switch(differenceType){
		case "year": difference = Math.abs(date1.getTime() - date2.getTime()) / yearMs; break;
		case "month": difference = Math.abs(date1.getTime() - date2.getTime()) / monthMs; break;
		case "day": difference = Math.abs(date1.getTime() - date2.getTime()) / dayMs; break;
		case "hour": difference = Math.abs(date1.getTime() - date2.getTime()) / hourMs; break;
		case "minute": difference = Math.abs(date1.getTime() - date2.getTime()) / minuteMs; break;
		case "second": difference = Math.abs(date1.getTime() - date2.getTime()) / secondMs; break;
		default: difference = 0;
		}
		
		return Long.valueOf(difference).intValue();
	}
	
	/**
	 * @see 根据不同类型获得传入日期与量值相加减后的日期
	 * 		类型分为：年（year）月（month）日（day）时（hour）分（minute）秒（second）
	 * @param date
	 * @param type
	 * @param amount
	 * @return Date
	 */
	public static Date getNeedDay(Date date, String type, int amount) {
		if(0 == amount) {
			return date;
		}
		
		Calendar calendar = getCalendar();
		
		int field = 0;
		
		calendar.setTime(date);
		
		switch(type){
		case "year": field = Calendar.YEAR; break;
		case "month": field = Calendar.MONTH; break;
		case "day": field = Calendar.DAY_OF_MONTH; break;
		case "hour": field = Calendar.HOUR_OF_DAY; break;
		case "minute": field = Calendar.MINUTE; break;
		case "second": field = Calendar.SECOND; break;
		default: field = Calendar.DAY_OF_MONTH;
		}
		
		calendar.add(field, amount);
		
		return calendar.getTime();
	}
	
	/**
	 * @see 获取两个日期的区间数组
	 * @param date1
	 * @param date2
	 * @return
	 * @throws Exception
	 */
	public static Date[] getDateInterval(Date date1, Date date2) {
		Date startDate = null;
		Date endDate = null;
		
		int difference = 0;
		
		Date[] dateArray = null;
		
		Calendar calendar = null;
		
		if(date1.compareTo(date2) == 1) {
			startDate = date2;
			endDate = date1;
		} else if(date1.compareTo(date2) == -1) {
			startDate = date1;
			endDate = date2;
		} else {
			return new Date[]{date1, date2};
		}
		
		difference = (int) getDateDifference(startDate, endDate, "day");
		
		dateArray = new Date[difference + 1];
		
		dateArray[0] = startDate;
		dateArray[dateArray.length - 1] = endDate;
		
		calendar = getCalendar();
		
		for(int i=0; i<difference-1; i++) {
			calendar.setTime(getNeedDay(startDate, "day", i + 1));
			
			dateArray[i + 1] = calendar.getTime();
		}
		
		return dateArray;
	}
	
}
