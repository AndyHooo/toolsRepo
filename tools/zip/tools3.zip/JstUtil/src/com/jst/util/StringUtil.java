package com.jst.util;

import java.util.Collection;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * 
 * <p>Title: StringUtil.java</p>
 * <p>Description: 此工具类用于处理字符串相关问题</p>
 * @author lee
 * @date 2015年5月13日
 * @version 1.0
 */
public class StringUtil {
	
	//日志
	@SuppressWarnings("unused")
	private static final Log log = LogFactory.getLog(StringUtil.class);

	public static final String ISO_8859_1 = "ISO-8859-1";
	
	public static final String UTF_8 = "UTF-8";
	
	public static final String GBK = "GBK";
	
	public static final String GB2312 = "GB2312";
	
	public static final String GB18030 = "GB18030";
	
	//默认编码
	public static final String DEFAULT_ENCODING = null == PropertyUtil.getPropertyValue("encoding") ? System.getProperty("file.encoding") : PropertyUtil.getPropertyValue("encoding");
	
	/**
	 * @see 校验字符串是否为空 
	 * @param string
	 * @return boolean
	 */
	public static boolean isEmpty(String string) {
		if (null == string || string.trim().equalsIgnoreCase("null") || string.trim().equals("")) {
			return true;
		}
		
		return false;
	}
	
	/**
	 * @see 校验一组字符串是否空字符串
	 * @param collection
	 * @return boolean
	 */
	public static boolean isEmpty(Collection<String> collection) {
		for (String string : collection) {
			if (isEmpty(string)) {
				return true;
			}
		}
		
		return false;
	}
	
	/**
	 * @see 校验字符串是否为非空
	 * @param string
	 * @return boolean
	 */
	public static boolean isNotEmpty(String string) {
		if (isEmpty(string)) {
			return false;
		}
		
		return true;
	}
	
	/**
	 * @see 获取一定数量的空格
	 * @param number
	 * @return String
	 */
	public static String addSpace(int number) {
		String space = "";
		
		for(int i=0; i<number; i++) {
			space += " ";
		}
		
		return space;
	}
	
	public static String addSpace(String string, int number) {
		return (isEmpty(string) ? "" : string) + addSpace(number);
	}
	
	/**
	 * @see 字符串首字母大写
	 * @param string
	 * @return String
	 */
	public static String firstLetterToUpperCase(String string) {
		return isEmpty(string) ? string : String.valueOf(string.charAt(0)).toUpperCase() + string.substring(1);
	}
	
	/**
	 * @see 字符串首字母小写
	 * @param string
	 * @return String
	 */
	public static String firstLetterToLowerCase(String string) {
		return isEmpty(string) ? string : String.valueOf(string.charAt(0)).toLowerCase() + string.substring(1);
	}
	
	/**
	 * @see 转换html相关字符串
	 * @param string
	 * @return String
	 */
	public static String escapeHtml(String string){
		return StringEscapeUtils.escapeHtml(string);
	}
	
	/**
	 * @see 反转换html相关字符串
	 * @param str
	 * @return String
	 */
	public static String unescapeHtml(String str){
		return StringEscapeUtils.unescapeHtml(str);
	}

}