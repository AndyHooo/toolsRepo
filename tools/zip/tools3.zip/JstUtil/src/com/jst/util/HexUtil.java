package com.jst.util;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * 
 * <p>Title: HexUtil.java</p>
 * <p>Description: 此工具类用于处理16进制数据相关问题</p>
 * @author lee
 * @date 2015年5月22日
 * @version 1.0
 */
public class HexUtil {
	
	//日志
	@SuppressWarnings("unused")
	private static final Log log = LogFactory.getLog(HexUtil.class);
	
	/**
	 * @see hex字符串转byte数组
	 * @param hexString
	 * @return
	 */
	public static byte[] toByteArray(String hexString) {
		byte[] bytes = new byte[hexString.length() / 2];
		
		for(int i=0; i<hexString.length() / 2; i++) {
			bytes[i] = (byte) (Character.digit(hexString.charAt(i * 2), 16) << 4 | Character.digit(hexString.charAt(i * 2 + 1), 16));
		}
		
		return bytes;
	}
	
}
