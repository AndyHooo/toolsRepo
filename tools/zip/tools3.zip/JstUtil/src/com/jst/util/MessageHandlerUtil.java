package com.jst.util;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.jst.constant.Message;
import com.jst.handler.MessageHandler;
import com.jst.handler.impl.JSONHandler;
import com.jst.handler.impl.XMLHandler;
import com.jst.type.DataType;

/**
 * 
 * <p>Title: MessageHandlerUtil.java</p>
 * <p>Description: 此工具类用于处理MessageHandler相关问题</p>
 * @author lee
 * @date 2015年6月8日
 * @version 1.0
 */
public class MessageHandlerUtil {
	
	//日志
	private static final Log log = LogFactory.getLog(MessageHandlerUtil.class);
	
	/**
	 * @see 根据报文类型返回MessageHandler的实例
	 * @param dataType
	 * @return MessageHandler
	 */
	public static MessageHandler getMessageHandler(DataType dataType) {
		return dataType.equals(DataType.XML) ? new XMLHandler() : dataType.equals(DataType.JSON) ? new JSONHandler() : new XMLHandler();
	}
	
	/**
	 * @see 根据报文类型及报文字符串返回MessageHandler的实例
	 * @param dataType
	 * @param text
	 * @return MessageHandler
	 * @throws Exception
	 */
	public static MessageHandler getMessageHandler(DataType dataType, String text) throws Exception {
		try {
			return dataType.equals(DataType.XML) ? new XMLHandler(text) : dataType.equals(DataType.JSON) ? new JSONHandler(text) : new XMLHandler(text);
		} catch (Exception e) {
			log.error("getMessageHandler error: " + e);
			
			throw e;
		}
	}
	
	/**
	 * @see 根据元素代码及报文类型获取其对应的路径表达式
	 * @param elementCode
	 * @param dataType
	 * @return String
	 * @throws Exception
	 */
	public static String getElementPath(String elementCode, DataType dataType) throws Exception {
		try {
			return (String) ReflectUtil.getFieldValue(Message.class.newInstance(), ReflectUtil.getField(Message.class, elementCode + "_" + dataType.toString() + "_" + "PATH"));
		} catch (Exception e) {
			log.error("getElementPath error: " + e);
			
			throw e;
		}
	}
	
}
