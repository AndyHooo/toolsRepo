package com.jst.util;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Arrays;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * 
 * <p>Title: ReflectUtil.java</p>
 * <p>Description: 此工具类用于处理反射相关问题</p>
 * @author lee
 * @date 2015年5月19日
 * @version 1.0
 */
public class ReflectUtil {
	
	//日志
	private static final Log log = LogFactory.getLog(ReflectUtil.class);
	
	/**
	 * @see 判断类是否含有指定注解
	 * @param clazz
	 * @param annotationClass
	 * @return boolean
	 */
	public static boolean hasAnnotation(Class<?> clazz, Class<? extends Annotation> annotationClass) {
		return clazz.isAnnotationPresent(annotationClass);
	}
	
	/**
	 * @see 判断类是否含有注解
	 * @param clazz
	 * @return boolean
	 */
	public static boolean hasAnnotations(Class<?> clazz) {
		return null != clazz.getAnnotations() && clazz.getAnnotations().length > 0;
	}
	
	/**
	 * @see 获取类的指定注解对象
	 * @param clazz
	 * @param annotationClass
	 * @return <A extends Annotation> A
	 */
	public static <A extends Annotation> A getAnnotation(Class<?> clazz, Class<A> annotationClass) {
		return clazz.getAnnotation(annotationClass); 
	}
	
	/**
	 * @see 获取类的所有注解对象
	 * @param clazz
	 * @return Annotation[]
	 */
	public static Annotation[] getAnnotations(Class<?> clazz) {
		return clazz.getAnnotations();
	}
	
	/**
	 * @see 实例化类
	 * @param clazz
	 * @return <T> T
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public static <T> T getInstance(Class<T> clazz) throws Exception {
		try {
			return (T) Class.forName(clazz.getName()).newInstance();
		} catch (Exception e) {
			log.error("getInstance error: " + e);
			
			throw e;
		}
	}
	
	/**
	 * @see 判断字段是否含有指定注解
	 * @param field
	 * @param annotationClass
	 * @return boolean
	 */
	public static boolean hasAnnotation(Field field, Class<? extends Annotation> annotationClass) {
		return field.isAnnotationPresent(annotationClass);
	}
	
	/**
	 * @see 判断字段是否含有注解
	 * @param field
	 * @return boolean
	 */
	public static boolean hasAnnotations(Field field) {
		return null != field.getAnnotations() && field.getAnnotations().length > 0;
	}
	
	/**
	 * @see 获取字段的指定注解对象
	 * @param field
	 * @param annotationClass
	 * @return <A extends Annotation> A
	 */
	public static <A extends Annotation> A getAnnotation(Field field, Class<A> annotationClass) {
		return field.getAnnotation(annotationClass);
	}
	
	/**
	 * @see 获取字段的所有注解对象
	 * @param field
	 * @return Annotation[]
	 */
	public static Annotation[] getAnnotations(Field field) {
		return field.getAnnotations();
	}
	
	/**
	 * @see 判断类中是否含有指定字段
	 * @param clazz
	 * @param fieldName
	 * @return boolean
	 * @throws Exception
	 */
	public static boolean hasField(Class<?> clazz, String fieldName) {
		for(Field field : getFields(clazz)) {
			if(fieldName.toLowerCase().equals(field.getName().toLowerCase())) {
				return true;
			}
		}
		
		for(Field field : getPublicFields(clazz)) {
			if(fieldName.toLowerCase().equals(field.getName().toLowerCase())) {
				return true;
			}
		}
		
		return false;
	}
	
	/**
	 * @see 判断类中是否含有字段
	 * @param clazz
	 * @return boolean
	 */
	public static boolean hasFields(Class<?> clazz) {
		return (null != getFields(clazz) && getFields(clazz).length > 0) || (null != getPublicFields(clazz) && getPublicFields(clazz).length > 0);
	}
	
	/**
	 * @see 获取自身类或父类中指定字段
	 * @param clazz
	 * @param fieldName
	 * @return Field
	 * @throws Exception
	 */
	public static Field getField(Class<?> clazz, String fieldName) {
		for(Field field : getFields(clazz)) {
			if(fieldName.toLowerCase().equals(field.getName().toLowerCase())) {
				return field;
			}
		}
		
		for(Field field : getPublicFields(clazz)) {
			if(fieldName.toLowerCase().equals(field.getName().toLowerCase())) {
				return field;
			}
		}
		
		return null;
	}
	
	/**
	 * @see 获取自身类中声明的所有字段及父类中声明的所有公共字段
	 * @param clazz
	 * @return Field[]
	 */
	public static Field[] getFields(Class<?> clazz) {
		Set<Field> fieldSet = new LinkedHashSet<Field>();
		
		fieldSet.addAll(Arrays.asList(getDeclaredFields(clazz)));
		fieldSet.addAll(Arrays.asList(getPublicFields(clazz)));
		
		return fieldSet.toArray(new Field[]{});
	}
	
	/**
	 * @see 获取自身类中声明的所有字段
	 * @param clazz
	 * @return Field[]
	 */
	public static Field[] getDeclaredFields(Class<?> clazz) {
		return clazz.getDeclaredFields();
	}
	
	/**
	 * @see 获取自身类及父类中声明的所有公共字段
	 * @param clazz
	 * @return Field[]
	 */
	public static Field[] getPublicFields(Class<?> clazz) {
		return clazz.getFields();
	}
	
	/**
	 * @see 获取字段类型
	 * @param field
	 * @return Class<?>
	 */
	public static Class<?> getFieldType(Field field) {
		return field.getType();
	}
	
	/**
	 * @see 获取字段类型
	 * @param clszz
	 * @param fieldName
	 * @return Class<?>
	 */
	public static Class<?> getFieldType(Class<?> clazz, String fieldName) {
		return hasField(clazz, fieldName) ? getFieldType(getField(clazz, fieldName)) : null;
	}
	
	/**
	 * @see 获取字段类型
	 * @param getMethod
	 * @return Class<?>
	 */
	public static Class<?> getFieldType(Method getMethod) {
		return getMethod.getReturnType();
	}
	
	/**
	 * @see 判断方法是否含有指定注解
	 * @param method
	 * @param annotationClass
	 * @return boolean
	 */
	public static boolean hasAnnotation(Method method, Class<? extends Annotation> annotationClass) {
		return method.isAnnotationPresent(annotationClass);
	}
	
	/**
	 * @see 判断方法是否含有注解
	 * @param method
	 * @return boolean
	 */
	public static boolean hasAnnotations(Method method) {
		return null != method.getAnnotations() && method.getAnnotations().length > 0;
	}
	
	/**
	 * @see 获取方法的指定注解
	 * @param method
	 * @param annotationClass
	 * @return <A extends Annotation> A
	 */
	public static <A extends Annotation> A getAnnotation(Method method, Class<A> annotationClass) {
		return method.getAnnotation(annotationClass);
	}
	
	/**
	 * @see 获取方法的所有注解
	 * @param method
	 * @return Annotation[]
	 */
	public static Annotation[] getAnnotations(Method method) {
		return method.getAnnotations();
	}
	
	/**
	 * @see 判断类中是否含有指定方法
	 * @param clazz
	 * @param methodName
	 * @return boolean
	 * @throws Exception
	 */
	public static boolean hasMethod(Class<?> clazz, String methodName, Class<?>... parameterTypes) {
		for(Method method : getMethods(clazz)) {
			if(methodName.toLowerCase().equals(method.getName().toLowerCase())) {
				return true;
			}
		}
		
		for(Method method : getPublicMethods(clazz)) {
			if(methodName.toLowerCase().equals(method.getName().toLowerCase())) {
				return true;
			}
		}
		
		return false;
	}
	
	/**
	 * @see 判断类中是否含有方法
	 * @param clazz
	 * @return boolean
	 */
	public static boolean hasMethods(Class<?> clazz) {
		return (null != getMethods(clazz) && getMethods(clazz).length > 0) || (null != getPublicMethods(clazz) && getPublicMethods(clazz).length > 0);
	}
	
	/**
	 * @see 获取自身类或父类中的指定方法
	 * @param clazz
	 * @param methodName
	 * @param parameterTypes
	 * @return Method
	 * @throws Exception
	 */
	public static Method getMethod(Class<?> clazz, String methodName, Class<?>... parameterTypes) {
		for(Method method : getMethods(clazz)) {
			if(methodName.toLowerCase().equals(method.getName().toLowerCase())) {
				return method;
			}
		}
		
		for(Method method : getPublicMethods(clazz)) {
			if(methodName.toLowerCase().equals(method.getName().toLowerCase())) {
				return method;
			}
		}

		return null;
	}

	/**
	 * @see 获取自身类中声明的所有方法及父类中声明的所有公共方法
	 * @param clazz
	 * @return Method[]
	 */
	public static Method[] getMethods(Class<?> clazz) {
		Set<Method> methodSet = new LinkedHashSet<Method>();
		
		methodSet.addAll(Arrays.asList(getDeclaredMethods(clazz)));
		methodSet.addAll(Arrays.asList(getPublicMethods(clazz)));
		
		return methodSet.toArray(new Method[]{});
	}
	
	/**
	 * @see 获取自身类中声明的所有方法
	 * @param clazz
	 * @return Method[]
	 */
	public static Method[] getDeclaredMethods(Class<?> clazz) {
		return clazz.getDeclaredMethods();
	}
	
	/**
	 * @see 获取自身类及父类中声明的所有公共方法
	 * @param clazz
	 * @return Method[]
	 */
	public static Method[] getPublicMethods(Class<?> clazz) {
		return clazz.getMethods();
	}
	
	/**
	 * @see 执行类中的指定方法
	 * @param method
	 * @param object
	 * @param parameterValues
	 * @return Object
	 * @throws Exception
	 */
	public static Object executeMethod(Method method, Object object, Object... parameterValues) throws Exception {
		try {
			return method.invoke(object, parameterValues);
		} catch (Exception e) {
			log.error("executeMethod error: " + e);
			
			throw e;
		}
	}
	
	/**
	 * @see 获取字段值
	 * @param object
	 * @param field
	 * @return Object
	 * @throws Exception
	 */
	public static Object getFieldValue(Object object, Field field) throws Exception {
		try {
			if(!field.isAccessible()) {
				field.setAccessible(true);
			}
			
			return field.get(object);
		} catch (Exception e) {
			log.error("getFieldValue error: " + e);
			
			throw e;
		}
	}
	
	/**
	 * @see 设置字段值
	 * @param object
	 * @param field
	 * @param value
	 * @throws Exception
	 */
	public static void setFieldValue(Object object, Field field, Object value) throws Exception {
		try {
			if(!field.isAccessible()) {
				field.setAccessible(true);
			}
			
			field.set(object, value);
		} catch (Exception e) {
			log.error("setFieldValue error: " + e);
			
			throw e;
		}
	}
	
	/**
	 * @see 判断是否为数组
	 * @param clazz
	 * @return boolean
	 */
	public static boolean isArray(Class<?> clazz) {
		return clazz.isArray();
	}
	
	/**
	 * @see 判断是否为数组
	 * @param object
	 * @return boolean
	 */
	public static boolean isArray(Object object) {
		return isArray(object.getClass());
	}
	
	/**
	 * @see 判断是否为集合
	 * @param clazz
	 * @return boolean
	 */
	public static boolean isCollection(Class<?> clazz) {
		return Collection.class.isAssignableFrom(clazz);
	}
	
	/**
	 * @see 判断是否为集合
	 * @param object
	 * @return boolean
	 */
	public static boolean isCollection(Object object) {
		return isCollection(object.getClass());
	}
	
	/**
	 * @see 判断是否为Map
	 * @param clazz
	 * @return boolean
	 */
	public static boolean isMap(Class<?> clazz) {
		return Map.class.isAssignableFrom(clazz);
	}
	
	/**
	 * @see 判断是否为Map
	 * @param object
	 * @return boolean
	 */
	public static boolean isMap(Object object) {
		return isMap(object.getClass());
	}
	
	/**
	 * @see 判断是否为Set
	 * @param clazz
	 * @return boolean
	 */
	public static boolean isSet(Class<?> clazz) {
		return Set.class.isAssignableFrom(clazz);
	}
	
	/**
	 * @see 判断是否为Set
	 * @param object
	 * @return boolean
	 */
	public static boolean isSet(Object object) {
		return isSet(object.getClass());
	}
	
	/**
	 * @see 判断是否为代理类
	 * @param clazz
	 * @return boolean
	 */
	public static boolean isProxyClass(Class<?> clazz) {
		return Proxy.isProxyClass(clazz);
	}
	
	/**
	 * @see 判断是否为代理类
	 * @param object
	 * @return boolean
	 */
	public static boolean isProxyClass(Object object) {
		return isProxyClass(object.getClass());
	}
	
	/**
	 * @see 判断是否为CGLIB的代理类
	 * @param clazz
	 * @return boolean
	 */
	public static boolean isCglibProxyClass(Class<?> clazz) {
		return null != clazz && (null != clazz.getName() && clazz.getName().contains("$$"));
	}
	
	/**
	 * @see 判断是否为CGLIB的代理类
	 * @param clazz
	 * @return boolean
	 */
	public static boolean isCglibProxyClass(Object object) {
		return isCglibProxyClass(object.getClass());
	}
}
