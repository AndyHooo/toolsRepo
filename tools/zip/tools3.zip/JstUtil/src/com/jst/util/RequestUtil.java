package com.jst.util;

import javax.servlet.http.HttpServletRequest;

import org.apache.axis2.context.MessageContext;
import org.apache.axis2.transport.http.HTTPConstants;
import org.apache.shiro.web.util.WebUtils;
import org.apache.struts2.ServletActionContext;

/**
 * 
 * <p>
 * Title: RequestUtil.java
 * </p>
 * <p>
 * Description: 此工具类用于处理Request相关问题
 * </p>
 * 
 * @author lee
 * @date 2015年6月10日
 * @version 1.0
 */
public class RequestUtil {

	/**
	 * @see 获取basePath
	 * @param request
	 * @param absolute
	 * @return String
	 */
	public static String getBasePath(HttpServletRequest request, boolean absolute) {
		return absolute ? request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort() + request.getContextPath() : request.getContextPath();
	}

	/**
	 * @see 从AXIS中获取HttpServletRequest
	 * @return HttpServletRequest
	 */
	public static HttpServletRequest getRequestFromAxis() {
		return (HttpServletRequest) MessageContext.getCurrentMessageContext().getProperty(HTTPConstants.MC_HTTP_SERVLETREQUEST);
	}

	/**
	 * @see 从AXIS中获取HttpServletRequest
	 * @param context
	 * @return HttpServletRequest
	 */
	public static HttpServletRequest getRequestFromAxis(MessageContext context) {
		return (HttpServletRequest) context.getProperty(HTTPConstants.MC_HTTP_SERVLETREQUEST);
	}

	/**
	 * @see 从Shiro中获取HttpServletRequest
	 * @return HttpServletRequest
	 */
	public static HttpServletRequest getRequestFromShiro() {
		return WebUtils.getHttpRequest(ShiroUtil.getSubject());
	}

	/**
	 * @see 从Struts2中获取HttpServletRequest
	 * @return HttpServletRequest
	 */
	public static HttpServletRequest getRequestFromStruts() {
		return ServletActionContext.getRequest();
	}

	/**
	 * @see 判断当前请求方式(同步或异步)
	 * @param request
	 * @return boolean
	 */
	public static boolean isSynchronized(HttpServletRequest request) {
		// return -1 == request.getHeader("accept").indexOf("application/json") || (null != request.getHeader("x-requested-with") && -1 == request.getHeader("x-requested-with").indexOf("XMLHttpRequest"));
		// ajax请求不设置数据返回格式
		return (null != request.getHeader("x-requested-with") && request.getHeader("x-requested-with").equals("XMLHttpRequest")) ? false : (-1 == request.getHeader("accept").indexOf("application/json"));
	}

}
