package com.jst.util;

import java.io.IOException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

/**
 * 
 * <p>Title: EncryptUtil.java</p>
 * <p>Description: 此工具类用于处理加解密相关问题</p>
 * @author lee
 * @date 2015年5月22日
 * @version 1.0
 */
public class EncryptUtil {
	
	//日志
	private static final Log log = LogFactory.getLog(EncryptUtil.class);
	
	//DES算法名称
	public static final String ALGORITHM_DES = "DES";
	
	//MD5算法名称
	public static final String ALGORITHM_MD5 = "MD5";

	
	/**
	 * @see BASE64加码
	 * @param bytes
	 * @return String
	 */
	public static String encryptBASE64(byte[] bytes) {
		return new BASE64Encoder().encode(bytes);
	}
	
	/**
	 * @see BASE64解码
	 * @param string
	 * @return byte[]
	 * @throws IOException
	 */
	public static byte[] decryptBASE64(String string) throws IOException {
		try {
			return new BASE64Decoder().decodeBuffer(string);
		} catch (IOException e) {
			log.error("decryptBASE64 error: " + e);
			
			throw e;
		} 		
		
	}
	
	/**
	 * @see DES加密
	 * @param key
	 * @param data
	 * @return byte[]
	 * @throws Exception
	 */
	public static String encryptDES(String key, String data) throws Exception {
		try {
			DESKeySpec desKey = new DESKeySpec(key.getBytes(StringUtil.DEFAULT_ENCODING));
			
			SecretKeyFactory keyFactory = SecretKeyFactory.getInstance(ALGORITHM_DES);
			
			SecretKey secretKey = keyFactory.generateSecret(desKey);
			
			SecureRandom random = new SecureRandom();
			
			Cipher cipher = Cipher.getInstance(ALGORITHM_DES);
			
			cipher.init(Cipher.ENCRYPT_MODE, secretKey, random);
			
			return ByteUtil.toHexString(cipher.doFinal(data.getBytes(StringUtil.DEFAULT_ENCODING)));
		} catch (Exception e) {
			log.error("encryptDES error: " + e);
			
			throw e;
		}
	}
	
	/**
	 * @see DES解密
	 * @param key
	 * @param data
	 * @return byte[]
	 * @throws Exception
	 */
	public static String decryptDES(String key, String hexString) throws Exception {
		try {
			DESKeySpec desKey = new DESKeySpec(key.getBytes(StringUtil.DEFAULT_ENCODING));
			
			SecretKeyFactory keyFactory = SecretKeyFactory.getInstance(ALGORITHM_DES);
			
			SecretKey secretKey = keyFactory.generateSecret(desKey);
			
			SecureRandom random = new SecureRandom();
			
			Cipher cipher = Cipher.getInstance(ALGORITHM_DES);
			
			cipher.init(Cipher.DECRYPT_MODE, secretKey, random);
			
			return new String(cipher.doFinal(HexUtil.toByteArray(hexString)));
		} catch (Exception e) {
			log.error("decryptDES error: " + e);
			
			throw e;
		}
	}
	
	/**
	 * @see MD5加密
	 * @param string
	 * @return byte[]
	 * @throws NoSuchAlgorithmException
	 */
	public static String encryptMD5(String string) throws Exception {
		try {
			return ByteUtil.toHexString(MessageDigest.getInstance(ALGORITHM_MD5).digest(string.getBytes(StringUtil.DEFAULT_ENCODING)));
		} catch (Exception e) {
			log.error("encryptMD5 error: " + e);
			
			throw e;
		}
	}
	
	/**
	 * @see url加码
	 * @param url
	 * @param encoding
	 * @return String
	 * @throws Exception
	 */
	public static String encryptURL(String url, String encoding) throws Exception {
		try {
			return null == encoding ? URLEncoder.encode(url, StringUtil.DEFAULT_ENCODING) : URLEncoder.encode(url, encoding);
		} catch (Exception e) {
			log.error("encryptURL error: " + e);
			
			throw e;
		}
	}
	
	/**
	 * @see url解码
	 * @param url
	 * @param encoding
	 * @return String
	 * @throws Exception
	 */
	public static String decryptURL(String url, String encoding) throws Exception {
		try {
			return null == encoding ? URLDecoder.decode(url, StringUtil.DEFAULT_ENCODING) : URLDecoder.decode(url, encoding);
		} catch (Exception e) {
			log.error("decryptURL error: " + e);
			
			throw e;
		}
	}
}
