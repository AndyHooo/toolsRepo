package com.jst.util;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletResponse;

import org.apache.axis2.context.MessageContext;
import org.apache.axis2.transport.http.HTTPConstants;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.shiro.web.util.WebUtils;
import org.apache.struts2.ServletActionContext;

/**
 * 
 * <p>Title: ResponseUtil.java</p>
 * <p>Description: 此工具类用于处理Response相关问题</p>
 * @author lee
 * @date 2015年6月10日
 * @version 1.0
 */
public class ResponseUtil {
	
	//日志
	private static final Log log = LogFactory.getLog(ResponseUtil.class);
	
	/**
	 * @see 从AXIS中获取HttpServletResponse
	 * @return HttpServletResponse
	 */
	public static HttpServletResponse getResponseFromAxis() {
		return (HttpServletResponse) MessageContext.getCurrentMessageContext().getProperty(HTTPConstants.MC_HTTP_SERVLETRESPONSE);
	}
	
	/**
	 * @see 从AXIS中获取HttpServletResponse
	 * @param context
	 * @return HttpServletResponse
	 */
	public static HttpServletResponse getResponseFromAxis(MessageContext context) {
		return (HttpServletResponse) context.getProperty(HTTPConstants.MC_HTTP_SERVLETRESPONSE);
	}
	
	/**
	 * @see 从Shiro中获取HttpServletResponse
	 * @return HttpServletResponse
	 */
	public static HttpServletResponse getResponseFromShiro() {
		return WebUtils.getHttpResponse(ShiroUtil.getSubject());
	}
	
	/**
	 * @see 从Struts2中获取HttpServletResponse
	 * @return HttpServletResponse
	 */
	public static HttpServletResponse getResponseFromStruts() {
		return ServletActionContext.getResponse();
	}

	/**
	 * @see 写入字符串
	 * @param response
	 * @param string
	 * @throws Exception
	 */
	public static void writeString(HttpServletResponse response, String string) throws Exception {
		PrintWriter writer = null;
		
		try {
			response.setContentType("text/html");
		    response.setHeader("Pragma", "no-cache");
		    response.setHeader("Cache-Control", "no-cache, must-revalidate");
		    response.setHeader("Pragma", "no-cache");
			
		    writer = response.getWriter();
		    
		    writer.write(string);
		    
		    writer.flush();
		} catch (Exception e) {
			log.error("writeString error: " + e);
			
			throw e;
		} finally {
			if (null != writer) {
				writer.close();
			}
		}
	}
	
}
