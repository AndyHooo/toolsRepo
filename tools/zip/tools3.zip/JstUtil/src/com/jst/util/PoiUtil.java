package com.jst.util;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class PoiUtil {

	//日志
	@SuppressWarnings("unused")
	private static final Log log = LogFactory.getLog(PoiUtil.class);
	
}
