package com.jst.util;

import net.sf.json.JSON;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import net.sf.json.JSONSerializer;
import net.sf.json.JsonConfig;
import net.sf.json.xml.XMLSerializer;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.jayway.jsonpath.JsonPath;
import com.jst.config.XMLSerializerConfig;

/**
 * 
 * <p>Title: JsonUtil.java</p>
 * <p>Description: 此工具类用于处理JSON相关问题</p>
 * @author lee
 * @date 2015年5月26日
 * @version 1.0
 */
public class JsonUtil {

	//日志
	private static final Log log = LogFactory.getLog(JsonUtil.class);
	
	//标志
	private static final String SUCCESS = "success";
	
	//消息
	private static final String MESSAGE = "message";
	
	/**
	 * @see 解析对象为JSON
	 * @param object
	 * @return JSON
	 */
	public static JSON parse(Object object) {
		return JSONSerializer.toJSON(object);
	}
	
	/**
	 * @see 根据配置解析对象为JSON
	 * @param object
	 * @param jsonConfig
	 * @return
	 */
	public static JSON parse(Object object, JsonConfig jsonConfig) {
		return JSONSerializer.toJSON(object, jsonConfig);
	}
	
	/**
	 * @see 解析对象为JSONObject
	 * @param object
	 * @return JSONObject
	 */
	public static JSONObject parseJSONObject(Object object) {
		return JSONObject.fromObject(object);
	}
	
	/**
	 * @see 根据配置解析对象为JSONObject
	 * @param object
	 * @param jsonConfig
	 * @return JSONObject
	 */
	public static JSONObject parseJSONObject(Object object, JsonConfig jsonConfig) {
		return JSONObject.fromObject(object, jsonConfig);
	}
	
	/**
	 * @see 解析对象为JSONArray
	 * @param object
	 * @return JSONArray
	 */
	public static JSONArray parseJSONArray(Object object) {
		return JSONArray.fromObject(object);
	}
	
	/**
	 * @see 根据配置解析对象为JSONArray
	 * @param object
	 * @param jsonConfig
	 * @return JSONArray
	 */
	public static JSONArray parseJSONArray(Object object, JsonConfig jsonConfig) {
		return JSONArray.fromObject(object, jsonConfig);
	} 
	
	/**
	 * @see 创建JSONObject
	 * @return JSONObject
	 */
	public static JSONObject createJsonObject() {
		return new JSONObject();
	}
	
	/**
	 * @see 创建JSONArray
	 * @return JSONArray
	 */
	public static JSONArray createJsonArray() {
		return new JSONArray();
	}

	/**
	 * @see 判断JSONObject是否含有根对象
	 * @param jsonObject
	 * @return boolean
	 */
	public static boolean hasRootObject(JSONObject jsonObject) {
		return null != jsonObject && !jsonObject.isEmpty() && 1 == jsonObject.keySet().size();
	}
	
	/**
	 * @see 获取JSONObject根对象名称
	 * @param jsonObject
	 * @return String
	 */
	public static String getRootName(JSONObject jsonObject) {
		return hasRootObject(jsonObject) ? (String) jsonObject.keys().next() : ""; 
	}
	
	/**
	 * @see 获取JSONObject根对象
	 * @param jsonObject
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static <T> T getRootObject(JSONObject jsonObject) {
		return (T) jsonObject.get(getRootName(jsonObject));
	}

	/**
	 * @see 根据JsonPath判断对象是否存在
	 * @param json
	 * @param jsonPath
	 * @return boolean
	 */
	public static boolean hasObject(JSON json, String jsonPath) {
		//此方法尚未完成，此处以简单形式判断，稍后以断言判断
		try {
			getObject(json, jsonPath);
		} catch (Exception e) {
			return false;
		}
		
		return true;
	}
	
	/**
	 * @see 根据JsonPath获取对象
	 * @param json
	 * @param jsonPath
	 * @return <T> T
	 */
	public static <T> T getObject(JSON json, String jsonPath) {
		return JsonPath.read(json, jsonPath);
	}
	
	/**
	 * @see 用户前后台交互，返回正确信息
	 * @param message
	 * @return String
	 */
	public static String toSuccessMsg(String message) {
		return createJsonObject().accumulate(SUCCESS, true).accumulate(MESSAGE, message).toString();
	}
	
	/**
	 * @see 用户前后台交互，返回错误信息
	 * @param message
	 * @return String
	 */
	public static String toErrorMsg(String message) {
		return createJsonObject().accumulate(SUCCESS, false).accumulate(MESSAGE, message).toString();
	}
	
	/**
	 * @see JSON转换XML，尚未完善，不推荐使用
	 * @param json
	 * @param config
	 * @return String
	 * @throws Exception
	 */
	@Deprecated
	public static String toXML(JSON json, XMLSerializerConfig config) throws Exception {
		XMLSerializer serializer = new XMLSerializer();
		
		try {
			EntityUtil.cloneEntity(config, serializer);
		} catch (Exception e) {
			log.error("toXML error: " + e);
			
			throw e;
		}
		
		return serializer.write(json, StringUtil.DEFAULT_ENCODING);
	}
	
}