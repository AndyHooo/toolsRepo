package com.jst.model;

import java.io.Serializable;

public class Token implements Serializable {

	private static final long serialVersionUID = -4202220511880740484L;

	private String token;
	private String random;

	public Token() {
		
	}

	public Token(String token, String random) {
		this.token = token;
		this.random = random;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getRandom() {
		return random;
	}

	public void setRandom(String random) {
		this.random = random;
	}

}
