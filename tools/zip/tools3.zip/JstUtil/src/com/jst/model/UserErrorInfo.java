package com.jst.model;

import java.util.Date;

/**
 * 
 * <p>Title: UserErrorInfo.java</p>
 * <p>Description: 此实体用于封装用户登录错误信息</p>
 * @author lee
 * @date 2014年4月22日
 * @version 1.0
 */
public class UserErrorInfo {
	
	//第一次登录错误的时间
	private Date errorTime;
	
	//联系登陆错误的次数
	private int errorCount;
	
	/**
	 * @see 构造方法
	 */
	public UserErrorInfo(){
		
	}
	
	/**
	 * @see 构造方法
	 * @param errorTime
	 * @param errorCount
	 */
	public UserErrorInfo(Date errorTime, int errorCount){
		this.errorTime = errorTime;
		this.errorCount = errorCount;
	}

	/**
	 * @see 获取第一次登录错误的时间
	 * @return Date
	 */
	public Date getErrorTime() {
		return errorTime;
	}

	/**
	 * @see 设置第一次登录错误的时间
	 * @param errorTime
	 */
	public void setErrorTime(Date errorTime) {
		this.errorTime = errorTime;
	}

	/**
	 * @see 获取登录错误的次数
	 * @return int
	 */
	public int getErrorCount() {
		return errorCount;
	}

	/**
	 * @see 设置登陆错误的次数
	 * @param errorCount
	 */
	public void setErrorCount(int errorCount) {
		this.errorCount = errorCount;
	}
	
}
