package com.jst.model;

import com.jst.common.utils.page.Page;
import com.jst.config.ObjectSerializeConfig;
import com.jst.serializer.ObjectSerializer;
import com.jst.type.DataType;
import com.jst.util.JsonUtil;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;


/**
 * 
 * <p>Title: EasyuiGrid.java</p>
 * <p>Description: 此实体用于封装EasyUI所需数据</p>
 * @author lee
 * @date 2015年5月28日
 * @version 1.0
 */
public class EasyuiGrid {
	
	//标志
	private static final String SUCCESS = "success";
	
	//消息
	private static final String MESSAGE = "message";
	
	//总数
	private static final String TOTAL = "total";
	
	//记录
	private static final String ROWS = "rows";
	
	//数据总数
	private long rowCount;
	
	//查询所返回的数据
	private JSONArray rows;
	
	
	/**
	 * @see 构造方法
	 */
	public EasyuiGrid(){
		//初始化对象
		rows = JsonUtil.createJsonArray();
	}
	
	/**
	 * @see 获取数据总数
	 * @return long
	 */
	public long getRowCount() {
		return rowCount;
	}

	/**
	 * @see 设置数据总数
	 * @param rowCount
	 */
	public void setRowCount(long rowCount){
		this.rowCount = rowCount;
	}
	
	/**
	 * @see 创建行对象
	 * @return EasyuiRow
	 */
	public EasyuiRow createRow(){
		return new EasyuiRow();
	}
	
	/**
	 * @see 增加一条行记录
	 * @param row
	 */
	public void addRow(EasyuiRow row){
		rows.add(row.getRow());
	}
	
	/**
	 * @see 添加多行记录
	 * @param rows
	 */
	public void addRows(JSONArray rows) {
		this.rows = rows;
	}
	
	/**
	 * @see 重写toString方法，返回符合EasyUI所需的JSON格式字符串
	 * @return String
	 */
	public String toString() {
		return JsonUtil.createJsonObject().accumulate(TOTAL, rowCount).accumulate(ROWS, rows).toString();
	}
	
	public String toString(boolean success, String message) {
		return JsonUtil.createJsonObject().accumulate(SUCCESS, success).accumulate(MESSAGE, message).accumulate(TOTAL, rowCount).accumulate(ROWS, rows).toString();
	}
	
	/**
	 * @see 序列化对象，返回EasyUI所需的JSON格式字符串
	 * @param success
	 * @param message
	 * @param serializeConfig
	 * @param page
	 * @return String
	 */
	@Deprecated
	public static String toString(boolean success, String message, ObjectSerializeConfig serializeConfig, Page<?> page) {
		JSONObject jsonObject = JsonUtil.createJsonObject();
		JSONArray jsonArray = JsonUtil.createJsonArray();
		
		jsonObject.accumulate(SUCCESS, success);
		jsonObject.accumulate(MESSAGE, message);
		
		if (success) {
			jsonObject.accumulate(TOTAL, page.getTotalCount());
			
			jsonArray = JsonUtil.getRootObject(JsonUtil.parseJSONObject(ObjectSerializer.getInstance(DataType.JSON, serializeConfig).serialize(page.getResult())));
			jsonObject.accumulate(ROWS, JsonUtil.getRootObject(jsonArray.getJSONObject(0)));
		} else {
			jsonObject.accumulate(TOTAL, 0);
			jsonObject.accumulate(ROWS, jsonArray);
		}
		
		return jsonObject.toString();
	}
}
