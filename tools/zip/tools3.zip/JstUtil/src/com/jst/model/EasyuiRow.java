package com.jst.model;

import net.sf.json.JSONObject;

/**
 * 
 * <p>Title: EasyuiRow.java</p>
 * <p>Description: 此实体用于封装EasyUI所需行数据</p>
 * @author lee
 * @date 2015年5月28日
 * @version 1.0
 */
public class EasyuiRow {

	private JSONObject row;
	
	public EasyuiRow(){
		row = new JSONObject();
	}
	
	public JSONObject getRow() {
		return row;
	}

	public void addCell(String key, Object value){
		row.accumulate(key, value);
	}
}
