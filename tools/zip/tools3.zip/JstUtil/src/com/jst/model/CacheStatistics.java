package com.jst.model;

import java.io.Serializable;

/**
 * 
 * <p>Title: CacheStatistics.java</p>
 * <p>Description: 缓存统计对象</p>
 * @author lee
 * @date 2015年7月29日
 * @version 1.0
 */
public class CacheStatistics implements Serializable {
	
	private static final long serialVersionUID = 2093545232014579020L;
	
	private long objectCount;				//存储对象数量
	private long objectSize;				//存储对象大小
	
	private long averageGetTime;			//平均获取时间
	private long averageSearchTime;			//平均查询时间
	private long searchesPerSecond;			//每秒查询次数
	
	private long cacheHits;					//缓存命中次数
	private long cacheMisses;				//缓存失误次数
	
	private long evictionCount;				//已清除元素数量
	
	private long memoryStoreObjectCount;	//内存中存储元素数量
	private long memoryStoreObjectSize;		//内存中存储元素大小
	
	private long inMemoryHits;				//内存中缓存命中次数			
	private long inMemoryMisses;			//内存中缓存失误次数
	
	private long diskStoreObjectCount;		//磁盘中存储元素数量
	private long diskStoreObjectSize;		//磁盘中存储元素大小
	
	private long onDiskHits;				//磁盘中缓存命中次数
	private long onDiskMisses;				//磁盘中缓存失误次数
	
	private long offHeapStoreObjectCount;	//堆外空间中存储元素数量
	private long offHeapStoreObjectSize;	//堆外空间中存储元素大小
	
	private long offHeapHits;				//堆外空间缓存命中次数
	private long offHeapMisses;				//堆外空间缓存失误次数
	
	public CacheStatistics() {
		super();
	}

	public CacheStatistics(long objectCount, long objectSize,
			long averageGetTime, long averageSearchTime,
			long searchesPerSecond, long cacheHits, long cacheMisses,
			long evictionCount, long memoryStoreObjectCount,
			long memoryStoreObjectSize, long inMemoryHits, long inMemoryMisses,
			long diskStoreObjectCount, long diskStoreObjectSize,
			long onDiskHits, long onDiskMisses, long offHeapStoreObjectCount,
			long offHeapStoreObjectSize, long offHeapHits, long offHeapMisses) {
		super();
		this.objectCount = objectCount;
		this.objectSize = objectSize;
		this.averageGetTime = averageGetTime;
		this.averageSearchTime = averageSearchTime;
		this.searchesPerSecond = searchesPerSecond;
		this.cacheHits = cacheHits;
		this.cacheMisses = cacheMisses;
		this.evictionCount = evictionCount;
		this.memoryStoreObjectCount = memoryStoreObjectCount;
		this.memoryStoreObjectSize = memoryStoreObjectSize;
		this.inMemoryHits = inMemoryHits;
		this.inMemoryMisses = inMemoryMisses;
		this.diskStoreObjectCount = diskStoreObjectCount;
		this.diskStoreObjectSize = diskStoreObjectSize;
		this.onDiskHits = onDiskHits;
		this.onDiskMisses = onDiskMisses;
		this.offHeapStoreObjectCount = offHeapStoreObjectCount;
		this.offHeapStoreObjectSize = offHeapStoreObjectSize;
		this.offHeapHits = offHeapHits;
		this.offHeapMisses = offHeapMisses;
	}

	public long getObjectCount() {
		return objectCount;
	}

	public void setObjectCount(long objectCount) {
		this.objectCount = objectCount;
	}

	public long getObjectSize() {
		return objectSize;
	}

	public void setObjectSize(long objectSize) {
		this.objectSize = objectSize;
	}

	public long getAverageGetTime() {
		return averageGetTime;
	}

	public void setAverageGetTime(long averageGetTime) {
		this.averageGetTime = averageGetTime;
	}

	public long getAverageSearchTime() {
		return averageSearchTime;
	}

	public void setAverageSearchTime(long averageSearchTime) {
		this.averageSearchTime = averageSearchTime;
	}

	public long getSearchesPerSecond() {
		return searchesPerSecond;
	}

	public void setSearchesPerSecond(long searchesPerSecond) {
		this.searchesPerSecond = searchesPerSecond;
	}

	public long getCacheHits() {
		return cacheHits;
	}

	public void setCacheHits(long cacheHits) {
		this.cacheHits = cacheHits;
	}

	public long getCacheMisses() {
		return cacheMisses;
	}

	public void setCacheMisses(long cacheMisses) {
		this.cacheMisses = cacheMisses;
	}

	public long getEvictionCount() {
		return evictionCount;
	}

	public void setEvictionCount(long evictionCount) {
		this.evictionCount = evictionCount;
	}

	public long getMemoryStoreObjectCount() {
		return memoryStoreObjectCount;
	}

	public void setMemoryStoreObjectCount(long memoryStoreObjectCount) {
		this.memoryStoreObjectCount = memoryStoreObjectCount;
	}

	public long getMemoryStoreObjectSize() {
		return memoryStoreObjectSize;
	}

	public void setMemoryStoreObjectSize(long memoryStoreObjectSize) {
		this.memoryStoreObjectSize = memoryStoreObjectSize;
	}

	public long getInMemoryHits() {
		return inMemoryHits;
	}

	public void setInMemoryHits(long inMemoryHits) {
		this.inMemoryHits = inMemoryHits;
	}

	public long getInMemoryMisses() {
		return inMemoryMisses;
	}

	public void setInMemoryMisses(long inMemoryMisses) {
		this.inMemoryMisses = inMemoryMisses;
	}

	public long getDiskStoreObjectCount() {
		return diskStoreObjectCount;
	}

	public void setDiskStoreObjectCount(long diskStoreObjectCount) {
		this.diskStoreObjectCount = diskStoreObjectCount;
	}

	public long getDiskStoreObjectSize() {
		return diskStoreObjectSize;
	}

	public void setDiskStoreObjectSize(long diskStoreObjectSize) {
		this.diskStoreObjectSize = diskStoreObjectSize;
	}

	public long getOnDiskHits() {
		return onDiskHits;
	}

	public void setOnDiskHits(long onDiskHits) {
		this.onDiskHits = onDiskHits;
	}

	public long getOnDiskMisses() {
		return onDiskMisses;
	}

	public void setOnDiskMisses(long onDiskMisses) {
		this.onDiskMisses = onDiskMisses;
	}

	public long getOffHeapStoreObjectCount() {
		return offHeapStoreObjectCount;
	}

	public void setOffHeapStoreObjectCount(long offHeapStoreObjectCount) {
		this.offHeapStoreObjectCount = offHeapStoreObjectCount;
	}

	public long getOffHeapStoreObjectSize() {
		return offHeapStoreObjectSize;
	}

	public void setOffHeapStoreObjectSize(long offHeapStoreObjectSize) {
		this.offHeapStoreObjectSize = offHeapStoreObjectSize;
	}

	public long getOffHeapHits() {
		return offHeapHits;
	}

	public void setOffHeapHits(long offHeapHits) {
		this.offHeapHits = offHeapHits;
	}

	public long getOffHeapMisses() {
		return offHeapMisses;
	}

	public void setOffHeapMisses(long offHeapMisses) {
		this.offHeapMisses = offHeapMisses;
	}
	
}
