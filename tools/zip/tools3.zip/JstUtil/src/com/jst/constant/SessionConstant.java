package com.jst.constant;

/**
 * 
 * <p>Title: SessionConstant.java</p>
 * <p>Description: The class stores some constants of session keys.</p>
 * @author lee
 * @date 2015年3月5日
 * @version 1.0
 */
public class SessionConstant {

	public static final String LOGIN_INFO = "LOGIN_INFO";
	
	public static final String USER_CODE = "USER_CODE";
	public static final String USER_NAME = "USER_NAME";
	public static final String USER_TYPE = "USER_TYPE";
	
	public static final String DEPT_ID = "DEPT_ID";
	public static final String DEPT_NAME = "DEPT_NAME";
	public static final String DEPT_TYPE = "DEPT_TYPE";
	
	public static final String VERIFY_CODE = "VERIFY_CODE";
	
}
