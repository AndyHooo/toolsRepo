package com.jst.constant;

public class RequestHeader {

	public static final String HOST = "host";
	
	public static final String CONNECTION = "connection";
	
	public static final String CACHE_CONTROL = "cache-control";
	
	public static final String ACCEPT = "accept";
	
	public static final String USER_AGENT = "user-agent";
	
	public static final String ACCEPT_ENCODING = "accept-encoding";
	
	public static final String ACCEPT_LANGUAGE = "accept-language";
	
	public static final String REFERER = "referer";
	
	public static final String X_REQUESTED_WITH = "x-requested-with";
	
}
