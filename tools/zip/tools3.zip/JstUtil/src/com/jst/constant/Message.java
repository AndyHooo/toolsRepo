package com.jst.constant;

import com.jst.util.DateUtil;
import com.jst.util.PropertyUtil;
import com.jst.util.StringUtil;

/**
 * 
 * <p>Title: Message.java</p>
 * <p>Description: 此常量包含报文的默认信及设置</p>
 * @author lee
 * @date 2015年6月8日
 * @version 1.0
 */
public class Message {
	
	//编码格式
	public static final String ENCODING = null == PropertyUtil.getPropertyValue("encoding") ? "UTF-8" : PropertyUtil.getPropertyValue("encoding");

	//文档类型
	public static final String DOC_TYPE = "<?xml version='1.0' encoding='" + ENCODING + "'?>";
	
	//SOAP头部认证信息节点名称
	public static final String AUTHENTICATION = "Authentication";
	
	//SOAP头部认证用户节点名称
	public static final String USER_CODE = "UserCode";
	
	//SOAP头部认证密码节点名称
	public static final String PASSWORD = "Password";
	
	//SOAP头部认证签名节点名称
	public static final String SIGNATURE = "Signature";

	//报文根节点代码
	public static final String ROOT = "MSG";
	
	//报文根节点名称
	public static final String ROOT_NAME = "msg";
	
	//XML根节点路径
	public static final String ROOT_XML_PATH = "/" + ROOT_NAME;
	
	//JSON根节点路径
	public static final String ROOT_JSON_PATH = "$." + ROOT_NAME;
	
	//报文头部节点代码
	public static final String HEAD = "HEAD";
	
	//报文头部节点名称
	public static final String HEAD_NAME = "head";
	
	//XML头部节点路径
	public static final String HEAD_XML_PATH = ROOT_XML_PATH + "/" + HEAD_NAME;
	
	//JSON头部节点路径
	public static final String HEAD_JSON_PATH = ROOT_JSON_PATH + "." + HEAD_NAME;
	
	//报文返回代码节点代码
	public static final String RET_CODE = "RET_CODE";
	
	//报文返回代码节点名称
	public static final String RET_CODE_NAME = "retCode";
	
	//XML返回代码节点路径
	public static final String RET_CODE_XML_PATH = HEAD_XML_PATH + "/" + RET_CODE_NAME;
	
	//JSON返回代码节点路径
	public static final String RET_CODE_JSON_PATH = HEAD_JSON_PATH + "." + RET_CODE_NAME;
	
	//报文返回信息节点代码
	public static final String RET_MSG = "RET_MSG";

	//报文返回信息节点名称
	public static final String RET_MSG_NAME = "retMsg";
	
	//XML返回信息节点路径
	public static final String RET_MSG_XML_PATH = HEAD_XML_PATH + "/" + RET_MSG_NAME;
	
	//JSON返回信息节点路径
	public static final String RET_MSG_JSON_PATH = HEAD_JSON_PATH + "." + RET_MSG_NAME;
	
	//报文身体节点代码
	public static final String BODY = "BODY";
	
	//报文身体节点名称
	public static final String BODY_NAME = "body";
	
	//XML身体节点路径
	public static final String BODY_XML_PATH = ROOT_XML_PATH + "/" + BODY_NAME;
	
	//JSON身体节点路径
	public static final String BODY_JSON_PATH = ROOT_JSON_PATH + "." + BODY_NAME;
	
	//报文数据记录节点代码
	public static final String RECORD = "RECORD";
	
	//报文数据记录节点名称
	public static final String RECORD_NAME = "record";
	
	//XML数据记录节点路径
	public static final String RECORD_XML_PATH = BODY_XML_PATH + "/" + RECORD_NAME;
	
	//JSON数据记录节点路径
	public static final String RECORD_JSON_PATH = BODY_JSON_PATH + "." + RECORD_NAME;
	
	//成功代码
	public static final String RET_CODE_SUCCESS = "T";
	
	//失败代码
	public static final String RET_CODE_FAILURE = "F";
	
	//默认日期格式
	public static final String DATE_PATTERN = StringUtil.isEmpty(PropertyUtil.getPropertyValue("wsDatePattern")) ? DateUtil.DATE_PATTERN_1 : PropertyUtil.getPropertyValue("wsDatePattern");	
	
	//默认时间格式
	public static final String TIMESTAMPS_PATTERN = StringUtil.isEmpty(PropertyUtil.getPropertyValue("wsTimestampsPattern")) ? DateUtil.TIMESTAMPS_PATTERN_1 : PropertyUtil.getPropertyValue("wsTimestampsPattern");
	
	//WebService地址前缀
	public static final String SERVICE_URL_PREFIX = PropertyUtil.getPropertyValue("serviceUrlPrefix");
	
	//TargetNamespace地址
	public static final String TARGET_NAMESPACE = PropertyUtil.getPropertyValue("targetNamespace");
	
	//HTTP METHOD
	public static final String HTTP_METHOD = StringUtil.isEmpty(PropertyUtil.getPropertyValue("httpMethod")) ? "POST" : PropertyUtil.getPropertyValue("httpMethod");
	
	//连接超时时间
	public static final long CONNECTION_TIMEOUT = StringUtil.isEmpty(PropertyUtil.getPropertyValue("connectionTimeout")) ? 1000 * 60 : Long.parseLong(PropertyUtil.getPropertyValue("connectionTimeout"));

}
