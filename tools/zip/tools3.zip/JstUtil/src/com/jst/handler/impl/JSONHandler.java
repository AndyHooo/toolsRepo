package com.jst.handler.impl;

import java.util.Collection;
import java.util.Iterator;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.dom4j.DocumentException;

import com.jst.config.ObjectSerializeConfig;
import com.jst.constant.Message;
import com.jst.handler.MessageHandler;
import com.jst.type.DataType;
import com.jst.util.JsonUtil;
import com.jst.serializer.ObjectSerializer;

/**
 * 
 * <p>Title: JSONHandler.java</p>
 * <p>Description: 此处理类用于包装及解析JSON报文</p>
 * @author lee
 * @date 2015年6月8日
 * @version 1.0
 */
public class JSONHandler implements MessageHandler {
	
	//日志
	@SuppressWarnings("unused")
	private static final Log log = LogFactory.getLog(JSONHandler.class);
	
	//保存json
	private JSONObject json;
	
	//保存msg
	private JSONObject msg;
	
	//保存head节点
	private JSONObject head;
	
	//保存body节点
	private JSONArray body;
	
	//记录当前map位置
	private int loopIndex = 0;
	
	/**
	 * @see 包装JSON报文时调用此方法创建实例
	 */
	public JSONHandler() {
		json = JsonUtil.createJsonObject().accumulate(
				Message.ROOT_NAME,
				JsonUtil.createJsonObject()
						.accumulate(Message.HEAD_NAME,
								JsonUtil.createJsonObject())
						.accumulate(Message.BODY_NAME,
								JsonUtil.createJsonArray()));
		
		msg = JsonUtil.getObject(json, Message.ROOT_JSON_PATH);
		
		head = JsonUtil.getObject(json, Message.HEAD_JSON_PATH);
		body = JsonUtil.getObject(json, Message.BODY_JSON_PATH);
	}
	
	/**
	 * @see 解析报文时调用此方法创建实例
	 * @param text
	 */
	public JSONHandler(String text) {
		json = JsonUtil.parseJSONObject(text); 
		
		msg = JsonUtil.getObject(json, Message.ROOT_JSON_PATH);
		head = JsonUtil.getObject(json, Message.HEAD_JSON_PATH);
		
		if (JsonUtil.hasObject(json, Message.BODY_JSON_PATH)) {
			body = JsonUtil.getObject(json, Message.BODY_JSON_PATH);
		}
	}

	/**
	 * @see 向头部节点中添加参数
	 * @param paramName
	 * @param paramValue
	 */
	@Override
	public void addHeadParam(String paramName, String paramValue) {
		head.put(paramName, paramValue);
	}

	/**
	 * @see 向头部节点中添加参数
	 * @param nodeName
	 * @param map
	 */
	@Override
	public void addHeadParam(String nodeName, Map<String, String> map) {
		JSONObject object = JsonUtil.createJsonObject();
		
		for (Iterator<String> it = map.keySet().iterator(); it.hasNext();) {
			String paramName = it.next();
			String paramValue = map.get(paramName);
			
			object.accumulate(paramName, paramValue);
		}

		head.accumulate(nodeName, object);
	}

	/**
	 * @see 向头部节点中添加对象，自动序列化
	 * @param object
	 * @param serializeConfig
	 */
	@Override
	public void addHeadParam(Object object, ObjectSerializeConfig serializeConfig) throws DocumentException {
		JSONObject jsonObject = JsonUtil.parseJSONObject(ObjectSerializer.getInstance(DataType.JSON, serializeConfig).serialize(object));
		
		head.accumulate(JsonUtil.getRootName(jsonObject), JsonUtil.getRootObject(jsonObject));
	}
	
	/**
	 * @see 向身体节点中添加参数
	 * @param paramName
	 * @param paramValue
	 * @param loop
	 */
	@Override
	public void addBodyParam(String paramName, String paramValue, boolean loop) {
		if (loop) {
			if (0 == loopIndex) {
				body.add(JsonUtil.createJsonObject().accumulate(Message.RECORD_NAME, JsonUtil.createJsonArray()));
				
				body.getJSONObject(0).getJSONArray(Message.RECORD_NAME).add(JsonUtil.createJsonObject());
			}
			
			if (body.getJSONObject(0).getJSONArray(Message.RECORD_NAME).getJSONObject(loopIndex).containsKey(paramName)) {
				body.getJSONObject(0).getJSONArray(Message.RECORD_NAME).add(JsonUtil.createJsonObject());
				loopIndex++;
			}
			
			body.getJSONObject(0).getJSONArray(Message.RECORD_NAME).getJSONObject(loopIndex).accumulate(paramName, paramValue);
		} else {
			if (0 == loopIndex) {
				body.add(JsonUtil.createJsonObject().accumulate(Message.RECORD_NAME, JsonUtil.createJsonObject()));
			}
			
			body.getJSONObject(0).getJSONObject(Message.RECORD_NAME).put(paramValue, paramValue);
			
			loopIndex++;
		}
	}

	/**
	 * @see 向身体节点中添加对象，自动序列化
	 * @param object
	 * @param serializeConfig
	 */
	@Override
	public void addBodyParam(Object object, ObjectSerializeConfig serializeConfig) throws DocumentException {
		body.add(JsonUtil.parseJSONObject(ObjectSerializer.getInstance(DataType.JSON, serializeConfig).serialize(object)));
	}
	
	/**
	 * @see 向身体节点中添加集合，自动序列化
	 * @param object
	 * @param serializeConfig
	 */
	@Override
	public void addBodyParam(Collection<?> collection, ObjectSerializeConfig serializeConfig) throws DocumentException {
		JSONArray jsonArray = JsonUtil.getRootObject(JsonUtil.parseJSONObject(ObjectSerializer.getInstance(DataType.JSON, serializeConfig).serialize(collection))); 
		
		body.addAll(JSONArray.toCollection(jsonArray)); 
	}
	
	/**
	 * @see 生成请求报文
	 */
	@Override
	public String generateRequestMessage() {
		msg.remove(Message.BODY_NAME);
		
		return json.toString();
	}
	
	/**
	 * @see 生成响应报文
	 */
	@Override
	public String generateResponseMessage() {
		if (body.isEmpty()) {
			msg.remove(Message.BODY_NAME);
		}
		
		return json.toString();
	}

	/**
	 * @see 根据JsonPath获取值
	 * @param jsonPath
	 */
	@Override
	public String getParamValue(String jsonPath) {
		return JsonUtil.getObject(json, jsonPath).toString();
	}
	
}
