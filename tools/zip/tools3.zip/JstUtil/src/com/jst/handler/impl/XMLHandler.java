package com.jst.handler.impl;

import java.util.Collection;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.Node;

import com.jst.config.ObjectSerializeConfig;
import com.jst.constant.Message;
import com.jst.handler.MessageHandler;
import com.jst.model.EasyuiGrid;
import com.jst.serializer.ObjectSerializer;
import com.jst.type.DataType;
import com.jst.util.Dom4jUtil;
import com.jst.util.MessageHandlerUtil;
import com.jst.util.StringUtil;

/**
 * 
 * <p>
 * Title: XMLHandler.java
 * </p>
 * <p>
 * Description: 此处理类用于包装及解析XML报文
 * </p>
 * 
 * @author lee
 * @date 2015年6月8日
 * @version 1.0
 */
public class XMLHandler implements MessageHandler {

	// 日志
	private static final Log log = LogFactory.getLog(XMLHandler.class);

	// 保存文档
	private Document document;

	// 保存msg节点
	private Element root;

	// 保存head节点
	private Element head;

	// 保存body节点
	private Element body;

	// 记录当前map位置
	private int loopIndex = 0;

	/**
	 * @see 包装报文时，使用此方法创建实例
	 */
	public XMLHandler() {
		root = Dom4jUtil.createElement(Message.ROOT_NAME);

		head = root.addElement(Message.HEAD_NAME);
		body = root.addElement(Message.BODY_NAME);

		document = Dom4jUtil.createDocument(root);

		document.setXMLEncoding(StringUtil.DEFAULT_ENCODING);
	}

	/**
	 * @see 解析报文时，使用此方法创建实例
	 * @param text
	 * @throws DocumentException
	 */
	public XMLHandler(String text) throws DocumentException {
		try {
			document = Dom4jUtil.parseText(text);

			root = (Element) Dom4jUtil.getNode(document, Message.ROOT_XML_PATH);
			head = (Element) Dom4jUtil.getNode(document, Message.HEAD_XML_PATH);

			if (Dom4jUtil.hasNode(document, Message.BODY_XML_PATH)) {
				body = (Element) Dom4jUtil.getNode(document, Message.BODY_XML_PATH);
			}
		} catch (DocumentException e) {
			log.error("initialize XmlHandler error: " + e);

			throw e;
		}
	}

	/**
	 * @see 向头部节点中添加参数
	 * @param paramName
	 * @param paramValue
	 */
	@Override
	public void addHeadParam(String paramName, String paramValue) {
		if (Dom4jUtil.hasNode(head, "/" + Message.HEAD_NAME + "/" + paramName)) {
			Dom4jUtil.getNode(head, "/" + Message.HEAD_NAME + "/" + paramName).setText(paramValue);
		} else {
			head.addElement(paramName).setText(paramValue);
		}
	}

	/**
	 * @see 向头部节点中添加参数
	 * @param nodeName
	 * @param map
	 */
	@Override
	public void addHeadParam(String nodeName, Map<String, String> map) {
		Element element = head.addElement(nodeName);

		for (Iterator<String> it = map.keySet().iterator(); it.hasNext();) {
			String paramName = it.next();
			String paramValue = map.get(paramName);

			element.addElement(paramName).setText(paramValue);
		}
	}

	/**
	 * @see 向头部节点中添加对象，自动序列化
	 * @param object
	 * @param serializeConfig
	 */
	@Override
	public void addHeadParam(Object object, ObjectSerializeConfig serializeConfig) throws DocumentException {
		try {
			head.add(Dom4jUtil.parseText(ObjectSerializer.getInstance(DataType.XML, serializeConfig).serialize(object)).getRootElement());
		} catch (DocumentException e) {
			log.error("addHeadParam error: " + e);

			throw e;
		}
	}

	/**
	 * @see 向身体节点中添加参数，loop代表是否循环添加
	 * @param paramName
	 * @param paramValue
	 * @param loop
	 */
	@Override
	public void addBodyParam(String paramName, String paramValue, boolean loop) {
		if (loop) {
			if (0 == loopIndex) {
				body.addElement(Message.RECORD_NAME);
			}

			if (Dom4jUtil.hasNode(body, Message.RECORD_XML_PATH + "/" + paramName)) {
				body.addElement(Message.RECORD_NAME);

				loopIndex++;
			}

			((Element) Dom4jUtil.getNodeList(body, Message.RECORD_XML_PATH).get(0)).addElement(paramName).setText(paramValue);
		} else {
			body.addElement(paramName).setText(paramValue);
		}
	}

	/**
	 * @see 向头部节点中添加对象，自动序列化
	 * @param object
	 * @param serializeConfig
	 */
	@Override
	public void addBodyParam(Object object, ObjectSerializeConfig serializeConfig) throws DocumentException {
		try {
			body.add(Dom4jUtil.parseText(ObjectSerializer.getInstance(DataType.XML, serializeConfig).serialize(object)).getRootElement());
		} catch (DocumentException e) {
			log.error("addBodyParam: " + e);

			throw e;
		}
	}

	/**
	 * @see 向头部节点中添加集合，自动序列化
	 * @param collection
	 * @param serializeConfig
	 */
	@Override
	public void addBodyParam(Collection<?> collection, ObjectSerializeConfig serializeConfig) throws DocumentException {
		try {
			Dom4jUtil.appendElement(body, Dom4jUtil.getChildNodeList(Dom4jUtil.parseText(ObjectSerializer.getInstance(DataType.XML, serializeConfig).serialize(collection)).getRootElement()).toArray(new Node[] {}));
		} catch (DocumentException e) {
			log.error("addBodyParam: " + e);

			throw e;
		}
	}

	/**
	 * @see 生成请求报文
	 */
	@Override
	public String generateRequestMessage() {
		body.detach();

		return document.asXML();
	}

	/**
	 * @see 生成响应报文
	 */
	@Override
	public String generateResponseMessage() {
		if (!body.hasContent()) {
			body.detach();
		}

		return document.asXML();
	}

	/**
	 * @see 根据XPATH获取值
	 * @param xPath
	 */
	@Override
	public String getParamValue(String xPath) {
		return Dom4jUtil.getNodeValue(document, xPath);
	}
	
	public static void main(String[] args) throws DocumentException {
		EasyuiGrid eg = new EasyuiGrid();
		eg.setRowCount(123);
		MessageHandler handler = MessageHandlerUtil.getMessageHandler(DataType.XML);
		
		handler.addHeadParam(Message.RET_CODE_NAME, Message.RET_CODE_SUCCESS);
		handler.addHeadParam(Message.RET_MSG_NAME, "获取数据成功");
		
		ObjectSerializeConfig serializeConfig = new ObjectSerializeConfig();
		
		serializeConfig.setObjectAlias(EasyuiGrid.class, Message.RECORD_NAME);

		log.debug("设置身体返回信息，序列化对象列表");
		handler.addBodyParam(eg, serializeConfig);
		
		System.out.println(handler.generateResponseMessage().toString());
	}
}
