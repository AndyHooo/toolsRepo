package com.jst.handler;

import java.util.Collection;
import java.util.Map;

import org.dom4j.DocumentException;

import com.jst.config.ObjectSerializeConfig;

/**
 * 
 * <p>Title: MessageHandler.java</p>
 * <p>Description: 此接定义了包装及解析报文的基本方法</p>
 * @author lee
 * @date 2015年6月8日
 * @version 1.0
 */
public abstract interface MessageHandler {
	
	public void addHeadParam(String paramName, String paramValue);
	
	public void addHeadParam(String nodeName, Map<String, String> map);
	
	public void addHeadParam(Object object, ObjectSerializeConfig serializeConfig) throws DocumentException;
	
	public void addBodyParam(String paramName, String paramValue, boolean loop);
	
	public void addBodyParam(Object object, ObjectSerializeConfig serializeConfig) throws DocumentException;
	
	public void addBodyParam(Collection<?> collection, ObjectSerializeConfig serializeConfig) throws DocumentException;
	
	public String generateRequestMessage();
	
	public String generateResponseMessage();
	
	public String getParamValue(String path);
	
}
