package com.jst.cache;

import java.util.List;

import com.jst.model.CacheStatistics;

/**
 * 
 * <p>Title: Cache.java</p>
 * <p>Description: 缓存对象</p>
 * @author lee
 * @date 2015年7月29日
 * @version 1.0
 */
public interface Cache {

	/**
	 * @see 添加缓存
	 * @param key
	 * @param value
	 * @throws Exception
	 */
	public void add(Object key, Object value) throws Exception;
	
	/**
	 * @see 删除缓存
	 * @param key
	 * @throws Exception
	 */
	public void delete(Object key) throws Exception;
	
	/**
	 * @see 删除全部缓存
	 * @throws Exception
	 */
	public void deleteAll() throws Exception;
	
	/**
	 * @see 更新缓存
	 * @param key
	 * @param value
	 * @throws Exception
	 */
	public void update(Object key, Object value) throws Exception;
	
	/**
	 * @see 获取缓存
	 * @param key
	 * @return Object
	 * @throws Exception
	 */
	public Object get(Object key) throws Exception;
	
	/**
	 * @see 获取全部缓存
	 * @return List<Object>
	 * @throws Exception
	 */
	public List<Object> getAll() throws Exception;

	/**
	 * @see 获取缓存统计对象
	 * @return CacheStatistics
	 * @throws Exception
	 */
	public CacheStatistics getCacheStatistics() throws Exception;
	
}
