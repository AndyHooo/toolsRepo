package com.jst.cache.ehcache;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.jst.cache.Cache;
import com.jst.cache.CacheManager;
import com.jst.util.StringUtil;

/**
 * 
 * <p>Title: EhcacheManager.java</p>
 * <p>Description: Ehcache缓存管理</p>
 * @author lee
 * @date 2015年7月29日
 * @version 1.0
 */
public class EhcacheManager implements CacheManager {
	
	//日志
	private static final Log log = LogFactory.getLog(EhcacheManager.class);
	
	private net.sf.ehcache.CacheManager manager = net.sf.ehcache.CacheManager.getInstance();

	/**
	 * @see 获取缓存
	 * @param name
	 * @return Cache
	 * @throws Exception
	 */
	public Cache getCache(String name) throws Exception {
		log.debug("get cache begin");
		
		log.debug("name: " + name);
		
		Ehcache ehcache = null;
		try {
			if (StringUtil.isNotEmpty(name)) {
				if (!manager.cacheExists(name)) {
					log.debug("Could not find configuration [" + name + "]; using defaults.");
					
					manager.addCache(name);
				}
				
				ehcache = new Ehcache(manager.getCache(name));
			}
		} catch (Exception e) {
			log.error("error: " + e, e);
			
			throw e;
		}
		
		log.debug("get cache end");
		
		return ehcache;
	}

	/**
	 * @see 启动缓存
	 * @throws Exception
	 */
	public void start() throws Exception {
		
	}

	/**
	 * @see 停止缓存
	 * @throws Exception
	 */
	public void stop() throws Exception {
		
	}

}
