package com.jst.cache.ehcache;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import net.sf.ehcache.Element;
import net.sf.ehcache.Statistics;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.jst.cache.Cache;
import com.jst.model.CacheStatistics;

public class Ehcache implements Cache {
	
	private static final Log log = LogFactory.getLog(Ehcache.class);
	
	private net.sf.ehcache.Ehcache cache;
	
	public Ehcache(net.sf.ehcache.Ehcache cache) {
		this.cache = cache;
	}
	
	/**
	 * @see 获取Ehcache统计对象
	 * @return Statistics
	 */
	private Statistics _getStatistics() {
		return cache.getStatistics();
	}

	/**
	 * @see 添加缓存
	 * @param key
	 * @param value
	 * @throws Exception
	 */
	public void add(Object key, Object value) throws Exception {
		log.debug("add cache begin");
		
		log.debug("key: " + key);
		log.debug("value: " + value);
		
		try {
			cache.put(new Element(key, value));
		} catch (Exception e) {
			log.error("add cache error: " + e, e);
			
			throw e;
		}
		
		log.debug("add cache end");
	}

	/**
	 * @see 删除缓存
	 * @param key
	 * @throws Exception
	 */
	public void delete(Object key) throws Exception {
		log.debug("delete cache begin");
		
		log.debug("key: " + key);
		
		try {
			cache.remove(key);
		} catch (Exception e) {
			log.error("delete cache error: " + e, e);
			
			throw e;
		}
		
		log.debug("delete cache end");
	}
	
	/**
	 * @see 删除全部缓存
	 * @throws Exception
	 */
	public void deleteAll() throws Exception {
		log.debug("delete all cache begin");
		
		try {
			cache.removeAll();
		} catch (Exception e) {
			log.error("delete all cache error: " + e, e);
			
			throw e;
		}
		
		log.debug("delete all cache end");
	}

	/**
	 * @see 更新缓存
	 * @param key
	 * @param value
	 * @throws Exception
	 */
	public void update(Object key, Object value) throws Exception {
		log.debug("update cache begin");
		
		log.debug("key: " + key);
		log.debug("value: " + value);
		
		try {
			cache.put(new Element(key, value));
		} catch (Exception e) {
			log.error("update cache error: " + e, e);
			
			throw e;
		}
		
		log.debug("update cache end");
	}

	/**
	 * @see 获取缓存
	 * @param key
	 * @return Object
	 * @throws Exception
	 */
	public Object get(Object key) throws Exception {
		log.debug("get cache begin");
		
		log.debug("key: " + key);
		
		Object value = null;
		
		try {
			Element element = cache.get(key);
			
			if (null != element) {
				value = element.getObjectValue();
			} else {
				log.debug("Could not find element indexed with " + key + "; return null.");
			}
		} catch (Exception e) {
			log.error("get cache error: " + e, e);
			
			throw e;
		}
		
		log.debug("get cache end");
		
		return value;
	}
	
	/**
	 * @see 获取全部缓存
	 * @return List<Object>
	 * @throws Exception
	 */
	public List<Object> getAll() throws Exception {
		log.debug("get all cache begin");

		List<Object> list = null;
		
		try {
			Map<Object, Element> map = cache.getAll(cache.getKeys());
			
			if (null != map && map.size() > 0) {
				list = new ArrayList<Object>();
				
				for (Iterator<Object> it = map.keySet().iterator(); it.hasNext();) {
					list.add(map.get(it.next()).getObjectValue());
				}
			}
		} catch (Exception e) {
			log.error("get all cache error: " + e, e);
			
			throw e;
		}
		
		log.debug("get all cache end");
		
		return list;
	}
	
	/**
	 * @see 获取缓存统计对象
	 * @return CacheStatistics
	 * @throws Exception
	 */
	public CacheStatistics getCacheStatistics() {
		log.debug("get cache statistics begin");
		
		CacheStatistics cs = new CacheStatistics();
		
		try {
			Statistics statistics = _getStatistics();
			
			long memoryStoreObjectSize = cache.calculateInMemorySize();
			long diskStoreObjectSize = cache.calculateOnDiskSize();
			long offHeapStoreObjectSize = cache.calculateOffHeapSize();
			
			long storeObjectSize = memoryStoreObjectSize + diskStoreObjectSize + offHeapStoreObjectSize;
			
			cs.setObjectCount(statistics.getObjectCount());
			cs.setObjectSize(storeObjectSize);
			cs.setAverageGetTime((long) statistics.getAverageGetTime());
			cs.setAverageSearchTime(statistics.getAverageSearchTime());
			cs.setSearchesPerSecond(statistics.getSearchesPerSecond());
			
			cs.setCacheHits(statistics.getCacheHits());
			cs.setCacheMisses(statistics.getCacheMisses());
			
			cs.setEvictionCount(statistics.getEvictionCount());
			
			cs.setMemoryStoreObjectCount(statistics.getMemoryStoreObjectCount());
			cs.setMemoryStoreObjectSize(memoryStoreObjectSize);
			
			cs.setInMemoryHits(statistics.getInMemoryHits());
			cs.setInMemoryMisses(statistics.getInMemoryMisses());
			
			cs.setDiskStoreObjectCount(statistics.getDiskStoreObjectCount());
			cs.setDiskStoreObjectSize(diskStoreObjectSize);
			
			cs.setOnDiskHits(statistics.getOnDiskHits());
			cs.setOnDiskMisses(statistics.getOnDiskMisses());
			
			cs.setOffHeapStoreObjectCount(statistics.getOffHeapStoreObjectCount());
			cs.setOffHeapStoreObjectSize(offHeapStoreObjectSize);
			
			cs.setOffHeapHits(statistics.getOffHeapHits());
			cs.setOffHeapMisses(statistics.getOffHeapMisses());
		} catch (Exception e) {
			log.error("get cache statistics error: " + e, e);
		}
		
		log.debug("get cache statistics end");
		
		return cs;
	}

}
