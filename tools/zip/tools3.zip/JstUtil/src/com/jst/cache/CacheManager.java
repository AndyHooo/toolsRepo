package com.jst.cache;

/**
 * 
 * <p>Title: CacheManager.java</p>
 * <p>Description: 缓存管理</p>
 * @author lee
 * @date 2015年7月29日
 * @version 1.0
 */
public interface CacheManager {

	/**
	 * @see 获取缓存
	 * @param name
	 * @return Cache
	 * @throws Exception
	 */
	public Cache getCache(String name) throws Exception;
	
	/**
	 * @see 启动缓存
	 * @throws Exception
	 */
	public void start() throws Exception;
	
	/**
	 * @see 停止缓存
	 * @throws Exception
	 */
	public void stop() throws Exception;
	
}
