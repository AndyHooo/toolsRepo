package com.jst.type;

/**
 * 
 * <p>Title: DataType.java</p>
 * <p>Description: 此枚举封装了报文的类型</p>
 * @author lee
 * @date 2015年6月8日
 * @version 1.0
 */
public enum DataType {
	JSON, XML;
}
