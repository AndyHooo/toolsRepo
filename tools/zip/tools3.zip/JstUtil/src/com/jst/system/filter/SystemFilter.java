package com.jst.system.filter;

import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.jst.model.EasyuiGrid;
import com.jst.system.wrapper.XssRequestWrapper;
import com.jst.util.JsonUtil;
import com.jst.util.PropertyUtil;
import com.jst.util.RequestUtil;
import com.jst.util.StringUtil;

/**
 * 
 * <p>
 * Title: SystemFilter.java
 * </p>
 * <p>
 * Description: 此过滤器用于防御XSS等攻击
 * </p>
 * 
 * @author lee
 * @date 2015年3月2日
 * @version 1.0
 */
public class SystemFilter implements Filter {
	private Logger log = Logger.getLogger(SystemFilter.class);
	private String encoding;
	private boolean forceEncoding = false;
	private String[] illegalChars;

	public void init(FilterConfig filterConfig) throws ServletException {
		this.encoding = filterConfig.getInitParameter("encoding");
		this.forceEncoding = Boolean.parseBoolean(filterConfig.getInitParameter("forceEncoding"));

		this.illegalChars = filterConfig.getInitParameter("illegalChars").split(",");
	}

	@SuppressWarnings("deprecation")
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain filterChain) throws IOException, ServletException {
		this.log.debug("systemFilter begin");

		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse res = (HttpServletResponse) response;

		if ((this.encoding != null) && ((this.forceEncoding) || (req.getCharacterEncoding() == null))) {
			this.log.debug("set request character enconding: " + this.encoding);
			req.setCharacterEncoding(this.encoding);

			if (this.forceEncoding) {
				this.log.debug("set response character enconding: " + this.encoding);
				res.setCharacterEncoding(this.encoding);
			}
		}

		this.log.debug("set property Set-Cookie: HttpOnly");
		res.setHeader("Set-Cookie", "name=value; HttpOnly");

		String requestUri = req.getRequestURI();

		this.log.debug("待过滤链接：" + requestUri);

		String basePath = req.getScheme() + "://" + req.getServerName();

		String referer = req.getHeader("referer");

		String filterIp = PropertyUtil.getPropertyValue("filter.ip");
		
		String [] filterIpArr = null;
		boolean filterIpFlag = false;
		if(StringUtil.isNotEmpty(filterIp)){
			filterIpArr = filterIp.split(";");
			if(null != filterIpArr){
				for(int i = 0 ;i < filterIpArr.length ; i++){
					if(null != referer && referer.contains(filterIpArr[i])){
						filterIpFlag = true;
						break;
					}
				}
			}
			else{
				filterIpFlag = true;
			}
		}else{
			filterIpFlag = true;
		}
		
		log.debug("开始检测跨站点请求伪造攻击");
		if(null != referer && referer.indexOf(basePath) < 0 && (StringUtil.isEmpty(filterIp)||StringUtil.isNotEmpty(filterIp)&&!filterIpFlag)){
			this.log.debug("发现跨站点请求伪造攻击，转跳回前一页面");

			res.setContentType("text/html;charset=" + this.encoding);
			res.getWriter().print("<script>window.alert('跨站点请求伪造攻击');window.history.go(-1);</script>");

			this.log.debug("systemFilter end");

			return;
		}

		this.log.debug("未发现发现跨站点请求伪造攻击");

		Enumeration<?> params = req.getParameterNames();

		boolean executable = true;

		boolean illegalStatus = false;
		String illegalChar = "";

		while (params.hasMoreElements()) {
			String paramName = (String) params.nextElement();

			executable = true;

			if (paramName.toLowerCase().contains("password")) {
				executable = false;
			}

			if (executable) {
				String[] paramValues = req.getParameterValues(paramName);

				for (int i = 0; i < paramValues.length; i++) {
					String paramValue = paramValues[i];

					for (int j = 0; j < this.illegalChars.length; j++) {
						illegalChar = this.illegalChars[j];

						if (paramValue.indexOf(illegalChar) != -1) {
							illegalStatus = true;
							break;
						}
					}

					if (illegalStatus) {
						break;
					}
				}
			}

			if (illegalStatus) {
				break;
			}
		}

		if (illegalStatus) {
			this.log.debug("当前链接中存在非法字符：" + illegalChar);

			res.setContentType("text/html;charset=" + this.encoding);
			res.setCharacterEncoding(this.encoding);

			if (RequestUtil.isSynchronized(req)) {
				this.log.debug("当前请求为同步");
				this.log.debug("转跳到前一页面");

				res.getWriter().print("<script>window.alert('当前链接中存在非法字符');window.history.go(-1);</script>");
			} else {
				this.log.debug("当前请求为异步");
				this.log.debug("返回错误信息");

				if ((requestUri.indexOf("list") > -1) || (requestUri.indexOf("List") > -1))
					res.getWriter().print(EasyuiGrid.toString(Boolean.FALSE.booleanValue(), "您输入的信息有误，请重新输入", null, null));
				else {
					res.getWriter().print(JsonUtil.toErrorMsg("您输入的信息有误，请重新输入"));
				}
			}

			return;
		}
		filterChain.doFilter(new XssRequestWrapper(req), res);

		this.log.debug("systemFilter end");
	}

	public void destroy() {
		this.encoding = null;
		this.illegalChars = null;
	}
}