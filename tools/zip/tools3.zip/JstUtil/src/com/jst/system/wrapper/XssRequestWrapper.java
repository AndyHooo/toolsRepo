package com.jst.system.wrapper;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

import com.jst.util.StringUtil;

/**
 * 
 * <p>Title: XssRequestWrapper.java</p>
 * <p>Description: 此包装类用于防御XSS攻击</p>
 * @author lee
 * @date 2015年3月2日
 * @version 1.0
 */
public class XssRequestWrapper extends HttpServletRequestWrapper{

	public XssRequestWrapper(HttpServletRequest request) {
		super(request);
	}

	public Object getAttribute(String name) {
		return null == super.getAttribute(name) ? super.getAttribute(name) : super.getAttribute(name) instanceof String ? StringUtil.escapeHtml(super.getAttribute(name).toString()) : super.getAttribute(name);
	}
	
	public String getHeader(String name) {
		return StringUtil.isEmpty(super.getHeader(name)) ? super.getHeader(name) : StringUtil.escapeHtml(super.getHeader(name));
	}
	
	public String getParameter(String name) {
		return StringUtil.isEmpty(super.getParameter(name)) ? super.getParameter(name) : StringUtil.escapeHtml(super.getParameter(name));
	}
	
	public String[] getParameterValues(String name) {
		String[] parameterValues = super.getParameterValues(name);
		
		if(null != parameterValues){
			for(int i=0; i<parameterValues.length; i++){
				parameterValues[i] = StringUtil.escapeHtml(parameterValues[i]);
			}
		}
		
		return parameterValues;
	}
	
	public String getPathInfo() {
		return StringUtil.isEmpty(super.getPathInfo()) ? super.getPathInfo() : StringUtil.escapeHtml(super.getPathInfo());
	}
	
	public String getQueryString() {
		return StringUtil.isEmpty(super.getQueryString()) ? super.getQueryString() : StringUtil.escapeHtml(super.getQueryString());
	}
	
	public String getRequestURI() {
		return StringUtil.isEmpty(super.getRequestURI()) ? super.getRequestURI() : StringUtil.escapeHtml(super.getRequestURI());
	}
	
	public StringBuffer getRequestURL() {
		return StringUtil.isEmpty(super.getRequestURL().toString()) ? super.getRequestURL() : new StringBuffer(StringUtil.escapeHtml(super.getRequestURL().toString()));
	}
}
