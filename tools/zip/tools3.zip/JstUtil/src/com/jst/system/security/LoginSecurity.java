package com.jst.system.security;

import java.util.Date;
import java.util.Hashtable;
import java.util.Map;

import com.jst.util.DateUtil;

import com.jst.model.UserErrorInfo;

/**
 * 
 * <p>Title: LoginSecurity.java</p>
 * <p>Description: 此类用于登录安全管理，连续登录错误达到指定错误次数，锁定账户，禁止登陆</p>
 * @author lee
 * @date 2014年4月22日
 * @version 1.0
 */
public class LoginSecurity {
	
	//用户登录账号
	private String userCode;
	
	//解锁时间 
	private static final int UNLOCK_TIME = 5; 
	
	//最大错误次数
	private static final int MAX_ERROR_TIMES = 5; 

	//用户登录错误信息
	private static Map<String, UserErrorInfo> errorInfo = new Hashtable<String, UserErrorInfo>();
	
	
	/**
	 * @see 构造方法
	 */
	public LoginSecurity(){
		
	}
	
	/**
	 * @see 构造方法
	 * @param userCode
	 */
	public LoginSecurity(String userCode){
		this.userCode = userCode;
	}
	
	
	/**
	 * @see 查看当前用户登陆错误信息
	 * @return UserErrorInfo
	 */
	public UserErrorInfo getErrorInfo(){
		return errorInfo.get(userCode);
	}
	
	/**
	 * @see 查看当前用户错误登陆信息是否存在
	 *      存    在：false
	 *      不存在： true
	 * @return boolean
	 */
	private boolean isErrorInfoEmpty(){
		UserErrorInfo userErrorInfo = this.getErrorInfo();
		
		return null == userErrorInfo ? true : false;
	}
	
	/**
	 * @see 新增当前用户登陆错误信息
	 */
	public void addErrorInfo(){
		UserErrorInfo userErrorInfo = new UserErrorInfo();
		
		userErrorInfo.setErrorTime(new Date());
		userErrorInfo.setErrorCount(1);
		
		errorInfo.put(userCode, userErrorInfo);
	}
	
	/**
	 * @see 更新当前用户登陆错误信息
	 */
	public void updateErrorInfo(){
		UserErrorInfo userErrorInfo = this.getErrorInfo();
		
		int errorCount = userErrorInfo.getErrorCount();
		
		userErrorInfo.setErrorCount(errorCount + 1);
		
		errorInfo.put(userCode, userErrorInfo);
	}
	
	
	/**
	 * @see 设置当前用户登陆错误信息   
	 *      信息不存在：新增
	 *      信息已存在：更新
	 */
	public void setErrorInfo(){
		if(this.isErrorInfoEmpty()){
			this.addErrorInfo();
		}else{
			this.updateErrorInfo();
		}
	}
	
	
	/**
	 * @see 查看当前登陆用户锁定状态
	 *      锁    定：true
	 *      未锁定：false
	 * @return boolean
	 */
	public boolean isLocked(){
		UserErrorInfo userErrorInfo = this.getErrorInfo();
		
		return (userErrorInfo != null && userErrorInfo.getErrorCount() >= MAX_ERROR_TIMES) ? true : false; 
	}
	
	/**
	 * @see 获取当前系统时间与第一次错误登陆的时间差
	 * @return int
	 */
	public int getUnlockTime(){
		UserErrorInfo userErrorInfo = this.getErrorInfo();
		
		return DateUtil.getDateDifference(userErrorInfo.getErrorTime(), new Date(), "minute");
	}
	
	/**
	 * @see 获取当前已锁定用户剩余解锁时间
	 * @return int
	 */
	public int getUnlockTimeRemaining(){
		UserErrorInfo userErrorInfo = this.getErrorInfo();

		return UNLOCK_TIME - DateUtil.getDateDifference(userErrorInfo.getErrorTime(), new Date(), "minute");
	}
	
	/**
	 * @see 清除当前用户登陆错误信息
	 */
	public void clearErrorInfo(){
		errorInfo.remove(userCode);
	}
	
	/**
	 * @see 释放当前用户登陆锁
	 *      成功：true
	 *      失败：false
	 * @return boolean
	 */
	public boolean releaseLock(){
		int unlockTime = this.getUnlockTime();
		
		if(unlockTime >= UNLOCK_TIME){
			this.clearErrorInfo();
			
			return true;
		}
		
		return false;
	}
	
}
