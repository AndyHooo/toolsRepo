package com.jst.platformClient.entity;

import java.util.Date;

/**
 * 操作日志实体类
 */
public class OpeLog implements java.io.Serializable {

    // Fields    
    private Long logId;
    private String appCode;
    private String opeType;
    private String objType;
    private String objId;
    private String opeUserCode;
    private String opeUserName;
    private Date opeTime;
    private String opeIp;
    private String remark;
    private String invokePage ;
    private String triggerPage ;
    private String mac ;

    @Override
	public String toString() {
		return "OpeLog [logId=" + logId + ", appCode=" + appCode + ", opeType="
				+ opeType + ", objType=" + objType + ", objId=" + objId
				+ ", opeUserCode=" + opeUserCode + ", opeUserName="
				+ opeUserName + ", opeTime=" + opeTime + ", opeIp=" + opeIp
				+ ", remark=" + remark + ", invokePage=" + invokePage
				+ ", triggerPage=" + triggerPage + ", mac=" + mac + "]";
	}
	// Constructors
    /** default constructor */
    public OpeLog() {
    }
    
    

    public String getInvokePage() {
		return invokePage;
	}



	public void setInvokePage(String invokePage) {
		this.invokePage = invokePage;
	}



	public String getTriggerPage() {
		return triggerPage;
	}



	public void setTriggerPage(String triggerPage) {
		this.triggerPage = triggerPage;
	}



	public String getMac() {
		return mac;
	}



	public void setMac(String mac) {
		this.mac = mac;
	}



	public OpeLog( String appCode, String opeType, String objType,
			String objId, String opeUserCode, String opeUserName, Date opeTime,
			String opeIp, String remark, String invokePage, String triggerPage,
			String mac) {
		super();
		this.logId = logId;
		this.appCode = appCode;
		this.opeType = opeType;
		this.objType = objType;
		this.objId = objId;
		this.opeUserCode = opeUserCode;
		this.opeUserName = opeUserName;
		this.opeTime = opeTime;
		this.opeIp = opeIp;
		this.remark = remark;
		this.invokePage = invokePage;
		this.triggerPage = triggerPage;
		this.mac = mac;
	}



	/** minimal constructor */
    public OpeLog(String appCode, String objType,String opeType,  String opeUserCode, Date opeTime, String opeIp) {
        this.appCode = appCode;
        this.opeType = opeType;
        this.objType = objType;
        this.opeUserCode = opeUserCode;
        this.opeTime = opeTime;
        this.opeIp = opeIp;
    }

    /** full constructor */
    public OpeLog(String objType,String opeType,  String objId, String opeUserCode, Date opeTime, String opeIp, String remark) {
        this.opeType = opeType;
        this.objType = objType;
        this.objId = objId;
        this.opeUserCode = opeUserCode;
        this.opeTime = opeTime;
        this.opeIp = opeIp;
        this.remark = remark;
    }

    /** full constructor */
    public OpeLog(String appCode, String opeType, String objType, String objId, String opeUserCode, String opeUserName, Date opeTime, String opeIp, String remark) {
        this.appCode = appCode;
        this.opeType = opeType;
        this.objType = objType;
        this.objId = objId;
        this.opeUserCode = opeUserCode;
        this.opeUserName = opeUserName;
        this.opeTime = opeTime;
        this.opeIp = opeIp;
        this.remark = remark;
    }

    // Property accessors
    public Long getLogId() {
        return this.logId;
    }

    public void setLogId(Long logId) {
        this.logId = logId;
    }

    public String getOpeType() {
        return this.opeType;
    }

    public void setOpeType(String opeType) {
        this.opeType = opeType;
    }

    public String getObjType() {
        return this.objType;
    }

    public void setObjType(String objType) {
        this.objType = objType;
    }

    public String getObjId() {
        return this.objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getOpeUser() {
        return this.opeUserCode;
    }

    public void setOpeUser(String opeUserCode) {
        this.opeUserCode = opeUserCode;
    }

    public Date getOpeTime() {
        return this.opeTime;
    }

    public void setOpeTime(Date opeTime) {
        this.opeTime = opeTime;
    }

    public String getOpeIp() {
        return this.opeIp;
    }

    public void setOpeIp(String opeIp) {
        this.opeIp = opeIp;
    }

    public String getRemark() {
        return this.remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getAppCode() {
        return this.appCode;
    }

    public void setAppCode(String appCode) {
        this.appCode = appCode;
    }

        public String getOpeUserCode() {
        return this.opeUserCode;
    }

    public void setOpeUserCode(String opeUserCode) {
        this.opeUserCode = opeUserCode;
    }

    public String getOpeUserName() {
        return this.opeUserName;
    }

    public void setOpeUserName(String opeUserName) {
        this.opeUserName = opeUserName;
    }


}
