/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.jst.platformClient.xml;

import java.io.File;
import java.io.StringReader;
import java.net.URL;
import java.util.List;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;
import org.jdom.xpath.XPath;
import org.xml.sax.InputSource;

public class JDomUtil {

	private SAXBuilder sb = new SAXBuilder();
	private Document doc = null;
	private Element root = null;

	public JDomUtil() {
	}

	public JDomUtil(SAXBuilder sb) {
		this.sb = sb;
	}

	public JDomUtil(Document doc) {
		this.doc = doc;
		this.root = doc.getRootElement();
	}

	public Document build(File xmlFile) throws Exception {
		this.doc = sb.build(xmlFile);

		return this.doc;
	}

	// error here
	public Document build(String xmlString) throws Exception {

		try {
			InputSource inputSource = new InputSource(new StringReader(
					xmlString));
			this.doc = sb.build(inputSource);
			this.root = doc.getRootElement();
		} catch (Exception e) {
			System.out.println("build exp:" + e.getMessage());
			e.printStackTrace();
		}

		return this.doc;
	}

	public Document build(URL xmlUrl) throws Exception {
		this.doc = sb.build(xmlUrl);

		return this.doc;
	}

	public Document getDocument() {
		return this.doc;
	}

	public Element getRoot() {
		return this.root;
	}

	public String getElementData(String elementName) throws Exception {

		String eleData = null;
		Element theElement = (Element) XPath.selectSingleNode(this.root,
				elementName);
		if (theElement != null)
			eleData = theElement.getTextTrim();
		return eleData;

	}

	public Element getElement(String elementName) throws Exception {
		return (Element) XPath.selectSingleNode(this.root, elementName);
	}

	public Element getElement(Object context, String elementName)
			throws Exception {
		return (Element) XPath.selectSingleNode(context, elementName);
	}

	public List getElementList(String elementName) throws Exception {
		return XPath.selectNodes(this.root, elementName);
	}

	public List getElementList(Object context, String elementName)
			throws Exception {
		return XPath.selectNodes(context, elementName);
	}

}
