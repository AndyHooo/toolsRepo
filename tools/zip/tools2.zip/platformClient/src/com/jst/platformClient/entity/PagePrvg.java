package com.jst.platformClient.entity;

/**
 * PagePrvg entity. @author MyEclipse Persistence Tools
 */

public class PagePrvg implements java.io.Serializable {

	// Fields

	private Integer id;
	private String pageName;
	private String mdlCode;
	private String controlId;
	private String prvgCode;
	private String remark;
	private Short sortId;
	private String appCode;

	// Constructors

	/** default constructor */
	public PagePrvg() {
	}

	/** minimal constructor */
	public PagePrvg(String pageName, String mdlCode, String controlId,
			String prvgCode) {
		this.pageName = pageName;
		this.mdlCode = mdlCode;
		this.controlId = controlId;
		this.prvgCode = prvgCode;
	}

	/** full constructor */
	public PagePrvg(String pageName, String mdlCode, String controlId,
			String prvgCode, String remark, Short sortId, String appcode) {
		this.pageName = pageName;
		this.mdlCode = mdlCode;
		this.controlId = controlId;
		this.prvgCode = prvgCode;
		this.remark = remark;
		this.sortId = sortId;
		this.appCode = appCode;
	}

	// Property accessors

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getPageName() {
		return this.pageName;
	}

	public void setPageName(String pageName) {
		this.pageName = pageName;
	}

	public String getMdlCode() {
		return this.mdlCode;
	}

	public void setMdlCode(String mdlCode) {
		this.mdlCode = mdlCode;
	}

	public String getControlId() {
		return this.controlId;
	}

	public void setControlId(String controlId) {
		this.controlId = controlId;
	}

	public String getPrvgCode() {
		return this.prvgCode;
	}

	public void setPrvgCode(String prvgCode) {
		this.prvgCode = prvgCode;
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Short getSortId() {
		return this.sortId;
	}

	public void setSortId(Short sortId) {
		this.sortId = sortId;
	}

	public String getAppCode() {
		return appCode;
	}

	public void setAppCode(String appCode) {
		this.appCode = appCode;
	}

	
}