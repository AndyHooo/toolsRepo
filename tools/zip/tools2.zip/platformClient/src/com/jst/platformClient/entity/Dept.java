package com.jst.platformClient.entity;


/**
 * Dept entity. @author MyEclipse Persistence Tools
 */

public class Dept implements java.io.Serializable {

	// Fields

	private Long deptId;
	private String deptName;
	private Long parentDeptId;
	private Integer deptType;
	private String remark;
	private Integer sortId;
	private Integer state;
	private String appCode;
	// Constructors

	/** default constructor */
	public Dept() {
	}

	/** minimal constructor */
	public Dept(String deptName, Long parentDeptId, Integer deptType,
			Integer state) {
		this.deptName = deptName;
		this.parentDeptId = parentDeptId;
		this.deptType = deptType;
		this.state = state;
	}
	/** full constructor */
	public Dept(String deptName, Long parentDeptId, Integer deptType,
			String remark, Integer sortId, Integer state, String appcode) {
		this.deptName = deptName;
		this.parentDeptId = parentDeptId;
		this.deptType = deptType;
		this.remark = remark;
		this.sortId = sortId;
		this.state = state;
		this.appCode = appCode;

	}
	public Dept(Long deptId ,String deptName, Long parentDeptId, Integer deptType,
			String remark, Integer sortId, Integer state) {
		
		this.deptId = deptId ;
		this.deptName = deptName;
		this.parentDeptId = parentDeptId;
		this.deptType = deptType;
		this.remark = remark;
		this.sortId = sortId;
		this.state = state;
	}

	// Property accessors

	public Long getDeptId() {
		return this.deptId;
	}

	public void setDeptId(Long deptId) {
		this.deptId = deptId;
	}

	public String getDeptName() {
		return this.deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public Long getParentDeptId() {
		return this.parentDeptId;
	}

	public void setParentDeptId(Long parentDeptId) {
		this.parentDeptId = parentDeptId;
	}

	public Integer getDeptType() {
		return this.deptType;
	}

	public void setDeptType(Integer deptType) {
		this.deptType = deptType;
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Integer getSortId() {
		return this.sortId;
	}

	public void setSortId(Integer sortId) {
		this.sortId = sortId;
	}

	public Integer getState() {
		return this.state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public String getAppCode() {
		return appCode;
	}

	public void setAppCode(String appCode) {
		this.appCode = appCode;
	}

	

}