package com.jst.platformClient.client;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.xml.namespace.QName;

import org.apache.axis2.addressing.EndpointReference;
import org.apache.axis2.client.Options;
import org.apache.axis2.rpc.client.RPCServiceClient;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.xpath.XPath;

import com.jst.platformClient.entity.Dept;
import com.jst.platformClient.entity.MdlPrvg;
import com.jst.platformClient.entity.OpeLog;
import com.jst.platformClient.entity.PagePrvg;
import com.jst.platformClient.entity.SysMdl;
import com.jst.platformClient.entity.User;
import com.jst.platformClient.entity.UserPrvg;
import com.jst.platformClient.utils.Assert;
import com.jst.platformClient.utils.Config;
import com.jst.platformClient.xml.JDomUtil;

/**
 * @author Administrator
 */
public class WebServiceClient {

	private static final Log log = LogFactory.getLog(WebServiceClient.class);
	final private String url = Config.getProperty("ws.url");
	final String default_ns_prefix = "http://ws.platform.jst.com";
	private static RPCServiceClient serviceClient = null;
	private Options options = null;
	public final String authCode = Config.getPathProperty("authCode");

	public WebServiceClient() throws Exception {

		try {
			serviceClient = new RPCServiceClient();

			options = serviceClient.getOptions();
			log.debug("url = " + url);
			log.debug("authCode = " + authCode);
			EndpointReference targetEPR = new EndpointReference(url);

			options.setTo(targetEPR);

			// options.setTimeOutInMilliSeconds(1000 * 60);// 60s
			options.setCallTransportCleanup(true);

			serviceClient.setOptions(options);
			// log.error("实例化 WebServiceClient 结束");

		} catch (Exception e) {
			// log.error("实例化 WebServiceClient 失败");
			throw e;
		}

	}

	/**
	 * 调用WebService
	 * 
	 * @param methodName
	 * @param paraArra
	 * @return
	 * @throws Exception
	 */
	public String callService(final String methodName, final Object[] paraArray)
			throws Exception {

		// log.debug("调用 callService 开始,methodName is" + url);
		try {
			Class[] resultClassArray = new Class[] { String.class };
			QName opAddEntry = new QName(default_ns_prefix, methodName);
			String result = (String) serviceClient.invokeBlocking(opAddEntry,
					paraArray, resultClassArray)[0];
			log.debug("调用 callService 方法 结束,result:" + result);
			close();
			return result;
		} catch (Exception e) {
			log.error("服务平台调用 失败", e);
			throw new Exception("服务平台调用失败：" + e.getMessage());
		}

	}

	public void close() {
		log.debug("调用 colse　开始");
		if (serviceClient != null) {
			try {
				serviceClient.cleanup();
				serviceClient.cleanupTransport();
			} catch (Exception e2) {
			}
		}
		log.debug("调用 colse 结束");
	}

	public void test() throws Exception {

		// 使用RPC方式调用WebService

		// 指定调用WebService的URL

		// 指定方法的参数值
		Object[] opAddEntryArgs = new Object[] { "001", "test", "test123" };
		// 指定方法返回值的数据类型的Class对象
		Class[] classes = new Class[] { String.class };
		// 指定要调用的方法及WSDL文件的命名空间
		QName opAddEntry = new QName("http://ws.apache.org/axis2", "checkLogin");
		// 调用方法并输出该方法的返回值

		String result = serviceClient.invokeBlocking(opAddEntry,
				opAddEntryArgs, classes)[0].toString();

		log.debug("result:" + result);

		JDomUtil jDomUtil = new JDomUtil();
		Document xmlDoc = jDomUtil.build(result);
		Element retCodeEle = (Element) XPath.selectSingleNode(xmlDoc,
				"//MSG//HEAD//RET_CODE");

		Element retMsgEle = (Element) XPath.selectSingleNode(xmlDoc,
				"//MSG//HEAD//RET_MSG");

		log.debug("ret_code:" + retCodeEle.getValue());
		log.debug("ret_msg:" + retMsgEle.getValue());

	}

	public String checkkLogin(String userCode, String pass) throws Exception {

		Boolean checkResult = null;
		String content = callService("checkLogin", new Object[] { authCode,
				userCode, pass });
		JDomUtil jDomUtil = new JDomUtil();
		Document xmlDoc = jDomUtil.build(content);
		String retCode = ((Element) XPath
				.selectSingleNode(xmlDoc, "//RET_CODE")).getValue();
		String retMsg = ((Element) XPath.selectSingleNode(xmlDoc, "//RET_MSG"))
				.getValue();
		if (retCode.equals("T")) {
			return retCode;
		} else {
			log.info(retMsg);
			return retMsg;
		}
	}

	/**
	 * 获取用户信息
	 * 
	 * @param userCode
	 * @return
	 * @throws Exception
	 */
	public User getUserInfo(final String userCode) throws Exception {

		String content = callService("getUserInfo", new Object[] { authCode,
				userCode });

		User user = null;

		JDomUtil jDomUtil = new JDomUtil();

		Document xmlDoc = jDomUtil.build(content);

		List<Element> nodeList = XPath.selectNodes(xmlDoc, "//REC");
		Element retCodeE = (Element) XPath.selectSingleNode(xmlDoc,
				"//RET_CODE");
		if ("F".equals(retCodeE.getText())) {
			Element retMsgE = (Element) XPath.selectSingleNode(xmlDoc,
					"//RET_MSG");
			throw new Exception("调用ws返回结果异常" + retMsgE.getText());
		}

		if (nodeList != null && nodeList.size() > 1) {
			throw new Exception("根据用户编码查出多于一个用户的信息");
		}
		if (nodeList != null && nodeList.size() == 1) {

			Element element = nodeList.get(0);
			user = new User();
			String userCodeTemp = element.getChildText("USER_CODE");
			String userName = element.getChildText("USER_NAME");
			String userPass = element.getChildText("USER_PASSWORD");
			String userType = element.getChildText("USER_TYPE");
			String deptId = element.getChildText("DEPT_ID");
			String state = element.getChildText("STATE");
			String sortId = element.getChildText("SORT_ID");
			String ifGrantLogin = element.getChildText("IF_GRANT_LOGIN");
			String remark = element.getChildText("REMARK");
			String remark1 = element.getChildText("REMARK1");
			String remark2 = element.getChildText("REMARK2");
			String remark3 = element.getChildText("REMARK3");
			user.setUserCode(checkNotNull(userCodeTemp) ? userCodeTemp : null);
			user.setUserName(checkNotNull(userName) ? userName : null);
			user.setUserPassword(checkNotNull(userPass) ? userPass : null);
			user.setUserType(checkNotNull(userType) ? Long.parseLong(userType)
					: null);
			user.setDeptId(checkNotNull(deptId) ? Long.parseLong(deptId) : null);
			user.setState(checkNotNull(state) ? Long.parseLong(state) : null);
			user.setSortId(checkNotNull(sortId) ? Long.parseLong(sortId) : null);
			user.setIfGrantLogin(checkNotNull(ifGrantLogin) ? Boolean
					.valueOf(ifGrantLogin) : null);
			user.setRemark(checkNotNull(remark) ? remark : null);
			user.setRemark1(checkNotNull(remark1) ? remark1 : null);
			user.setRemark2(checkNotNull(remark) ? remark2 : null);
			user.setRemark3(checkNotNull(remark) ? remark3 : null);
		}
		return user;

	}

	public void mergeUser(User user) throws Exception {

		String content = callService(
				"mergeUser",
				new Object[] { authCode, user.getUserCode(),
						user.getUserName(), user.getUserPassword(),
						user.getDeptId(), user.getUserType(),
						user.getIfGrantLogin(), user.getState(),
						user.getSortId(), user.getRemark(), user.getRemark1(),
						user.getRemark2(), user.getRemark3() });

		// System.out.println(content);
		JDomUtil jDomUtil = new JDomUtil();
		Document xmlDoc = jDomUtil.build(content);
		Element retCodeEle = (Element) XPath.selectSingleNode(xmlDoc,
				"//RET_CODE");
		if (retCodeEle.getValue().equals("T")) {
			return;
		} else {
			Element retMsgEle = (Element) XPath.selectSingleNode(xmlDoc,
					"//RET_MSG");
			throw new Exception("webservice服务端返回错误:" + retMsgEle.getValue());
		}

	}

	/**
	 * 删除用户
	 * 
	 * @param userCode
	 * @throws Exception
	 */
	public void delteUser(String userCode) throws Exception {

		Options options = serviceClient.getOptions();
		// 设置调用WebService的URL
		String address = url;
		EndpointReference epf = new EndpointReference(address);
		options.setTo(epf);

		/**
		 * 设置将调用的方法，http://ws.apache.org/axis2是方法 默认（没有package）命名空间，如果有包名
		 * 就是http://service.hoo.com 包名倒过来即可 sayHello就是方法名称了
		 */

		QName qname = new QName("http://ws.platform.jst.com", "deleteUser");
		// 指定调用的方法和传递参数数据，及设置返回值的类型

		Object[] result = serviceClient.invokeBlocking(qname, new Object[] {
				authCode, userCode }, new Class[] { String.class });
		System.out.println(result[0]);

	}

	/**
	 * 获得满足条件的的记录
	 * 
	 * @param user
	 * @param pageNO
	 * @param pageSize
	 * @param orderBy
	 * @param order
	 * @return
	 * @throws Exception
	 */
	public List<User> getCurDeptUserAndNextDeptUser(Long currdeptId,
			String excludeUserCodes) throws Exception {

		Options options = serviceClient.getOptions();
		// 设置调用WebService的URL
		String address = url;
		EndpointReference epf = new EndpointReference(address);
		options.setTo(epf);

		/**
		 * 设置将调用的方法，http://ws.apache.org/axis2是方法 默认（没有package）命名空间，如果有包名
		 * 就是http://service.hoo.com 包名倒过来即可 sayHello就是方法名称了
		 */

		QName qname = new QName("http://ws.platform.jst.com",
				"getCurDeptUserAndNextDeptUser");
		// 指定调用的方法和传递参数数据，及设置返回值的类型

		Object[] result = serviceClient.invokeBlocking(qname, new Object[] {
				authCode, currdeptId, excludeUserCodes },
				new Class[] { String.class });
		close();
		System.out.println(result[0]);
		String content = (String) result[0];
		JDomUtil jDomUtil = new JDomUtil();
		Document xmlDoc = jDomUtil.build(content);

		List<Element> nodeList = XPath.selectNodes(xmlDoc, "//REC");
		Element retCodeE = (Element) XPath.selectSingleNode(xmlDoc,
				"//RET_CODE");
		if ("F".equals(retCodeE.getText())) {
			Element retMsgE = (Element) XPath.selectSingleNode(xmlDoc,
					"//RET_MSG");
			throw new Exception("调用ws返回结果异常" + retMsgE.getText());
		}
		List<User> listUser = new ArrayList<User>();
		for (Element element : nodeList) {
			User user = new User();
			String userCodeTemp = element.getChildText("USER_CODE");
			String userName = element.getChildText("USER_NAME");
			String userType = element.getChildText("USER_TYPE");
			String deptId = element.getChildText("DEPT_ID");
			String state = element.getChildText("STATE");
			// String sortId = element.getChildText("SORT_ID");
			// String ifGrantLogin = element.getChildText("IF_GRANT_LOGIN");
			user.setUserCode(checkNotNull(userCodeTemp) ? userCodeTemp : null);
			user.setUserName(checkNotNull(userName) ? userName : null);
			user.setUserType(checkNotNull(userType) ? Long.parseLong(userType)
					: null);
			user.setDeptId(checkNotNull(deptId) ? Long.parseLong(deptId) : null);
			user.setState(checkNotNull(state) ? Long.parseLong(state) : null);
			listUser.add(user);
		}

		return listUser;

	}

	public List<User> getUserlist(User user, int pageNo, int pageSize,
			String orderBy, String order) throws Exception {

		Options options = serviceClient.getOptions();
		// 设置调用WebService的URL
		String address = url;
		EndpointReference epf = new EndpointReference(address);
		options.setTo(epf);

		/**
		 * 设置将调用的方法，http://ws.apache.org/axis2是方法 默认（没有package）命名空间，如果有包名
		 * 就是http://service.hoo.com 包名倒过来即可 sayHello就是方法名称了
		 */

		QName qname = new QName("http://ws.platform.jst.com", "getUserList");
		// 指定调用的方法和传递参数数据，及设置返回值的类型

		Object[] result = serviceClient.invokeBlocking(
				qname,
				new Object[] { authCode, user.getUserCode(),
						user.getUserName(), null, user.getDeptId(),
						user.getUserType(), user.getIfGrantLogin(),
						user.getState(), user.getSortId(), "remark", "remark1",
						"remark2", "remark3", pageNo, pageSize, "userCode",
						"desc" }, new Class[] { String.class });

		System.out.println(result[0]);
		String content = (String) result[0];
		JDomUtil jDomUtil = new JDomUtil();
		Document xmlDoc = jDomUtil.build(content);

		List<Element> nodeList = XPath.selectNodes(xmlDoc, "//REC");
		Element retCodeE = (Element) XPath.selectSingleNode(xmlDoc,
				"//RET_CODE");
		if ("F".equals(retCodeE.getText())) {
			Element retMsgE = (Element) XPath.selectSingleNode(xmlDoc,
					"//RET_MSG");
			throw new Exception("调用ws返回结果异常" + retMsgE.getText());
		}
		List<User> listUser = new ArrayList<User>();
		for (Element element : nodeList) {
			user = new User();
			String userCodeTemp = element.getChildText("USER_CODE");
			String userName = element.getChildText("USER_NAME");
			String userType = element.getChildText("USER_TYPE");
			String deptId = element.getChildText("DEPT_ID");
			String state = element.getChildText("STATE");
			// String sortId = element.getChildText("SORT_ID");
			// String ifGrantLogin = element.getChildText("IF_GRANT_LOGIN");
			user.setUserCode(checkNotNull(userCodeTemp) ? userCodeTemp : null);
			user.setUserName(checkNotNull(userName) ? userName : null);
			user.setUserType(checkNotNull(userType) ? Long.parseLong(userType)
					: null);
			user.setDeptId(checkNotNull(deptId) ? Long.parseLong(deptId) : null);
			user.setState(checkNotNull(state) ? Long.parseLong(state) : null);
			listUser.add(user);
		}
		close();
		return listUser;

	}

	/**
	 * 获得满足条件产用户数量
	 * 
	 * @param user
	 * @return
	 * @throws Exception
	 */
	public Long getUserCounter(User user) throws Exception {

		Options options = serviceClient.getOptions();
		// 设置调用WebService的URL
		String address = url;
		EndpointReference epf = new EndpointReference(address);
		options.setTo(epf);

		/**
		 * 设置将调用的方法，http://ws.apache.org/axis2是方法 默认（没有package）命名空间，如果有包名
		 * 就是http://service.hoo.com 包名倒过来即可 sayHello就是方法名称了
		 */
		QName qname = new QName("http://ws.platform.jst.com", "getUserCounter");
		// 指定调用的方法和传递参数数据，及设置返回值的类型

		Object[] result = serviceClient.invokeBlocking(qname, new Object[] {
				authCode, "jack", "jack", "jack123", 2L, 1L, true, 1L, 999L,
				"remark", "remark1", "remark2", "remark3" },
				new Class[] { String.class });

		System.out.println(result[0]);
		close();
		return 1L;

	}

	/**
	 * 根据机构id获得机构信息
	 * 
	 * @return
	 * @throws Exception
	 */
	public Dept getDept(Long deptId) throws Exception {

		String content = callService("getDeptInfo", new Object[] { authCode,
				deptId });
		JDomUtil jDomUtil = new JDomUtil();
		Document xmlDoc = jDomUtil.build(content);
		Element retCodeE = (Element) XPath.selectSingleNode(xmlDoc,
				"//RET_CODE");
		if ("F".equals(retCodeE.getText())) {
			Element retMsgE = (Element) XPath.selectSingleNode(xmlDoc,
					"//RET_MSG");
			throw new Exception("调用ws返回结果异常" + retMsgE.getText());
		}
		List<Element> nodeList = XPath.selectNodes(xmlDoc, "//REC");
		if (nodeList != null && nodeList.size() > 1) {
			throw new Exception("根据id查出多于一个部分信息");
		}
		if (nodeList != null && nodeList.size() == 1) {
			Element element = nodeList.get(0);
			Dept d = new Dept();
			String deptIdStr = element.getChildText("DEPT_ID");
			System.out.println(deptIdStr);
			String dept_name = element.getChildText("DEPT_NAME");
			String parent_dept_id = element.getChildText("PARENT_DEPT_ID");
			String dept_type = element.getChildText("DEPT_TYPE");
			String remark = element.getChildText("REMARK");
			String sort_id = element.getChildText("SORT_ID");
			String state = element.getChildText("STATE");
			d.setDeptId(checkNotNull(deptIdStr) ? Long.valueOf(deptIdStr)
					: null);
			d.setDeptName(checkNotNull(dept_name) ? dept_name : null);
			d.setDeptType(checkNotNull(parent_dept_id) ? Integer
					.parseInt(parent_dept_id) : null);
			d.setRemark(checkNotNull(remark) ? remark : null);
			d.setSortId(checkNotNull(sort_id) ? Integer.parseInt(sort_id)
					: null);
			d.setState(checkNotNull(state) ? Integer.parseInt(state) : null);
			close();
			return d;
		}
		close();
		return null;
	}

	/**
	 * 新增或修改机构
	 * 
	 * @param dept
	 * @throws Exception
	 */
	public void mergeDept(Dept dept) throws Exception {

		String content = callService(
				"mergeDept",
				new Object[] { authCode, dept.getDeptId(), dept.getDeptName(),
						dept.getParentDeptId(), dept.getDeptType(),
						dept.getRemark(), dept.getSortId(), dept.getState() });
		close();
		JDomUtil jDomUtil = new JDomUtil();

		Document xmlDoc = jDomUtil.build(content);

		Element retCodeEle = (Element) XPath.selectSingleNode(xmlDoc,
				"//RET_CODE");

		if (retCodeEle.getValue().equals("T")) {
			return;
		} else {
			Element retMsgEle = (Element) XPath.selectSingleNode(xmlDoc,
					"//RET_MSG");
			throw new Exception("webservice服务端返回错误:" + retMsgEle.getValue());
		}

	}

	public void delteDept(Long deptId) {

		// callService(methodName, paraArray)

	}

	/**
	 * 获得机构列表
	 * 
	 * @param user
	 * @param pageNo
	 * @param pageSize
	 * @param orderBy
	 * @param order
	 * @return
	 * @throws Exception
	 */
	public List<Dept> getDeptListByTree(final Dept dept,
			final String excludeDeptIds) throws Exception {

		String content = callService("getDeptListByTree",
				new Object[] { authCode, dept.getDeptId(), dept.getDeptName(),
						dept.getParentDeptId(), dept.getDeptType(),
						excludeDeptIds });
		close();
		JDomUtil jDomUtil = new JDomUtil();

		List<Dept> deptList = new ArrayList<Dept>();

		Document xmlDoc = jDomUtil.build(content);
		List<Element> nodeList = XPath.selectNodes(xmlDoc, "//REC");

		Element retCodeE = (Element) XPath.selectSingleNode(xmlDoc,
				"//RET_CODE");
		if ("F".equals(retCodeE.getText())) {
			Element retMsgE = (Element) XPath.selectSingleNode(xmlDoc,
					"//RET_MSG");
			throw new Exception("调用ws返回结果异常" + retMsgE.getText());
		}
		for (Element element : nodeList) {
			Dept d = new Dept();
			String deptIdStr = element.getChildText("DEPT_ID");
			String dept_name = element.getChildText("DEPT_NAME");
			String parent_dept_id = element.getChildText("PARENT_DEPT_ID");
			// String dept_type = element.getChildText("DEPT_TYPE");
			// String remark = element.getChildText("REMARK");
			// String sort_id = element.getChildText("SORT_ID");
			// String state = element.getChildText("STATE");
			d.setDeptId(checkNotNull(deptIdStr) ? Long.valueOf(deptIdStr)
					: null);
			d.setDeptName(checkNotNull(dept_name) ? dept_name : null);
			d.setDeptType(checkNotNull(parent_dept_id) ? Integer
					.parseInt(parent_dept_id) : null);
			// d.setRemark(checkNotNull(remark) ? remark : null);
			// d.setSortId(checkNotNull(sort_id) ? Integer.parseInt(sort_id)
			// : null);
			// d.setState(checkNotNull(state) ? Integer.parseInt(state) : null);
			deptList.add(d);
		}
		return deptList;

	}

	public List<Dept> getDeptList(final Dept dept, final int pageNo,
			final int pageSize, final String orderBy, final String order)
			throws Exception {

		String content = callService(
				"getDeptList",
				new Object[] { authCode, dept.getDeptId(), dept.getDeptName(),
						dept.getParentDeptId(), dept.getDeptType(),
						dept.getRemark(), dept.getSortId(), dept.getState(),
						pageNo, pageSize, orderBy, order });
		close();
		JDomUtil jDomUtil = new JDomUtil();

		List<Dept> deptList = new ArrayList<Dept>();

		Document xmlDoc = jDomUtil.build(content);
		List<Element> nodeList = XPath.selectNodes(xmlDoc, "//REC");

		Element retCodeE = (Element) XPath.selectSingleNode(xmlDoc,
				"//RET_CODE");
		if ("F".equals(retCodeE.getText())) {
			Element retMsgE = (Element) XPath.selectSingleNode(xmlDoc,
					"//RET_MSG");
			throw new Exception("调用ws返回结果异常" + retMsgE.getText());
		}
		for (Element element : nodeList) {
			Dept d = new Dept();
			String deptIdStr = element.getChildText("DEPT_ID");
			System.out.println(deptIdStr);
			String dept_name = element.getChildText("DEPT_NAME");
			String parent_dept_id = element.getChildText("PARENT_DEPT_ID");
			String dept_type = element.getChildText("DEPT_TYPE");
			String remark = element.getChildText("REMARK");
			String sort_id = element.getChildText("SORT_ID");
			String state = element.getChildText("STATE");
			d.setDeptId(checkNotNull(deptIdStr) ? Long.valueOf(deptIdStr)
					: null);
			d.setDeptName(checkNotNull(dept_name) ? dept_name : null);
			d.setDeptType(checkNotNull(parent_dept_id) ? Integer
					.parseInt(parent_dept_id) : null);
			d.setRemark(checkNotNull(remark) ? remark : null);
			d.setSortId(checkNotNull(sort_id) ? Integer.parseInt(sort_id)
					: null);
			d.setState(checkNotNull(state) ? Integer.parseInt(state) : null);
			deptList.add(d);
		}

		return deptList;

	}

	public void testGetDeptList() throws Exception {
		List<Dept> deptList = getDeptList(new Dept(), 1, 20, "deptId", "desc");
		for (Dept d : deptList) {
			System.out.println(d);
		}
		System.out.println(deptList.size());
	}

	public Long getDeptCount(final Dept dept) throws Exception {
		String content = callService(
				"getDeptCount",
				new Object[] { authCode, dept.getDeptId(), dept.getDeptName(),
						dept.getParentDeptId(), dept.getDeptType(),
						dept.getRemark(), dept.getSortId(), dept.getState() });
		close();
		JDomUtil jDomUtil = new JDomUtil();
		Document xmlDoc = jDomUtil.build(content);
		Element counter = (Element) XPath.selectSingleNode(xmlDoc, "//COUNTER");
		Element retCodeE = (Element) XPath.selectSingleNode(xmlDoc,
				"//RET_CODE");
		if ("F".equals(retCodeE.getText())) {
			Element retMsgE = (Element) XPath.selectSingleNode(xmlDoc,
					"//RET_MSG");
			throw new Exception("调用ws返回结果异常" + retMsgE.getText());
		}
		log.debug(counter.getValue());
		return Long.parseLong(counter.getValue());

	}

	public void testGetDeptCount() throws Exception {

		Dept d = new Dept();
		System.out.println(getDeptCount(d));

	}

	/**
	 * 判断串是否为空
	 * 
	 * @param str
	 * @return
	 */
	private boolean checkNotNull(String str) {
		if (str == null || str.equals("null") || str.equals("")) {
			return false;
		}
		return true;
	}

	/**
	 * 获取日志记录
	 * 
	 * @param opeLog
	 * @param opeBegenTime
	 * @param opeEndTime
	 * @param pageNo
	 * @param pageSize
	 * @param orderBy
	 * @param order
	 * @return
	 * @throws Exception
	 */
	public List<OpeLog> getOpeLogList(OpeLog opeLog, Date opeBeginTime,
			Date opeEndTime, int pageNo, int pageSize, String orderBy,
			String order) throws Exception {
		String content = callService(
				"getOpeLogList",
				new Object[] { authCode, opeLog.getAppCode(),
						opeLog.getObjType(), opeLog.getOpeType(),
						opeLog.getObjId(), opeLog.getOpeUserCode(),
						opeLog.getOpeUserName(), opeLog.getOpeTime(),
						opeLog.getOpeIp(), opeLog.getRemark(), opeBeginTime,
						opeEndTime, pageNo, pageSize, orderBy, order });
		// System.out.println(content);
		close();
		JDomUtil jDomUtil = new JDomUtil();
		Document xmlDoc = jDomUtil.build(content);
		Element retElement = (Element) XPath.selectSingleNode(xmlDoc,
				"//RET_CODE");
		Assert.notNull(retElement);
		if (retElement.getText().equals("F")) {
			Element retMsgElement = (Element) XPath.selectSingleNode(xmlDoc,
					"//RET_MSG");
			throw new Exception("服务器返回错误:" + retMsgElement.getText());
		}
		List<Element> nodeList = XPath.selectNodes(xmlDoc, "//REC");
		List<OpeLog> opeLogList = new ArrayList<OpeLog>();
		for (Element elment : nodeList) {
			OpeLog tmpObj = new OpeLog();
			tmpObj.setAppCode(elment.getChildText("APP_CODE"));
			tmpObj.setLogId(Long.parseLong(elment.getChildText("LOG_ID")));
			String dateStr = StringUtils.substringBefore(
					elment.getChildText("OPE_TIME"), ".");
			if (!dateStr.equals("null")) {
				Date opeTimeTemp = DateUtils.parseDate(dateStr,
						new String[] { "yyyy-MM-dd hh:mm:ss" });
				tmpObj.setOpeTime(opeTimeTemp);
			}
			tmpObj.setObjType(elment.getChildText("OBJ_TYPE"));
			tmpObj.setObjId(elment.getChildText("OBJ_ID"));
			tmpObj.setOpeUserCode(elment.getChildText("OPE_USER_CODE"));
			tmpObj.setOpeUserName(elment.getChildText("OPE_USER_NAME"));
			tmpObj.setOpeIp(elment.getChildText("OPE_IP"));
			tmpObj.setRemark(elment.getChildText(elment.getChildText("OPE_IP")));
			opeLogList.add(tmpObj);
		}
		System.out.println(opeLogList.size());
		for (OpeLog o : opeLogList) {
			System.out.println(o);
		}
		return opeLogList;

	}

	/**
	 * 获取操作日志记录数
	 * 
	 * @param opeLog
	 * @param opeBegenTime
	 * @param opeEndTime
	 * @return
	 * @throws Exception
	 */
	public Long getOpeLogCounter(OpeLog opeLog, Date opeBegenTime,
			Date opeEndTime) throws Exception {
		String content = callService(
				"getOpeLogCounter",
				new Object[] { authCode, opeLog.getAppCode(),
						opeLog.getObjType(), opeLog.getOpeType(),
						opeLog.getObjId(), opeLog.getOpeUserCode(),
						opeLog.getOpeUserName(), opeLog.getOpeTime(),
						opeLog.getOpeIp(), opeLog.getRemark(), opeBegenTime,
						opeEndTime });
		close();
		JDomUtil jDomUtil = new JDomUtil();
		Document xmlDoc = jDomUtil.build(content);
		Element retCounterEle = (Element) XPath.selectSingleNode(xmlDoc,
				"//COUNTER");

		Element ret = (Element) XPath.selectSingleNode(xmlDoc, "//RET_CODE");
		Assert.notNull(ret);
		if (ret.getText().equals("F")) {
			Element retMsgEle = (Element) XPath.selectSingleNode(xmlDoc,
					"//RET_MSG");
			throw new Exception("获取失败:" + retMsgEle.getText());
		}
		return Long.parseLong(retCounterEle.getValue());

	}

	public List<UserPrvg> getUserPrvgList(String appCode, String userCode,
			String mdlCode) throws Exception {

		String content = callService("getUserPrvgList", new Object[] {
				authCode, appCode, userCode, mdlCode });
		close();
		// System.out.print(content);

		List<UserPrvg> userPrvgs = new ArrayList<UserPrvg>();
		JDomUtil jDomUtil = new JDomUtil();
		Document xmlDoc = jDomUtil.build(content);

		Element ret = (Element) XPath.selectSingleNode(xmlDoc, "//RET_CODE");
		Assert.notNull(ret);
		if (ret.getText().equals("F")) {
			Element retMsgEle = (Element) XPath.selectSingleNode(xmlDoc,
					"//RET_MSG");
			throw new Exception("获取失败:" + retMsgEle.getText());
		}
		List<Element> nodeList = XPath.selectNodes(xmlDoc, "//REC");
		for (Element element : nodeList) {
			UserPrvg userPrvg = new UserPrvg();
			userPrvg.setAppCode(appCode);
			userPrvg.setUserCode(userCode);
			userPrvg.setMdlCode(element.getChildText("MDL_CODE"));
			userPrvg.setMdlPrvgList(element.getChildText("MDL_PRVG_LIST_STR"));
			userPrvgs.add(userPrvg);
		}

		return userPrvgs;
	}

	public List<MdlPrvg> getMdlPrvgList(MdlPrvg mdlPrvg) throws Exception {

		String content = callService(
				"getMdlPrvgList",
				new Object[] { authCode, mdlPrvg.getAppCode(),
						mdlPrvg.getMdlCode(), mdlPrvg.getPrvgCode(),
						mdlPrvg.getPrvgName() });
		close();
		List<MdlPrvg> mdlPrvgsList = new ArrayList<MdlPrvg>();
		JDomUtil jDomUtil = new JDomUtil();
		Document xmlDoc = jDomUtil.build(content);
		Element ret = (Element) XPath.selectSingleNode(xmlDoc, "//RET_CODE");
		Assert.notNull(ret);
		if (ret.getText().equals("F")) {
			Element retMsgEle = (Element) XPath.selectSingleNode(xmlDoc,
					"//RET_MSG");
			throw new Exception("获取失败:" + retMsgEle.getText());
		}
		List<Element> nodeList = XPath.selectNodes(xmlDoc, "//REC");
		for (Element element : nodeList) {
			MdlPrvg tempObj = new MdlPrvg();
			tempObj.setAppCode(element.getChildText("APP_CODE"));
			tempObj.setMdlCode(element.getChildText("MDL_CODE"));
			tempObj.setPrvgCode(element.getChildText("PRVG_CODE"));
			tempObj.setPrvgName("PRVG_NAME");
			mdlPrvgsList.add(tempObj);
		}
		return mdlPrvgsList;

	}

	public List<SysMdl> getSysMdlList(SysMdl sysMdl) throws Exception {

		String content = callService("getSysMdlList", new Object[] { authCode,
				sysMdl.getAppCode(), sysMdl.getMdlCode(), sysMdl.getMdlName(),
				sysMdl.getParentMdlCode(), sysMdl.getType() });
		close();
		List<SysMdl> mdlPrvgsList = new ArrayList<SysMdl>();
		JDomUtil jDomUtil = new JDomUtil();
		Document xmlDoc = jDomUtil.build(content);
		Element ret = (Element) XPath.selectSingleNode(xmlDoc, "//RET_CODE");
		Assert.notNull(ret);
		if (ret.getText().equals("F")) {
			Element retMsgEle = (Element) XPath.selectSingleNode(xmlDoc,
					"//RET_MSG");
			throw new Exception("获取失败:" + retMsgEle.getText());
		}
		List<Element> nodeList = XPath.selectNodes(xmlDoc, "//REC");
		for (Element element : nodeList) {
			SysMdl tempObj = new SysMdl();
			tempObj.setAppCode(element.getChildText("APP_CODE"));
			tempObj.setMdlCode(element.getChildText("MDL_CODE"));
			tempObj.setMdlName(element.getChildText("MDL_NAME"));
			tempObj.setParentMdlCode(element.getChildText("PARENT_MDL_CODE"));
			String type = element.getChildText("TYPE");
			if (checkNotNull(type)) {
				tempObj.setType(Long.parseLong(type));
			}

			mdlPrvgsList.add(tempObj);
		}
		return mdlPrvgsList;

	}

	private void testGetSysMdlList() throws Exception {

		List<SysMdl> sysMdlList = getSysMdlList(new SysMdl());

		for (SysMdl s : sysMdlList) {
			System.out.println(s);
		}

	}

	public List<PagePrvg> getPagePrvgList(PagePrvg pagePrvg) throws Exception {

		String content = callService(
				"getPagePrvgList",
				new Object[] { authCode, pagePrvg.getAppCode(),
						pagePrvg.getPageName(), pagePrvg.getMdlCode(),
						pagePrvg.getControlId(), pagePrvg.getPrvgCode() });
		List<PagePrvg> pagePrvgList = new ArrayList<PagePrvg>();
		close();
		JDomUtil jDomUtil = new JDomUtil();
		Document xmlDoc = jDomUtil.build(content);
		Element ret = (Element) XPath.selectSingleNode(xmlDoc, "//RET_CODE");
		Assert.notNull(ret);
		if (ret.getText().equals("F")) {
			Element retMsgEle = (Element) XPath.selectSingleNode(xmlDoc,
					"//RET_MSG");
			throw new Exception("获取失败:" + retMsgEle.getText());
		}
		List<Element> nodeList = XPath.selectNodes(xmlDoc, "//REC");
		for (Element element : nodeList) {
			PagePrvg tempObj = new PagePrvg();
			tempObj.setAppCode(element.getChildText("APP_CODE"));
			tempObj.setMdlCode(element.getChildText("MDL_CODE"));
			tempObj.setPageName(element.getChildText("PAGE_NAME"));
			tempObj.setControlId(element.getChildText("CONTROL_ID"));
			pagePrvgList.add(tempObj);
		}
		return pagePrvgList;

	}

	public void addOpeLog(OpeLog opeLog) throws Exception {

		Date opeTime = opeLog.getOpeTime();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		Assert.notNull(opeTime);
		String opeTimeStr = sdf.format(opeTime);
		String content = callService(
				"addOpeLog",
				new Object[] { authCode, opeLog.getAppCode(),
						opeLog.getObjType(), opeLog.getOpeType(),
						opeLog.getObjId(), opeLog.getOpeUserCode(),
						opeLog.getOpeUserName(), opeTimeStr, opeLog.getOpeIp(),
						opeLog.getRemark(), opeLog.getInvokePage(),
						opeLog.getTriggerPage(), opeLog.getMac() });
		close();
		JDomUtil jDomUtil = new JDomUtil();
		Document xmlDoc = jDomUtil.build(content);
		Element ret = (Element) XPath.selectSingleNode(xmlDoc, "//RET_CODE");
		Assert.notNull(ret);
		if (ret.getText().equals("F")) {
			Element retMsgEle = (Element) XPath.selectSingleNode(xmlDoc,
					"//RET_MSG");
			throw new Exception("调用远程ws方法失败:" + retMsgEle.getText());
		}

	}

	public void testAddOpeLog() throws Exception {

		OpeLog opeLog = new OpeLog("001", "111", "111", "111", "111", "111",
				new Date(), "111", "111", "111", "111", "111");
		addOpeLog(opeLog);
	}

	public static void main(String[] args) throws Exception {
		WebServiceClient wc = new WebServiceClient();
		User user = new User();
		user.setDeptId(new Long(1));
		System.out.println("|00111");
		System.out.println(wc.getCurDeptUserAndNextDeptUser(Long.valueOf(1),
				"'gwyx'").size());
		System.out.println(wc.getCurDeptUserAndNextDeptUser(Long.valueOf(1),
				null).size());
		System.out.println(wc.getCurDeptUserAndNextDeptUser(Long.valueOf(1),
				null).size());
		System.out.println(wc.getCurDeptUserAndNextDeptUser(Long.valueOf(1),
				null).size());
		System.out.println(wc.getCurDeptUserAndNextDeptUser(Long.valueOf(1),
				null).size());
		System.out.println("|00");
	}

}
