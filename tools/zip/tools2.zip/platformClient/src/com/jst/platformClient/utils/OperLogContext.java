package com.jst.platformClient.utils;

import com.jst.platformClient.entity.OpeLog;

public class OperLogContext {
	
	private static ThreadLocal<OpeLog> instance = new ThreadLocal<OpeLog>() {
		protected OpeLog initialValue() {
			return (null);
		}
	};

	public static OpeLog getCurrentInstance() {

		return (instance.get());

	}
	public static void setCurrentInstance(OpeLog opeLog) {

		if (opeLog == null) {
			instance.remove();
		} else {
			instance.set(opeLog);
		}

	}

}
