package com.jst.platformClient.entity;

/**
 * UserPrvg entity. @author MyEclipse Persistence Tools
 */

public class UserPrvg implements java.io.Serializable {

	// Fields
	private Integer userPrvgId;
	private String userCode;
	private String mdlCode;
	private String mdlPrvgList;
	private String appCode;

	// Constructors

	/** default constructor */
	public UserPrvg() {
	}
	public UserPrvg(String userCode, String mdlCode, String prvgListStr ){
		this.userCode = userCode;
		this.mdlCode = mdlCode;
		this.mdlPrvgList =prvgListStr;
	}
	
	// Property accessors

	public Integer getUserPrvgId() {
		return this.userPrvgId;
	}

	public void setUserPrvgId(Integer userPrvgId) {
		this.userPrvgId = userPrvgId;
	}


	public String getMdlPrvgList() {
		return this.mdlPrvgList;
	}

	public void setMdlPrvgList(String mdlPrvgList) {
		this.mdlPrvgList = mdlPrvgList;
	}

	public String getUserCode() {
		return userCode;
	}


	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}


	public String getMdlCode() {
		return mdlCode;
	}


	public void setMdlCode(String mdlCode) {
		this.mdlCode = mdlCode;
	}
	public String getAppCode() {
		return appCode;
	}
	public void setAppCode(String appCode) {
		this.appCode = appCode;
	}


	



}