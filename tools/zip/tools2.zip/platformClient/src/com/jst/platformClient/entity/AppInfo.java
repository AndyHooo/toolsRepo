package com.jst.platformClient.entity;

public class AppInfo {
	
	private String appCode ;
	private String appName ;
	private String verStr ;
	private Integer verStrState ;
	private String  remark ;
	
	public AppInfo(){};
	
	public AppInfo(String appCode, String appName, String verStr,
			Integer verStrState, String remark) {
		super();
		this.appCode = appCode;
		this.appName = appName;
		this.verStr = verStr;
		this.verStrState = verStrState;
		this.remark = remark;
	}
	public String getAppCode() {
		return appCode;
	}
	public void setAppCode(String appCode) {
		this.appCode = appCode;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public String getVerStr() {
		return verStr;
	}
	public void setVerStr(String verStr) {
		this.verStr = verStr;
	}
	public Integer getVerStrState() {
		return verStrState;
	}
	public void setVerStrState(Integer verStrState) {
		this.verStrState = verStrState;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	
	

}
