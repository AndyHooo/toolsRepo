package com.jst.platformClient.entity;


/**
 * User entity. @author MyEclipse Persistence Tools
 */

public class User implements java.io.Serializable {

	// Fields
	private String userCode;
	private Long deptId;
	private String userName;
	private String userPassword;
	private Long userType;
	private Boolean  ifGrantLogin;
	private Long state;
	private Long sortId;
	private String remark;
	private String remark1;
	private String remark2;
	private String remark3;
	private String appCode;
	/** default constructor */
	public User() {
	}

	@Override
	public String toString() {
		return "User [userCode=" + userCode + ", deptId=" + deptId
				+ ", userName=" + userName + ", userPassword=" + userPassword
				+ ", userType=" + userType + ", ifGrantLogin=" + ifGrantLogin
				+ ", state=" + state + ", sortId=" + sortId + ", remark="
				+ remark + ", remark1=" + remark1 + ", remark2=" + remark2
				+ ", remark3=" + remark3 + ", appCode=" + appCode + "]";
	}

	public Long getUserType() {
		return userType;
	}

	public void setUserType(Long userType) {
		this.userType = userType;
	}

	public Long getState() {
		return state;
	}

	public void setState(Long state) {
		this.state = state;
	}

	public Long getSortId() {
		return sortId;
	}

	public void setSortId(Long sortId) {
		this.sortId = sortId;
	}

	
	public String getUserCode() {
		return this.userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public String getUserName() {
		return this.userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserPassword() {
		return this.userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public Long getDeptId() {
		return deptId;
	}

	public void setDeptId(Long deptId) {
		this.deptId = deptId;
	}

	

	public Boolean getIfGrantLogin() {
		return ifGrantLogin;
	}

	public void setIfGrantLogin(Boolean ifGrantLogin) {
		this.ifGrantLogin = ifGrantLogin;
	}

	

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getRemark1() {
		return remark1;
	}

	public void setRemark1(String remark1) {
		this.remark1 = remark1;
	}

	public String getRemark2() {
		return remark2;
	}

	public void setRemark2(String remark2) {
		this.remark2 = remark2;
	}

	public String getRemark3() {
		return remark3;
	}

	public void setRemark3(String remark3) {
		this.remark3 = remark3;
	}

	public String getAppCode() {
		return appCode;
	}

	public void setAppCode(String appCode) {
		this.appCode = appCode;
	}
	

	
}