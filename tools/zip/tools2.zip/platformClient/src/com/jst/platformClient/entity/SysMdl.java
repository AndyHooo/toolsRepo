package com.jst.platformClient.entity;


/**
 * SysMdl entity. @author MyEclipse Persistence Tools
 */

public class SysMdl implements java.io.Serializable {

	// Fields

	
	
	private String mdlCode;
	private String mdlName;
	private String parentMdlCode;
	private Long state;
	private Long type;
	private String remark;
	private Long mdlLevel;
	private Long sortId;
	private String appCode;
	
	

	// Constructors

	/** default constructor */
	public SysMdl() {
	}

	public String getMdlCode() {
		return mdlCode;
	}

	public void setMdlCode(String mdlCode) {
		this.mdlCode = mdlCode;
	}

	public String getMdlName() {
		return mdlName;
	}

	public void setMdlName(String mdlName) {
		this.mdlName = mdlName;
	}

	public String getParentMdlCode() {
		return parentMdlCode;
	}

	public void setParentMdlCode(String parentMdlCode) {
		this.parentMdlCode = parentMdlCode;
	}

	public Long getState() {
		return state;
	}

	public void setState(Long state) {
		this.state = state;
	}

	public Long getType() {
		return type;
	}

	public void setType(Long type) {
		this.type = type;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Long getMdlLevel() {
		return mdlLevel;
	}

	public void setMdlLevel(Long mdlLevel) {
		this.mdlLevel = mdlLevel;
	}

	public Long getSortId() {
		return sortId;
	}

	public void setSortId(Long sortId) {
		this.sortId = sortId;
	}

	public String getAppCode() {
		return appCode;
	}

	public void setAppCode(String appCode) {
		this.appCode = appCode;
	}

	
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((appCode == null) ? 0 : appCode.hashCode());
		result = prime * result + ((mdlCode == null) ? 0 : mdlCode.hashCode());
		result = prime * result
				+ ((mdlLevel == null) ? 0 : mdlLevel.hashCode());
		result = prime * result + ((mdlName == null) ? 0 : mdlName.hashCode());
		result = prime * result
				+ ((parentMdlCode == null) ? 0 : parentMdlCode.hashCode());
		result = prime * result + ((remark == null) ? 0 : remark.hashCode());
		result = prime * result + ((sortId == null) ? 0 : sortId.hashCode());
		result = prime * result + ((state == null) ? 0 : state.hashCode());
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SysMdl other = (SysMdl) obj;
		if (appCode == null) {
			if (other.appCode != null)
				return false;
		} else if (!appCode.equals(other.appCode))
			return false;
		if (mdlCode == null) {
			if (other.mdlCode != null)
				return false;
		} else if (!mdlCode.equals(other.mdlCode))
			return false;
		if (mdlLevel == null) {
			if (other.mdlLevel != null)
				return false;
		} else if (!mdlLevel.equals(other.mdlLevel))
			return false;
		if (mdlName == null) {
			if (other.mdlName != null)
				return false;
		} else if (!mdlName.equals(other.mdlName))
			return false;
		if (parentMdlCode == null) {
			if (other.parentMdlCode != null)
				return false;
		} else if (!parentMdlCode.equals(other.parentMdlCode))
			return false;
		if (remark == null) {
			if (other.remark != null)
				return false;
		} else if (!remark.equals(other.remark))
			return false;
		if (sortId == null) {
			if (other.sortId != null)
				return false;
		} else if (!sortId.equals(other.sortId))
			return false;
		if (state == null) {
			if (other.state != null)
				return false;
		} else if (!state.equals(other.state))
			return false;
		if (type == null) {
			if (other.type != null)
				return false;
		} else if (!type.equals(other.type))
			return false;
		return true;
	}
	
	

	
	
	}