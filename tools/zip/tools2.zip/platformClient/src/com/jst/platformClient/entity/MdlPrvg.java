package com.jst.platformClient.entity;

/**
 * ModelPrvg entity. @author MyEclipse Persistence Tools
 */

public class MdlPrvg implements java.io.Serializable {

	// Fields

	private Integer mdlPrvgId;
	public String getMdlCode() {
		return mdlCode;
	}
	public void setMdlCode(String mdlCode) {
		this.mdlCode = mdlCode;
	}
	private String  mdlCode;
	private String prvgCode;
	private String prvgName;
	private Short sortId;
	private String appCode;

	// Constructors

	/** default constructor */
	public MdlPrvg() {
	}

	/** minimal constructor */
	
	// Property accessors

	public Integer getMdlPrvgId() {
		return this.mdlPrvgId;
	}

	

	

	public void setMdlPrvgId(Integer mdlPrvgId) {
		this.mdlPrvgId = mdlPrvgId;
	}


	public String getPrvgCode() {
		return this.prvgCode;
	}

	public void setPrvgCode(String prvgCode) {
		this.prvgCode = prvgCode;
	}

	public String getPrvgName() {
		return this.prvgName;
	}

	public void setPrvgName(String prvgName) {
		this.prvgName = prvgName;
	}

	public Short getSortId() {
		return this.sortId;
	}

	public void setSortId(Short sortId) {
		this.sortId = sortId;
	}
	public String getAppCode() {
		return appCode;
	}
	public void setAppCode(String appCode) {
		this.appCode = appCode;
	}

	

}