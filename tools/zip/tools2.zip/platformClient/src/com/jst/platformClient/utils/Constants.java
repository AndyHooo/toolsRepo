package com.jst.platformClient.utils;


public class Constants {

	public static String CURRENT_APPCODE = Config.getProperty("current.system.appcode");
	
	

}
