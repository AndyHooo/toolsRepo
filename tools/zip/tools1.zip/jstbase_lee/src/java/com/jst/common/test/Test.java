/**
 * 
 */
package com.jst.common.test;

import java.io.BufferedInputStream;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import com.jst.common.hibernate.PropertyFilter;
import com.jst.common.service.ServiceFactory;
import com.jst.common.test.person.Person;
import com.jst.common.test.person.PersonService;
import com.jst.common.utils.page.Page;

/**
 * @author Administrator
 *
 */
public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			// test("DELETE");
			test("ADD");
			// test("UPDATE");
			// test("GET_LIST_COUNTER");
			// test("GET_LIST");
			// test("PAY_FEE_APP");
			test("GET_LIST");
			test("GET_LIST");
			test("GET_LIST");
			test("GET_LIST");
			test("GET_LIST");
			
		
			Thread.sleep(1000*30);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public static void test(String testType) throws Exception {

		PersonService svr=(PersonService)ServiceFactory.getService("personService") ;
		Person obj = getTestObj();
		HttpSession httpSession = null;

		if (testType.equalsIgnoreCase("ADD")) {
			
			svr.add(obj, httpSession);
		} else if (testType.equalsIgnoreCase("UPDATE")) {

			svr.update(obj, httpSession);

		} else if (testType.equalsIgnoreCase("DELETE")) {
			svr.delete(obj, httpSession);
					
		} else if (testType.equalsIgnoreCase("GET_LIST_COUNTER")) {

			String idCard=null;
			String personName=null;
			String schoolCode=null;
			String state=null;
			String sortStr=null;
			
			long counter = 0;

			//counter=svr.getPersonListCounter(idCard, personName, schoolCode, state);

			System.out.println("couner:" + counter);

	
		} else if (testType.equalsIgnoreCase("LIST")) {
			
			Page page=new Page();
			List<PropertyFilter> filters=new ArrayList();			
			Page p=svr.getPage(page, filters);
			
			System.out.println("counter:"+p.getTotalCount());
			if(p!=null && p.getTotalCount()>0){
				
				Person person=(Person)p.getResult().get(0);
				//System.out.println("personName:"+person.getPersonName());
				
			}			
			
		} else if (testType.equalsIgnoreCase("GET_LIST")) {

			String idCard=null;
			String personName=null;
			String schoolCode=null;
			String state=null;
			String sortStr=null;			 
			
			int pageSize = 100;
			int pageNo = 1;

			List list = svr.getPersonList(idCard, personName, schoolCode, state, sortStr, pageSize, pageNo);

			System.out.println("couner:" + list.size());
			if (list.size() > 0) {
				System.out.println("id:" + ((Person) list.get(0)).getId()
						+ " name=:" + ((Person) list.get(0)).getPersonName());

			}
		}
		
		

	}


	public static Person getTestObj() {

		Integer id = new Integer(4);
		String idCard = "432402197609191010";
		String personName = "������2";
		String schoolCode = "001";
		String state = "1";
		byte[] photo =null;
		
		
		
		try{
			BufferedInputStream in = new BufferedInputStream(new FileInputStream("D:\\img\\2.2.1.4.jpg"));         
	        ByteArrayOutputStream out = new ByteArrayOutputStream(1024);         
	        
	        System.out.println("Available bytes:" + in.available());         
	        
	        byte[] temp = new byte[1024];         
	        int size = 0;         
	        while ((size = in.read(temp)) != -1) {         
	            out.write(temp, 0, size);         
	        }         
	        in.close();  
	        photo = out.toByteArray();
        
		}catch(Exception e){
			e.printStackTrace();
		}
        
                

        

		Person person = new Person(idCard, personName, schoolCode, state);

		person.setId(id);
		person.setPhoto(photo);

		return person;

	}
	
	

}
