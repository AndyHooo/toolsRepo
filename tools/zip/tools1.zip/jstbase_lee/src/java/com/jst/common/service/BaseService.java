package com.jst.common.service;


import java.io.Serializable;
import java.util.List;
import com.jst.common.model.BaseModel;
import javax.servlet.http.HttpSession;
import com.jst.common.hibernate.PropertyFilter;
import com.jst.common.utils.page.Page;

/**
 * 基础服务接口
 * @author 刘美林 2012-04-25
 * 
 */


public interface BaseService {
	
	/**
	 * 添加对象 
	 * @param baseModel
	 * @param httpSession 包含当前用户信息，如：USER_CODE,USER_NAME,USER_TYPE,DEPT_CODE,DEPT_NAME,DEPT_TYPE,IP,MACHINE_CODE
	 * @return
	 * @throws Exception
	 */
	public Object add(BaseModel baseModel,HttpSession httpSession)throws Exception;
	
	/**
	 * 修改对象	 * 
	 * @param baseModel
	 * @param httpSession 包含当前用户信息，如：USER_CODE,USER_NAME,USER_TYPE,DEPT_CODE,DEPT_NAME,DEPT_TYPE,IP,MACHINE_CODE
	 * @throws Exception
	 */	
	public void update(BaseModel baseModel,HttpSession httpSession)throws Exception;
	
	/**
	 * 删除对象
	 * @param id 对象ID
	 * @param httpSession 包含当前用户信息，如：USER_CODE,USER_NAME,USER_TYPE,DEPT_CODE,DEPT_NAME,DEPT_TYPE,IP,MACHINE_CODE
	 * @throws Exception
	 */
	public void delete(Object id,HttpSession httpSession)throws Exception;
	
	/**
	 * 获取对象
	 * @param id
	 * @return
	 * @throws Exception
	 */
	public BaseModel get(Serializable id) throws Exception;	
	
	/**
	 * 获取所有对象List (数据量过多时请勿使用）
	 * @return
	 * @throws Exception
	 */	
	public List getAllList() throws Exception;
	
	/**
	 * 获取所有对象数量
	 * @return
	 * @throws Exception
	 */	
	public long getAllListCounter() throws Exception;
	
	/**
	 * 根据多个属性查找对象
	 * @param propertyNames
	 * @param values
	 * @param pSqlWhere
	 * @param orderByStr
	 * @return
	 * @throws Exception
	 */
	
	public List getListByPropertys(String[] propertyNames,
			Object[] values, String pSqlWhere ,String orderByStr) throws Exception;
	
	/**
	 * 根据一个属性查找对象
	 * @param propertyName
	 * @param value
	 * @param pSqlWhere
	 * @return
	 * @throws Exception
	 */
	public List getListByPorperty(String propertyName,
			Object value, String pSqlWhere) throws Exception;
	
	/**
	 * 获取对象Page (保留)
	 * @param page
	 * @param filters
	 * @return
	 * @throws Exception
	 */	
	public  Page getPage(Page page,List<PropertyFilter> filters) throws Exception;
	
	public Page<Object> list(final Page page,List<PropertyFilter> filters) throws Exception;
	
		
}