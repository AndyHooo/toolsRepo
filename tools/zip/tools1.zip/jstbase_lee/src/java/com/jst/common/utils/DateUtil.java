package com.jst.common.utils;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtil {
	
	public static Date getDate(String dateStr){
		Date date = null ;
		try{
			if(dateStr==null ||dateStr.equals("")){
				return null ;
			}
			SimpleDateFormat sdf  = null ;
			if(dateStr.matches("\\d{4}-\\d{1,2}-\\d{1,2}")){ //yyyy-MM-dd
				 sdf = new SimpleDateFormat("yyyy-MM-dd");
			}else if(dateStr.matches("\\d{2}-\\d{1,2}-\\d{1,2}")){ //yy-MM-dd
				 sdf = new SimpleDateFormat("yy-MM-dd");
			}else if(dateStr.matches("\\d{4}-\\d{1,2}-\\d{1,2}\\s\\d{1,2}:d{1,2}")){ //yyyy-MM-dd hh:mm
				 sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm");
			}else if(dateStr.matches("\\d{4}-\\d{1,2}-\\d{1,2}\\s\\d{1,2}:d{1,2}:\\d{1,2}")){ // yyyy-MM-dd hh:mm:ss
				 sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
			}else if(dateStr.matches("\\d{2}-\\d{1,2}-\\d{1,2}\\s\\d{1,2}:d{1,2}:\\d{1,2}")){ //yy-MM-dd hh:MM:ss
				 sdf = new SimpleDateFormat("yy-MM-dd hh:mm:ss");
			}else if(dateStr.matches("\\d{4}-\\d{1,2}-\\d{1,2}\\s\\d{1,2}:\\d{1,2}:\\d{1,2}\\.0")){//yyyy-MM-dd hh:mm:ss.0
				dateStr = dateStr.substring(0,dateStr.lastIndexOf("."));
				sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
			}else{
				System.out.println("日期转换错误，暂时不支持该格式");
				 return null ; 
			}
			date = sdf.parse(dateStr);
		}catch(Exception e){
			e.printStackTrace();
		}
		return date ;
	}

}
