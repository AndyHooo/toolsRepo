/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.jst.common.xml;

/**
 *
 * @author Administrator
 */
public class XmlParseTest {

    public static void test(){

        String xml="<?xml version=\"1.0\" encoding=\"UTF-8\"?><MSG><HEAD><RET_CODE>T</RET_CODE><RET_MSG>成功</RET_MSG></HEAD><BODY></BODY></MSG>";
        

    }

}
