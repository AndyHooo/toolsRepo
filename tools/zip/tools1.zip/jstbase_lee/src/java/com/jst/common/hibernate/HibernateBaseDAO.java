package com.jst.common.hibernate;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.io.Serializable;
import java.lang.reflect.Method;

import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.CriteriaSpecification;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.impl.CriteriaImpl;
import org.hibernate.transform.ResultTransformer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.util.Assert;

import com.jst.common.model.BaseModel;
import com.jst.common.utils.reflection.ReflectionUtils;
import com.jst.common.utils.string.StringUtil;
import com.jst.common.hibernate.PropertyFilter;
import com.jst.common.hibernate.PropertyFilter.MatchType;
import com.jst.common.utils.page.Page;


/**
 * Data access object (DAO) for domain model
 * 
 * @author MyEclipse Persistence Tools
 * @param <T>
 */

@Repository
public abstract class HibernateBaseDAO<T> extends HibernateTemplate {
	private static final Log log = LogFactory.getLog(HibernateBaseDAO.class);
	
	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory){  
	  super.setSessionFactory(sessionFactory);  
	}
		
	public String formatSqlWhere(String sql) {
		return sql;
	}

	public long getListCounter(String sql, List paraList) throws Exception {
		long counter = 0L;
		Session session = null;
		try {
			session = getSession();
			SQLQuery query = session.createSQLQuery(sql);

			if ((paraList != null) && (paraList.size() > 0)) {
				for (int index = 0; index < paraList.size(); ++index) {
					Object pe = paraList.get(index);
					query.setParameter(index, pe);
				}
			}
			counter = Long.parseLong(query.uniqueResult().toString());
			return counter;
		} catch (Exception ex) {
			log.error("getListCounter failed: " + ex);
			throw ex;
		}
	}

	public long getListCounter(String sql) throws Exception {
		return getListCounter(sql, null);
	}
	
	public long getObjListCounter(String sql, List paraList) throws Exception{
		long counter = 0;
		Session session =null;
		try{
			session = getSession();			
			Query query = session.createQuery(sql);
			
			if(paraList!=null && paraList.size()>0){
				for(int index=0;index<paraList.size();index++){
					Object pe = (Object)paraList.get(index);
					query.setParameter(index, pe);
				}
			}
			counter = Long.parseLong(query.uniqueResult().toString());		
			return counter;
		}
		catch(Exception ex){			
			log.error("getListCounter failed: " + ex);
			throw ex;
		}		
	}
	
	public List getObjList(String sql, List paraList,Page page) throws Exception {
		List list = new ArrayList();
		Session session = null;
		try {
			session = getSession();
			if(page!=null && StringUtil.isNotEmpty(page.getOrderBy())){
				sql +=" order by model."+page.getOrderBy();
				if(StringUtil.isNotEmpty(page.getOrder()) && page.getOrder().equalsIgnoreCase("asc")){
					sql+=" asc";
				}else{
					sql+=" desc";
				}
			}else{
				sql +=" order by model.id desc";
			}
			Query query = session.createQuery(sql);
			if ((paraList != null) && (paraList.size() > 0)) {
				for (int index = 0; index < paraList.size(); ++index) {
					Object pe = paraList.get(index);
					query.setParameter(index, pe);
				}
			}
			
			if (page!=null && (page.getPageNo() > 0) && (page.getPageSize()> 0)) {
				query.setFirstResult((page.getPageNo() - 1) * page.getPageSize());
				query.setMaxResults(page.getPageSize());
			}
			
			list = query.list();
			return list;
		} catch (Exception ex) {
			log.error("getList failed: " + ex);
			throw ex;
		}
	}
	
	public List getObjList(String sql, List paraList,int pageSize,int pageNo) throws Exception{
		
		Page page=new Page();
		page.setPageSize(pageSize);
		page.setPageNo(pageNo);
		
		return this.getObjList(sql, paraList, page);
			
		
	}
	
	public void updatePart(String sql, List paraList)
			throws Exception {
		Session session = null;
		try {
			session = getSession();
			Query query = session.createQuery(sql);
			if ((paraList != null) && (paraList.size() > 0)) {
				for (int index = 0; index < paraList.size(); ++index) {
					Object pe = paraList.get(index);
					query.setParameter(index, pe);
				}
			}

			query.executeUpdate();
		} catch (Exception ex) {
			log.error("updatePart failed: " + ex);
			throw ex;
		}
	}
	
	public void executeHql(String hql,List paraList) throws Exception {
		log.debug("executeSql begin");
		
		Session session = null;
		try {
			session = getSession();
			Query query = session.createQuery(hql);
			if ((paraList != null) && (paraList.size() > 0)) {
				for (int index = 0; index < paraList.size(); ++index) {
					Object pe = paraList.get(index);
					query.setParameter(index, pe);
				}
			}

			query.executeUpdate();
		} catch (Exception ex) {
			log.error("executeSql failed: " + ex);
			throw ex;
		}
	}

	public void executeHql(String hql) throws Exception {
		executeHql(hql,null);
	}

	public List getObjList(String sql, Page page) throws Exception {
		return getObjList(sql, null,null);
	}

	public List getObjList(String sql) throws Exception {
		return getObjList(sql, null,null);
	}

	public List getObjList(String sql, List paraList) throws Exception {
		return getObjList(sql, paraList,null);
	}

	public List getTableList(String sql,Page page) throws Exception {
		return getTableList(sql, null,page,null);
	}

	public List getTableList(String sql, List paraList,String className) throws Exception {
		return getTableList(sql, paraList, null,className);
	}
	
	public List getTableList(String sql, List paraList,Page page,String className)throws Exception {
		Object[] objs = null;
		Session session = null;
		try {
			session = getSession();
			session.beginTransaction();
			SQLQuery query = session.createSQLQuery(sql);

			if ((paraList != null) && (paraList.size() > 0)) {
				for (int index = 0; index < paraList.size(); ++index) {
					Object pe = paraList.get(index);
					query.setParameter(index, pe);
				}
			}
			if(StringUtil.isNotEmpty(className)){
				query.addEntity(className);
			}
			if (page!=null && (page.getPageNo() > 0) && (page.getPageSize()> 0)) {
				query.setFirstResult((page.getPageNo() - 1) * page.getPageSize());
				query.setMaxResults(page.getPageSize());
			}
			List list = query.list();
			return list;
		} catch (Exception ex) {
			log.error("getListCounter failed: " + ex);
			throw ex;
		}
	}
	
	public List getTableList(String sql, List paraList,int pageSize,int pageNo,String className)throws Exception {
		Page page=new Page();
		page.setPageSize(pageSize);
		page.setPageNo(pageNo);
		
		return this.getTableList(sql, paraList, page, className);		
	}
	
	/**
	 * @param sql
	 * @param paraList
	 * @return
	 * @throws Exception
	 */
	public long getTableListCounter(String sql, List paraList) throws Exception{
		long counter = 0;
		Session session =null;
		try{
			session = getSession();			
			SQLQuery query = session.createSQLQuery(sql);
			
			if(paraList!=null && paraList.size()>0){
				for(int index=0;index<paraList.size();index++){
					Object pe = (Object)paraList.get(index);
					query.setParameter(index, pe);
				}
			}
			counter = Long.parseLong(query.uniqueResult().toString());		
			return counter;
		}
		catch(Exception ex){			
			log.error("getListCounter failed: " + ex);
			throw ex;
		}		
	}


	public void delete(Object id){
		StringBuffer hql = new StringBuffer(1000);
		hql.append("delete ");
		hql.append(getModelName());
		hql.append(" as model where model.id=?");
        Session sessions = getSession();
       // Transaction t = sessions.beginTransaction();
        Query query = sessions.createQuery(hql.toString());
        query.setParameter(0, id);       
            query.executeUpdate();      
       //     t.rollback();
       
	}
	
	public List getByPropertys(String[] propertyNames,
			Object[] values, String pSqlWhere) throws Exception {
		log.debug("geting " + getModelName() + " instance with propertys: ");
		try {
			String sqlWhere = "";

			for (int index = 0; index < propertyNames.length; ++index) {
				if (index == 0)
					sqlWhere = " where model." + propertyNames[index] + " = ?";
				else {
					sqlWhere = sqlWhere + " and  model." + propertyNames[index]
							+ " = ?";
				}
			}

			if ((pSqlWhere != null) && (pSqlWhere.trim().length() > 0)) {
				if (sqlWhere.trim().length() > 0)
					sqlWhere = sqlWhere + " and " + pSqlWhere;
				else {
					sqlWhere = sqlWhere + " where " + pSqlWhere;
				}
			}
			String sql = "select * from " + getModelName() + " as model " + sqlWhere;

			Query queryObject = getSession().createQuery(sql);

			for (int index = 0; index < values.length; ++index) {
				queryObject.setParameter(index, values[index]);
			}

			return queryObject.list();
		} catch (RuntimeException re) {
			log.error("get by propertys name failed", re);
			throw re;
		}
	}
    
    public BaseModel getById(Object id) {
        log.debug("getting "+getModelName()+" instance with id: " + id);
        try {      	
        	        		
        	BaseModel instance = (BaseModel) getSession().get(
        					getModelName(), (Serializable) id);        	
        	
            return instance;
        } catch (RuntimeException re) {
            log.error("get failed", re);
            throw re;
        }
    }
    
    public BaseModel get(Object id) {
        log.debug("getting "+getModelName()+" instance with id: " + id);
        try {      	
        	        		
        	BaseModel instance = (BaseModel) getSession().get(
        					getModelName(), (Serializable) id);        	
        	
            return instance;
        } catch (RuntimeException re) {
            log.error("get failed", re);
            throw re;
        }
    }
    
    public List getByExample(BaseModel instance) {
		log.debug("geting "+getModelName()+" instance by example");
		try {
			List results = getSession()
					.createCriteria(getModelName())
					.add(Example.create(instance)).list();
			log.debug("get by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("get by example failed", re);
			throw re;
		}
	}
    public BaseModel merge(BaseModel detachedInstance) {
		log.debug("merging "+getModelName()+" instance");
		try {
			BaseModel result = (BaseModel) getSession().merge(
					detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

    public abstract String getModelName();
    
    public  List getObjList(BaseModel objBaseModel,Page page)throws Exception{
    	return null;
    }
    public  long getObjListCounter(BaseModel objBaseModel)throws Exception{
    	return 0;
    }
	
	/**
	 * 按属性过滤条件列表分页查找对象.
	 */
	public Page<T> getList(final Page<T> page, final List<PropertyFilter> filters) throws Exception{
		Criterion[] criterions = new HibernateHelper().buildCriterionByPropertyFilter(filters);
		
		if(null != filters && filters.size() > 0){
			return new HibernateHelper().getPage(page, filters, criterions);
		}
		
		return new HibernateHelper().getPage(page, criterions);
	}
	
	class HibernateHelper{
	
	/**
	 * @see 按属性条件列表创建Criterion数组,辅助函数
	 *      为了处理ManyToOne或OneToOne的特殊情况，对
	 *      filters做出了过滤。
	 * @author lee
	 * @since 2014-08-19
	 * @param filters
	 * @return
	 */
	private Criterion[] buildCriterionByPropertyFilter(final List<PropertyFilter> filters) {
		List<Criterion> criterionList = new ArrayList<Criterion>();
		
		for (int i=filters.size()-1; i>=0; i--) {
			PropertyFilter filter = filters.get(i);
			
			if(filter.getPropertyName().indexOf(".") > 0){
				continue;
			}
			
			if (!filter.hasMultiProperties()) { //只有一个属性需要比较的情况.
				Criterion criterion=null;
				
				if(filter.getMatchType().equals(MatchType.IN)){
					criterion = buildCriterionin(filter.getPropertyName(), filter.getCzValue());
				}else{
					criterion = buildCriterion(filter.getPropertyName(), filter.getMatchValue(), filter.getMatchType());
				}
				
				criterionList.add(criterion);
			} else {//包含多个属性需要比较的情况,进行or处理.
				Disjunction disjunction = Restrictions.disjunction();
				
				for (String param : filter.getPropertyNames()) {
					Criterion criterion=null;
					
					if(filter.getMatchType().equals(MatchType.IN)){
						criterion = buildCriterionin(filter.getPropertyName(), filter.getCzValue());
					}else{
						criterion = buildCriterion(filter.getPropertyName(), filter.getMatchValue(), filter.getMatchType());
					}
					
					disjunction.add(criterion);
				}
				
				criterionList.add(disjunction);
			}
			
			filters.remove(i);
		}
		
		return criterionList.toArray(new Criterion[criterionList.size()]);
	}
	
	/**
	 * 按属性条件参数创建Criterion,辅助函数.
	 */
	private Criterion buildCriterion(final String propertyName, final Object propertyValue, final MatchType matchType) {
		Assert.hasText(propertyName, "propertyName不能为空");
		Criterion criterion = null;
		//根据MatchType构造criterion
		switch (matchType) {
		case EQ:
			criterion = Restrictions.eq(propertyName, propertyValue);
			break;
		case LIKE:
			criterion = Restrictions.like(propertyName, (String) propertyValue, MatchMode.ANYWHERE);
			break;
		case LE:
			criterion = Restrictions.le(propertyName, propertyValue);
			break;
		case LT:
			criterion = Restrictions.lt(propertyName, propertyValue);
			break;
		case GE:
			criterion = Restrictions.ge(propertyName, propertyValue);
			break;
		case GT:
			criterion = Restrictions.gt(propertyName, propertyValue);
			break;
		case NE:   //不等于
			criterion = Restrictions.ne(propertyName, propertyValue);
			break;
		case ILIKE:  //模糊查询不分大小写
			criterion = Restrictions.ilike(propertyName, propertyValue);
			break;
		}
		
		return criterion;
	}
	
	/**
	 * 按属性条件参数创建Criterion,辅助函数,此处只匹配in
	 */
	private Criterion buildCriterionin(final String propertyName, final List<?> propertyValue) {
		Assert.hasText(propertyName, "propertyName不能为空");
		Criterion criterion = null;		
		criterion = Restrictions.in(propertyName, propertyValue);						
		return criterion;
	}
	
	
	/**
	 * 按Criteria分页查询.
	 * 
	 * @param page 分页参数.
	 * @param criterions 数量可变的Criterion.
	 * 
	 * @return 分页查询结果.附带结果列表及所有查询输入参数.
	 */
	private Page<T> getPage(final Page<T> page, final Criterion... criterions) throws Exception{
		Assert.notNull(page, "page不能为空");

		Criteria c = createCriteria(criterions);

		if (page.isAutoCount()) {
			long totalCount = countCriteriaResult(c);
			page.setTotalCount(totalCount);
		}

		setPageParameterToCriteria(c, page);

		List result = c.list();
		page.setResult(result);
		return page;
	}
	
	
	/**
	 * @see 此方法解决了实体关联关系为多对一，多方以一方非外键关联字段为查询条件查询时，
	 *      而导致的Exception:could not resolve property someproperty of some model
	 *      且同样适用于正常的方式，即在之前的编码基础上做出了适当升级，但仅支持JPA的Annotation
	 * @author lee
	 * @since 2014-08-19
	 * @param page
	 * @param filters 此时filter中仅包含ManyToOne中One方的属性
	 * @param criterions
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	private Page<T> getPage(final Page<T> page, final List<PropertyFilter> filters, final Criterion... criterions) throws Exception{
		Assert.notNull(page, "page不能为空");

		Criteria c = createCriteria(criterions);
		
		Map<String, List<PropertyFilter>> entityMap = new HashMap<String, List<PropertyFilter>>();
		
		for(PropertyFilter pf : filters){
			String entityName = pf.getPropertyName().substring(0, pf.getPropertyName().indexOf("."));
			
			if(!entityMap.containsKey(entityName)){
				String methodName = "get" + entityName.substring(0,1).toUpperCase() + entityName.substring(1,entityName.length());
				
				Class<?> modelClass = Class.forName(getModelName());
				
				try{
					Method method = modelClass.getMethod(methodName);
					
					if(!method.isAnnotationPresent(OneToOne.class) && !method.isAnnotationPresent(ManyToOne.class)){
						throw new Exception("请在方法" + methodName + "上添加@OneToOne或@ManyToOne注解");
					}
				}catch(Exception e){
					if(e instanceof NoSuchMethodException){
						throw new Exception("请检查实体" + modelClass.getSimpleName() + "中ManyToOne的One方实体命名与所传入属性命名");
					}else{
						throw e;
					}
				}
				
				List<PropertyFilter> propertyFilterList = new ArrayList<PropertyFilter>();
				
				propertyFilterList.add(pf);
				
				entityMap.put(entityName, propertyFilterList);
			}else{
				entityMap.get(entityName).add(pf);
			}
		}
		
		for(String entityName : entityMap.keySet()){
			Criteria criteria = c.createCriteria(entityName);
			
			for(PropertyFilter pf : entityMap.get(entityName)){
				String propertyName = pf.getPropertyName();
				
				propertyName = propertyName.substring(propertyName.indexOf(".")+1,propertyName.length());
				
				criteria.add(buildCriterion(propertyName, pf.getMatchValue(), pf.getMatchType()));
			}
		}
		
//		循环取出One方属性
//		for(int i=0; i<filters.size(); i++){
//			PropertyFilter pf = filters.get(i);
//			
//			String propertyName = pf.getPropertyName();
//			
//			propertyName = propertyName.substring(propertyName.indexOf(".")+1,propertyName.length());
//			
//			MatchType matchType = pf.getMatchType();
//			Object propertyValue = pf.getMatchValue();
//			
//			if(0 == i){
//				//Many方实体中的One方实体名称
//				String entityName = pf.getPropertyName().substring(0, pf.getPropertyName().indexOf("."));
//				
//				//Many方实体对象
//				Class<?> modelClass = Class.forName(getModelName());
//				
//				//尝试获取One方实体的get方法
//				String methodName = "get" + entityName.substring(0,1).toUpperCase() 
//											+ entityName.substring(1,entityName.length());
//				
//				try{
//					Method method = modelClass.getMethod(methodName);
//					
//					if(!method.isAnnotationPresent(OneToOne.class) &&  !method.isAnnotationPresent(ManyToOne.class)){
//						throw new Exception("请在方法" + methodName + "上添加@OneToOne或@ManyToOne注解");
//					}
//					
//					//为One方创建新的Criteria对象
//					criteria = c.createCriteria(entityName);
//				}catch(Exception e){
//					if(e instanceof NoSuchMethodException){
//						throw new Exception("请检查实体"+modelClass.getSimpleName()+"中ManyToOne的One方实体命名与所传入属性命名");
//					}else{
//						throw e;
//					}
//				}
//			}
//			
//			criteria.add(buildCriterion(propertyName, propertyValue, matchType));
//		}

		if (page.isAutoCount()) {
			long totalCount = countCriteriaResult(c);
			page.setTotalCount(totalCount);
		}

		setPageParameterToCriteria(c, page);

		List<T> result = c.list();
		
		page.setResult(result);
		
		return page;
	}
	
	private Criteria createCriteria(final Criterion... criterions) throws Exception{
		Criteria criteria = getSession().createCriteria(Class.forName(getModelName()));
		for (Criterion c : criterions) {
			criteria.add(c);
		}
		return criteria;
	}
	
	/**
	 * 执行count查询获得本次Criteria查询所能获得的对象总数.
	 */
	@SuppressWarnings("unchecked")
	private long countCriteriaResult(final Criteria c) throws Exception{
		CriteriaImpl impl = (CriteriaImpl) c;

		// 先把Projection、ResultTransformer、OrderBy取出来,清空三者后再执行Count操作
		Projection projection = impl.getProjection();
		ResultTransformer transformer = impl.getResultTransformer();

		List<CriteriaImpl.OrderEntry> orderEntries = null;
		try {
			orderEntries = (List) ReflectionUtils.getFieldValue(impl, "orderEntries");
			ReflectionUtils.setFieldValue(impl, "orderEntries", new ArrayList());
		} catch (Exception e) {
			log.error("countCriteriaResult error", e);
			throw e;
		}

		// 执行Count查询
		Long totalCountObject = new Long(c.setProjection(Projections.rowCount()).uniqueResult().toString());
		long totalCount = (totalCountObject != null) ? totalCountObject : 0;

		// 将之前的Projection,ResultTransformer和OrderBy条件重新设回去
		c.setProjection(projection);

		if (projection == null) {
			c.setResultTransformer(CriteriaSpecification.ROOT_ENTITY);
		}
		if (transformer != null) {
			c.setResultTransformer(transformer);
		}
		try {
			ReflectionUtils.setFieldValue(impl, "orderEntries", orderEntries);
		} catch (Exception e) {
			log.error("countCriteriaResult error", e);
			throw e;
		}

		return totalCount;
	}
	
	/**
	 * 设置分页参数到Criteria对象,辅助函数.
	 */
	private Criteria setPageParameterToCriteria(final Criteria c, final Page<T> page) {

		Assert.isTrue(page.getPageSize() > 0, "Page Size must larger than zero");

		//hibernate的firstResult的序号从0开始
		
		c.setFirstResult((page.getPageNo() - 1) * page.getPageSize());	
		c.setMaxResults(page.getPageSize());

		if (page.getOrderBy()!=null && page.getOrderBy().trim().length()>0) {
			String[] orderByArray = StringUtils.split(page.getOrderBy(), ',');
			String[] orderArray = StringUtils.split(page.getOrder(), ',');

			Assert.isTrue(orderByArray.length == orderArray.length, "分页多重排序参数中,排序字段与排序方向的个数不相等");

			for (int i = 0; i < orderByArray.length; i++) {
				if (Page.ASC.equals(orderArray[i])) {
					c.addOrder(Order.asc(orderByArray[i]));
				} else {
					c.addOrder(Order.desc(orderByArray[i]));
				}
			}
		}
		return c;
	}	
	}
	
	public List getByPorperty(String propertyName,
			Object value, String pSqlWhere){
		log.debug("getByPorperty begin");
		
		try{
			String[] propertyNames=new String[] {propertyName};
			Object[] values=new Object[] {value};
			
			String orderByStr="";
			List list=getByPropertys(propertyNames,values,pSqlWhere,orderByStr);
			log.debug("getByPorperty end");
			return list;
		} catch (RuntimeException re) {
			log.error("getByPorperty  failed", re);
			throw re;
		}
		
		
		
	}
	
	public List getByPropertys(String[] propertyNames,
			Object[] values, String pSqlWhere ,String orderByStr)  {
		log.debug("geting " + getModelName() + " instance with propertys: ");
		
		if(propertyNames==null || values==null){
			throw new RuntimeException("propertyNames 和 values 都不能为空");
		}
		if(propertyNames.length!=values.length){
			throw new RuntimeException("propertyNames 和 values 的length不一致");
		}
		
		try {
			String sqlWhere = "";

			for (int index = 0; index < propertyNames.length; ++index) {
				if (index == 0)
					sqlWhere = " where model." + propertyNames[index] + " = ?";
				else {
					sqlWhere = sqlWhere + " and  model." + propertyNames[index]
							+ " = ?";
				}
			}

			if ((pSqlWhere != null) && (pSqlWhere.trim().length() > 0)) {
				if (sqlWhere.trim().length() > 0)
					sqlWhere = sqlWhere + " and " + pSqlWhere;
				else {
					sqlWhere = sqlWhere + " where " + pSqlWhere;
				}
			}
			if(orderByStr==null)
				orderByStr="";
			String sql = " from " + getModelName() + " as model " + orderByStr+" "+sqlWhere;

			Query queryObject = getSession().createQuery(sql);

			for (int index = 0; index < values.length; ++index) {
				queryObject.setParameter(index, values[index]);
			}

			return queryObject.list();
		} catch (RuntimeException re) {
			log.error("get by propertys name failed", re);
			throw re;
		}
	}
	
	public List getAllList() {

		log.debug("getAllList " + getModelName() + " instances");
		try {
			String queryString = "from " + getModelName();
			Query queryObject = getSession().createQuery(queryString);
			return queryObject.list();
		} catch (RuntimeException re) {
			log.error("getAllList failed", re);
			throw re;
		}

	}

	public long getAllListCounter() {

		long counter = 0;

		log.debug("getAllListCounter " + getModelName() + " instances");
		try {
			String queryString = "select count(*) from " + getModelName();
			Query queryObject = getSession().createQuery(queryString);
			counter = ((Long) queryObject.iterate().next()).longValue();
			return counter;

		} catch (RuntimeException re) {
			log.error("getAllListCounter failed", re);
			throw re;
		}

	}
	
}
