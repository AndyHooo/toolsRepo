package com.jst.common.utils.cache;


public interface ValueProvider {
    
    Object getValue(final String  key) ;

} // END Factory
