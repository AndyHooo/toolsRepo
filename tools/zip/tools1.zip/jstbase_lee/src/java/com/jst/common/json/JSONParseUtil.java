package com.jst.common.json;

import java.util.List;
import java.util.Map;

public class JSONParseUtil {
	public static  Map listToCellMap(List rows){
		return null;
	}

}
