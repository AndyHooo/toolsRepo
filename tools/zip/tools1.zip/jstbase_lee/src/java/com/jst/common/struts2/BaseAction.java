package com.jst.common.struts2;


import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;

import com.jst.common.json.WriterUtil;
import com.jst.common.utils.web.Page;
import com.jst.common.model.BaseModel;
import com.jst.common.service.BaseService;
import com.jst.common.utils.string.StringUtil;
import com.opensymphony.xwork2.ActionSupport;

public abstract class BaseAction extends ActionSupport implements ServletRequestAware,ServletResponseAware {
	private static final Log log = LogFactory.getLog(BaseAction.class);
	protected HttpServletRequest request;
	protected HttpServletResponse response;
	protected HttpSession session;
	protected String basePath;

	//分页对象,JQuery传递的变量	
	protected int rp; //页面大小
	protected String sortname;
	protected String sortorder;
	protected int page;//当前页
	
	protected int pageSize; //页面大小=rp
	protected int pageNo;  ////当前页=page
	
	
	//服务接口
	//protected BaseService baseService;

	//Model，用于页面与Action之间传递参数
	
	
	public abstract void setBaseService(BaseService baseService) ;	
	public abstract BaseService getBaseService() ;	

	
		
	@Override
	public void setServletRequest(HttpServletRequest request) {
		this.request = request;
		basePath =request.getContextPath()+"/";
		session=request.getSession();
	}
	
	@Override
	public void setServletResponse(HttpServletResponse response) {
		this.response = response;
		
	}
	
	public HttpServletRequest getServletRequest() {
		return request;
	}
	public HttpServletResponse getServletResponse() {
		return response;
	}

	public HttpSession getSession(){
		
		return session;
		
	}

	public abstract void setModel(BaseModel model);
	public abstract BaseModel getBaseModel();

	

	/**
	 * add 初始化，打开add页面
	 * @return
	 * @throws Exception
	 */
	public String add() throws Exception {		
		return "add";
	}
	
/**
 * edit 初始化，打开edit页面
 * @return
 * @throws Exception
 */
	public String update() throws Exception {
		String id = request.getParameter("id");
		if(StringUtil.isNotEmpty(id)){		
			setModel(getBaseService().get(id));
		}else{
			return ERROR;
		}
		return "update";
	}
/**
 * view 初始化，打开view页面
 * @return
 * @throws Exception
 */
	public String view() throws Exception {
		String id = request.getParameter("id");
		if(StringUtil.isNotEmpty(id)){
			setModel(getBaseService().get(id));
		}else{
			return ERROR;
		}
		return "view";
	}
	
	/**
	 * 执行add动作,完成后转向doAdd页面
	 * @return
	 * @throws Exception
	 */
	public String doAdd() throws Exception {		
		return "doAdd";
		
	}
	
	/**
	 * 执行update，完成后转向doUpdate
	 * @return
	 * @throws Exception
	 */
	public String doUpdate() throws Exception {			
		
		return "doUpdate";		
	}
	
	/**
	 * 执行delete ,转向doDelete
	 * @return
	 * @throws Exception
	 */
	public String doDelete() throws Exception {
		String id = request.getParameter("id");
		if(StringUtil.isNotEmpty(id)){		
			getBaseService().delete(id,getSession());
		}else{
			return ERROR;
		}
		return "doDelete";
	}
	/**
	 * 执行deleteAll,无返回,输出JSON结果
	 * @return
	 * @throws Exception
	 */
	public String doDeleteAll() throws Exception {
		String ids = request.getParameter("ids");
		try {
			if(StringUtil.isNotEmpty(ids)){
				String[] idArray=ids.split(",");
				for(String strId:idArray){
					getBaseService().delete(strId,getSession());
				}
			}
			WriterUtil.getJSONString(getServletResponse(),"{flag:'T',msg:'成功',data:'xxxxxx'}");
		} catch (Exception e2) {
			log.error(e2);
			WriterUtil.getJSONString(getServletResponse(),"{flag:'F',msg:'删除过程中出现异常情况" + e2.getLocalizedMessage() + "',data:'xxxxxx'}");//
		}
		return null;
	}


	/**
	 * list初始化，转向list
	 * @return
	 * @throws Exception
	 */

	public String list() throws Exception {		
		return "list";
	}

	/**
	 * 执行list,完成后，转向doList
	 * @return
	 * @throws Exception
	 */
	public String doList() throws Exception {		
		return "doList";
	}
	
	
	public void setPage(int page) {
		this.page = page;
		this.pageNo=page;
		
	}

	public void setSortname(String sortname) {
		this.sortname = sortname;
	}

	public void setSortorder(String sortorder) {
		this.sortorder = sortorder;
	}

	public void setRp(int rp) {
		this.rp = rp;
		this.pageSize=rp;
	}
	
	/**
	 * 获取页面参数 pageSize(rp),pageNo(page),sortname,sortorder
	 */
	public void getPageParameters(){
		
		setPage(Integer.parseInt(request.getParameter("page")));
		setRp(Integer.parseInt(request.getParameter("rp")));		
		setSortname(request.getParameter("sortname"));
		setSortorder(request.getParameter("sortorder"));		
		
	}
	
}
