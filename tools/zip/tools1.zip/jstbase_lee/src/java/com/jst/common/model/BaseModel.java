package com.jst.common.model;

import java.io.Serializable;

public class BaseModel implements Serializable{
	protected Object id;

	public Object getId() {
		return id;
	}
	public void setId(Object id) {
		this.id = id;
	}
	
}
