package com.jst.common.service;

import java.io.Serializable;


import java.util.List;



import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.jst.common.utils.page.Page;
import com.jst.common.model.BaseModel;
import com.jst.common.hibernate.HibernateBaseDAO;
import com.jst.common.hibernate.PropertyFilter;
import com.jst.common.service.BaseService;
import javax.servlet.http.HttpSession;

@Transactional
public abstract class BaseServiceImpl implements BaseService{
	private static final Log log = LogFactory.getLog(HibernateBaseDAO.class);
	
	public abstract HibernateBaseDAO getHibernateBaseDAO();
	
	public Object add(BaseModel baseModel,HttpSession httpSession)throws Exception{
		getHibernateBaseDAO().save(baseModel);
		return baseModel.getId();
	}
	
	public void update(BaseModel baseModel,HttpSession httpSession)throws Exception {
		getHibernateBaseDAO().update(baseModel);
	}
	
	public void delete(Object id,HttpSession httpSession)throws Exception {
		getHibernateBaseDAO().delete(id);
	}
	@Transactional(propagation=Propagation.NEVER,readOnly=true)
	public BaseModel get(Serializable id) throws Exception{
		return getHibernateBaseDAO().getById(id);
	}
	

	
	@Transactional(propagation=Propagation.NEVER,readOnly=true)
	public List getListByPropertys(String[] propertyNames,
			Object[] values, String pSqlWhere ,String orderByStr) throws Exception {		
		return getHibernateBaseDAO().getByPropertys(propertyNames, values, pSqlWhere, orderByStr);
	}
	@Transactional(propagation=Propagation.NEVER,readOnly=true)
	public List getListByPorperty(String propertyName,
			Object value, String pSqlWhere) throws Exception{
		return getHibernateBaseDAO().getByPorperty(propertyName, value, pSqlWhere);
	}
	
	
	
	@Transactional(propagation=Propagation.NEVER,readOnly=true)
	public  Page getPage(Page page,List<PropertyFilter> filters) throws Exception{					
			return  getHibernateBaseDAO().getList(page, filters);	
	
	}
	
	@Transactional(propagation=Propagation.NEVER,readOnly=true)
	public List getAllList() throws Exception{			
		return  getHibernateBaseDAO().getAllList();
	}
	
	@Transactional(propagation=Propagation.NEVER,readOnly=true)
	public long getAllListCounter() throws Exception{			
		return  getHibernateBaseDAO().getAllListCounter();
	}
	
	public Page<Object> list(Page page, List<PropertyFilter> filters)
			throws Exception {
		return getHibernateBaseDAO().getList(page, filters);
	}
}
