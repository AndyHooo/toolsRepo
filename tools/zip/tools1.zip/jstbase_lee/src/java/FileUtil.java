import java.io.File;


public class FileUtil {

	public static String hello(String name){

		return "hello"+name;
	}

	public static String fileExists(String fileName) {

		boolean flag = false;

		try {

			File f = new File(fileName);
			
			System.out.println("hello");
			if (f != null && f.isFile()){
				flag= true;
				return "T_file is  exists";
			}else{
				System.out.println("no file");
				flag= false;
				return "F_file is not  exists";
			}

		} catch (Exception e) {
			flag= false;
			return "F_"+e.getMessage();
		}

		

	}

	public static String deleteFile(String fileName) {

		boolean flag = false;

		try {

			File f = new File(fileName);

			if (f != null && f.exists()) {
				f.delete();
				flag= true;

			} else {
				flag= true;
			}

		} catch (Exception e) {
			flag= false;
			return "F_"+e.getMessage();
		}

		if(flag)
			return "T";
		else
			return "F";

	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {		
		System.out.println(fileExists("c:\\abc.jpg"));
	}

}
